"""
标签构建 + 滑动窗口采样 + 分层负采样
====================================
对每个时间断面：
  - 候选对   = 观察窗口内至少 MIN_OBS_INTERACTIONS 次交互的 user-item 对
  - 正样本   = 候选对中，预测窗口内有 LABEL_ACTION 行为（购买）的，label=1
  - 负样本   = 候选对中，预测窗口无购买的，label=0
  - 负采样   = 按 (用户活跃度分层 × 商品热度分层) 分层，统一比例抽取，保留分布代表性

时间合规：候选对与标签分别来自互不重叠的观察窗口 / 预测窗口。
"""
import os
import sys
import argparse
from pyspark.sql import functions as F
from pyspark.sql import Window

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.modeling.config import *


def _activity_bucket(obs, key_col, out_col):
    """按观察窗口内行为总量分 5 层（活跃度/热度），用分位数分桶避免全局排序"""
    agg = obs.groupBy(key_col).agg(F.sum("total_cnt").alias("_cnt"))
    quantiles = agg.approxQuantile("_cnt", [0.2, 0.4, 0.6, 0.8], 0.01)
    expr = F.lit(5)
    for i in range(3, -1, -1):
        expr = F.when(F.col("_cnt") <= quantiles[i], i + 1).otherwise(expr)
    return agg.withColumn(out_col, expr).select(key_col, out_col)


def stratified_neg_sample(neg, obs, n_pos):
    """分层负采样：按 (用户活跃度 × 商品热度) 5×5 层，统一比例抽取，使负:正 ≈ POS_NEG_RATIO"""
    target_neg = n_pos * POS_NEG_RATIO
    n_neg = neg.count()
    if n_neg <= target_neg:
        print(f"  负样本 {n_neg:,} <= 目标 {target_neg:,}，全量保留（不欠采样）")
        return neg

    # 分层
    ub = _activity_bucket(obs, "user_id", "user_bucket")
    ib = _activity_bucket(obs, "item_id", "item_bucket")
    neg = neg.join(ub, "user_id", "left").join(ib, "item_id", "left") \
             .withColumn("stratum", F.concat(F.col("user_bucket").cast("string"),
                                             F.lit("_"), F.col("item_bucket").cast("string")))

    frac = target_neg / n_neg
    strata = [r["stratum"] for r in neg.select("stratum").distinct().collect()]
    fractions = {s: frac for s in strata}
    sampled = neg.sampleBy("stratum", fractions, seed=NEG_SAMPLE_SEED)
    print(f"  分层负采样: {n_neg:,} -> 目标 {target_neg:,} (比例 {frac:.3f}), 层数 {len(strata)}")
    return sampled.drop("user_bucket", "item_bucket", "stratum")


def build_labels(spark, daily, w):
    """对一个断面构建正负样本，返回 (user_id, item_id, label, slice_id, split)"""
    slice_id = w["slice_id"]
    label_col = f"{LABEL_ACTION}_cnt"

    # 观察窗口候选对（>= MIN_OBS_INTERACTIONS 次交互）
    obs = daily.filter(
        (F.col("action_date") >= w["obs_start"]) &
        (F.col("action_date") <= w["obs_end"])
    )
    cand = obs.groupBy("user_id", "item_id").agg(F.sum("total_cnt").alias("_n")) \
              .filter(F.col("_n") >= MIN_OBS_INTERACTIONS) \
              .select("user_id", "item_id")

    # 预测窗口购买对
    pred_buy = daily.filter(
        (F.col("action_date") >= w["pred_start"]) &
        (F.col("action_date") <= w["pred_end"]) &
        (F.col(label_col) > 0)
    ).select("user_id", "item_id").distinct()

    pos = cand.join(pred_buy, ["user_id", "item_id"], "inner") \
              .withColumn("label", F.lit(1))
    neg = cand.join(pred_buy, ["user_id", "item_id"], "left_anti") \
              .withColumn("label", F.lit(0))

    n_pos = pos.count()
    n_neg_before = neg.count()
    print(f"[labels] slice_id={slice_id}: 候选 {n_pos + n_neg_before:,} (正 {n_pos:,} / 负 {n_neg_before:,})")
    if n_pos == 0:
        print(f"[labels] slice_id={slice_id}: 无正样本（购买稀疏），跳过该断面")
        return None

    neg = stratified_neg_sample(neg, obs, n_pos)

    samples = pos.unionByName(neg) \
                 .withColumn("slice_id", F.lit(slice_id)) \
                 .withColumn("split", F.lit(w["split"]))
    return samples
