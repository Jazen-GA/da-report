"""
特征预处理与筛选（第一部分 a.5，配置驱动）
============================================
对 dataset 已落盘的 train/val/test 做：
  1. 缺失值填充      —— 数值特征按 config.PREPROCESS["fill_numeric_na"] 填充
  2. 异常值截断      —— 按 config.PREPROCESS["clip_quantiles"] 分位数裁剪
  3. 标准化          —— 按 train 拟合 mean/std，套到 val/test（防泄露）
  4. 低基数类别独热  —— 类别数 <= config.PREPROCESS["onehot_max_categories"] 才独热
  5. 相关性筛选      —— 按 train 的 |corr| > config.PREPROCESS["corr_threshold"] 剔除冗余

严格防泄露：以上所有拟合（分位数 / mean-std / 独热取值 / 相关性）**只用 train**，
val/test 只做 transform，绝不从 val/test 学习任何参数。

目标编码（高基数类别的 target encoding）不在此处做：它需要 fold 内计算才能避免标签
泄露，放到第二部分训练侧用 out-of-fold 方式实现。

输出: data/modeling/preprocessed/{mode}/{train|val|test}  (Parquet)
用法: python scripts/modeling/preprocess.py --mode debug|dev|full
"""
import os
import sys
import json
import time
import argparse
from pyspark.sql import functions as F
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.stat import Correlation

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.modeling.config import *


# ── 列类型划分（换数据改 config，不改这里）──
# 元数据列：不参与任何特征处理
META_COLS = ["user_id", "item_id", "label", "slice_id", "split", "pred_start", "obs_end"]
# 类别列（id 型）：高基数保留原值（第二部分目标编码），低基数独热
CAT_COLS = ["parent_cat", "leaf_cat", "brand_id", "seller_id",
            "u_top1_cat", "u_top2_cat", "u_top3_cat", "u_top1_brand"]


def _numeric_cols(df):
    """数值特征列 = 全部列 - 元数据 - 类别（x_stage / x_has_full_path 等离散列也按数值处理）"""
    return [c for c in df.columns if c not in META_COLS and c not in CAT_COLS]


def _read(spark, mode, split):
    return spark.read.parquet(os.path.join(DATASET_DIR, mode, split))


def fit(train, numeric_cols, p):
    """只用 train 拟合全部预处理参数，返回 params dict"""
    params = {}

    # 1) 异常值截断分位数（approxQuantile 自动忽略 null）
    if p.get("clip_quantiles"):
        lo, hi = p["clip_quantiles"]
        params["clip"] = {}
        for c in numeric_cols:
            q = train.approxQuantile(c, [lo, hi], 0.001)
            if q[0] is not None and q[1] is not None and q[0] < q[1]:
                params["clip"][c] = (float(q[0]), float(q[1]))

    # 2) 标准化 mean/std
    if p.get("standardize"):
        agg = []
        for c in numeric_cols:
            agg += [F.mean(c).alias(f"{c}__m"), F.stddev(c).alias(f"{c}__s")]
        row = train.agg(*agg).collect()[0]
        params["scale"] = {}
        for c in numeric_cols:
            m, s = row[f"{c}__m"], row[f"{c}__s"]
            if m is not None and s is not None and s > 0:
                params["scale"][c] = (float(m), float(s))

    # 3) 低基数类别独热取值
    if p.get("onehot_max_categories"):
        params["onehot"] = {}
        for c in CAT_COLS:
            if c not in train.columns:
                continue
            vals = [r[c] for r in train.select(c).distinct().na.drop().collect()]
            if 0 < len(vals) <= p["onehot_max_categories"]:
                params["onehot"][c] = vals

    # 4) 相关性筛选（只在标准化前的数值列上算，剔除高相关冗余）
    params["drop_cols"] = []
    if p.get("corr_threshold"):
        corr_cols = [c for c in numeric_cols if c in train.columns]
        if len(corr_cols) >= 2:
            vec = VectorAssembler(inputCols=corr_cols, outputCol="__vec", handleInvalid="skip") \
                .transform(train.select(corr_cols))
            corr_mat = Correlation.corr(vec, "__vec", "pearson").collect()[0][0]
            n = len(corr_cols)
            drop = set()
            for i in range(n):
                if corr_cols[i] in drop:
                    continue
                for j in range(i + 1, n):
                    if corr_cols[j] in drop:
                        continue
                    if abs(corr_mat[i, j]) > p["corr_threshold"]:
                        drop.add(corr_cols[j])  # 保留靠前的，剔除靠后的
            params["drop_cols"] = sorted(drop)

    return params


def transform(df, numeric_cols, params, p):
    """套用 fit 得到的参数，产出处理后的 DataFrame（不学习任何新参数）"""
    # 1) 缺失填充（数值列）
    if p.get("fill_numeric_na") is not None:
        fill_val = float(p["fill_numeric_na"])
        df = df.fillna(fill_val, subset=[c for c in numeric_cols if c in df.columns])

    # 2) 异常值截断
    for c, (lo, hi) in params.get("clip", {}).items():
        df = df.withColumn(c, F.when(F.col(c) < lo, lo).when(F.col(c) > hi, hi).otherwise(F.col(c)))

    # 3) 标准化
    for c, (m, s) in params.get("scale", {}).items():
        df = df.withColumn(c, (F.col(c) - m) / s)

    # 4) 低基数类别独热（未知值 / null → 全 0）
    for c, vals in params.get("onehot", {}).items():
        for v in vals:
            df = df.withColumn(f"{c}_oh_{v}", F.when(F.col(c) == v, 1).otherwise(0))
        df = df.drop(c)

    # 5) 相关性剔除
    drop = [c for c in params.get("drop_cols", []) if c in df.columns]
    if drop:
        df = df.drop(*drop)

    return df


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["debug", "dev", "full"], default="debug")
    args = parser.parse_args()

    p = PREPROCESS

    # 容错：debug 档日志过小、观察窗口内无购买时，dataset.py 不会产出任何样本。
    # 此时跳过预处理并正常退出，避免对空目录读 parquet 抛异常。
    if not os.path.isdir(os.path.join(DATASET_DIR, args.mode, "train")):
        print(f"[preprocess] 未找到 dataset/{args.mode}/train，跳过预处理。")
        print("  原因：样本过小（debug 档常见——观察窗口内无购买，dataset 无正样本未产出）。")
        print("  请用更大档位（dev/full）验证，或检查 dataset.py 日志。")
        return

    spark = create_spark(f"Modeling-Preprocess-{args.mode}")
    t0 = time.time()

    train = _read(spark, args.mode, "train")
    # 目录可能存在但残留 0 行空 parquet（历史无正样本运行），行数为 0 同样跳过
    if train.count() == 0:
        print(f"[preprocess] dataset/{args.mode}/train 为空（0 行），跳过预处理。")
        print("  原因：样本过小（debug 档常见——观察窗口内无购买，无正样本）。请用更大档位（dev/full）。")
        spark.stop()
        return
    numeric_cols = _numeric_cols(train)
    print(f"[preprocess] 数值特征 {len(numeric_cols)} 列，类别特征 {len(CAT_COLS)} 列")

    params = fit(train, numeric_cols, p)
    print(f"[preprocess] 拟合完成：clip={len(params.get('clip', {}))} "
          f"scale={len(params.get('scale', {}))} onehot={list(params.get('onehot', {}).keys())} "
          f"drop={len(params.get('drop_cols', []))} 列")

    out_root = os.path.join(PREPROCESSED_DIR, args.mode)
    for split in ["train", "val", "test"]:
        df = _read(spark, args.mode, split)
        out = transform(df, numeric_cols, params, p)
        out.write.mode("overwrite").option("compression", "snappy") \
            .parquet(os.path.join(out_root, split))
        print(f"[preprocess] {split}: {out.count():,} 行, {len(out.columns)} 列 -> {os.path.join(out_root, split)}")

    # 落一份参数清单（可复现 / 供第二部分复用）
    os.makedirs(REPORTS_DIR, exist_ok=True)
    param_path = os.path.join(REPORTS_DIR, f"{args.mode}_preprocess_params.json")
    with open(param_path, "w", encoding="utf-8") as f:
        json.dump({
            "numeric_cols": numeric_cols,
            "clip": params.get("clip", {}),
            "scale": params.get("scale", {}),
            "onehot": params.get("onehot", {}),
            "drop_cols": params.get("drop_cols", []),
        }, f, ensure_ascii=False, indent=2)

    print(f"[preprocess] 完成, 耗时 {time.time() - t0:.1f}s; 参数清单 -> {param_path}")
    spark.stop()


if __name__ == "__main__":
    main()
