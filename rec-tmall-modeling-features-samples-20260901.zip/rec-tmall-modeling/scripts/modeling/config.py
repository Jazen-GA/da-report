"""
建模 pipeline 全局配置
======================
用户购买意愿与转化预测：特征工程 + 样本构建（第一部分 a+b）

所有参数集中在此。换一个结构相似的数据集，只需修改本文件：
  - COL:            字段名映射
  - ACTION_VALUES / LABEL_ACTION: 行为类型取值及正样本（购买）行为
  - OBS_WINDOW_DAYS / PRED_WINDOW_DAYS / FEATURE_WINDOWS: 时间窗口
  - SLICES:         时间断面与 train/val/test 归属
  - POS_NEG_RATIO / MIN_OBS_INTERACTIONS: 采样
其余脚本一律不改。
"""
import os
import sys
from datetime import date, timedelta

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, PROJECT_ROOT)

from scripts.config import (DATA_CLEANED, DATA_SAMPLES, SENTIMENT_OUTPUT_DIR, create_spark)

# ── 数据输入路径 ──
LOG_PATH = os.path.join(DATA_CLEANED, "log")
PRODUCT_PATH = os.path.join(DATA_CLEANED, "product")
REVIEW_PATH = os.path.join(DATA_CLEANED, "review")
ITEM_REPUTATION_CSV = os.path.join(SENTIMENT_OUTPUT_DIR, "item_reputation.csv")

# ── 三档推进：debug（万级）/ dev（1% 用户）/ full（全量）──
LOG_BY_MODE = {
    "full": LOG_PATH,
    "dev": os.path.join(DATA_SAMPLES, "dev", "log"),
    "debug": os.path.join(DATA_SAMPLES, "debug", "log"),
}

# ── 建模输出目录 ──
MODELING_DIR = os.path.join(PROJECT_ROOT, "data", "modeling")
DAILY_DIR = os.path.join(MODELING_DIR, "daily")
FEATURES_DIR = os.path.join(MODELING_DIR, "features")
DATASET_DIR = os.path.join(MODELING_DIR, "dataset")
PREPROCESSED_DIR = os.path.join(MODELING_DIR, "preprocessed")
REPORTS_DIR = os.path.join(MODELING_DIR, "reports")

# ── 字段名映射（换数据改这里）──
# 日志侧 + product 侧 + 口碑侧的全部原始列名集中在此；脚本内只认这里定义的别名
COL = {
    # 日志表
    "user_id": "user_id",
    "item_id": "item_id",
    "action": "action",
    "date": "action_date",   # 清洗后的日期列（yyyy-MM-dd）
    # product 表
    "product_category": "category",   # 类目列，默认 "父类目-子类目" 拼接字符串
    "product_brand": "brand_id",
    "product_seller": "seller_id",
    # 口碑表（复用情感分析产出）
    "review_cnt": "review_cnt",
    "review_pos_rate": "pos_rate",
    "review_avg_sentiment": "avg_sentiment",
}

# ── 类目解析（换数据改这里）──
# product 类目列按分隔符拆成父/子两级；数值类目 cast int，非数值保留原样
CATEGORY_SPLIT = "-"
CATEGORY_PARENT_IDX = 0
CATEGORY_LEAF_IDX = 1

# ── 行为映射（换数据改这里）──
# 数据集里的四类行为取值；LABEL_ACTION 是正样本（购买）行为
ACTION_VALUES = ["click", "collect", "cart", "alipay"]
LABEL_ACTION = "alipay"

# 行为语义位置（换数据改这里）：四类行为按「点击→收藏→加购→购买」的漏斗顺序排列，
# 派生特征（占比/转化率/决策阶段/动销率/交互深度）依赖此顺序；换数据保持语义顺序填即可。
ACTION_CLICK = ACTION_VALUES[0]    # 点击/浏览
ACTION_COLLECT = ACTION_VALUES[1]  # 收藏
ACTION_CART = ACTION_VALUES[2]     # 加购
ACTION_BUY = LABEL_ACTION          # 购买（正样本）

# ── 时间窗口（换数据改这里）──
OBS_WINDOW_DAYS = 30    # 观察窗口长度（天）
PRED_WINDOW_DAYS = 7    # 预测窗口长度（天）
FEATURE_WINDOWS = [7, 14, 30]   # 「近 N 天」特征窗口

# ── 时间断面（滑动窗口采样，换数据改这里）──
# 每个断面 = 30 天观察窗口 + 7 天预测窗口；pred_start 为预测窗口起点（也是标签时间基准）
SLICES = [
    {"slice_id": 1, "pred_start": "2013-05-01", "split": "train"},
    {"slice_id": 2, "pred_start": "2013-06-01", "split": "train"},
    {"slice_id": 3, "pred_start": "2013-07-01", "split": "train"},
    {"slice_id": 4, "pred_start": "2013-08-01", "split": "val"},
    {"slice_id": 5, "pred_start": "2013-09-01", "split": "test"},
    {"slice_id": 6, "pred_start": "2013-09-15", "split": "test"},
]

# ── 采样参数（换数据改这里）──
POS_NEG_RATIO = 5          # 负样本 : 正样本（目标比例）
MIN_OBS_INTERACTIONS = 1   # 观察窗口内最少交互次数（<此值剔除）
NEG_SAMPLE_SEED = 42

# ── 时间衰减（近 N 天加权频次）──
TIME_DECAY_LAMBDA = 0.05   # 权重 = exp(-lambda * 距 obs_end 的天数)

# ── 特征组开关（可插拔）──
FEATURE_GROUPS = ["user", "item", "cross", "sequence"]

# ── 特征预处理（preprocess.py，换数据改这里）──
# 缺失填充 / 异常值截断 / 标准化 / 低基数独热 / 相关性筛选，全部用 train 拟合再套到 val/test（防泄露）
PREPROCESS = {
    "fill_numeric_na": 0.0,            # 数值特征缺失填充值（None=不填）
    "clip_quantiles": [0.01, 0.99],    # 异常值截断分位数（None=不截断）
    "standardize": True,               # 是否标准化（train 拟合 mean/std）
    "onehot_max_categories": 10,       # 低基数类别独热阈值（类别数 <= 此值才独热）
    "corr_threshold": 0.95,            # 相关性筛选阈值（|corr| > 此值剔除其一）
}

# ── 类别权重（第二部分训练时使用，此处仅预留开关）──
# 负:正 ≈ 5:1 不平衡，训练侧启用 class_weight 从损失函数层平衡；
# 不在落盘阶段计算（目标编码/权重需在训练集内部 fold 内算，全局算会引入标签泄露）
USE_CLASS_WEIGHT = True


def _parse(s):
    return date(*[int(x) for x in s.split("-")])


def slice_windows():
    """展开每个断面的完整时间窗口，返回 ISO 字符串（yyyy-MM-dd 字符串比较等价于日期比较）。

    观察窗口 [obs_start, obs_end]（含边界），预测窗口 [pred_start, pred_end]（含边界）。
    特征只用 < pred_start 的数据，标签只用 [pred_start, pred_end] 的数据 —— 从规则上杜绝时间穿越。
    """
    out = []
    for s in SLICES:
        pred_start = _parse(s["pred_start"])
        obs_start = pred_start - timedelta(days=OBS_WINDOW_DAYS)
        obs_end = pred_start - timedelta(days=1)
        pred_end = pred_start + timedelta(days=PRED_WINDOW_DAYS - 1)
        out.append({
            "slice_id": s["slice_id"],
            "split": s["split"],
            "pred_start": pred_start.isoformat(),
            "pred_end": pred_end.isoformat(),
            "obs_start": obs_start.isoformat(),
            "obs_end": obs_end.isoformat(),
        })
    return out
