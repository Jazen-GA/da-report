"""
每日行为中间表构建
==================
把日志聚合成 (user_id, item_id, action_date) 粒度：每天每个 user-item 对的四类行为计数。

这是整条 pipeline 的「地基」：
  - user 侧特征   = groupBy(user_id) + 日期窗口过滤累加
  - item 侧特征   = groupBy(item_id) + 日期窗口过滤累加
  - 交叉/序列特征 = 在 (user_id, item_id) / (user_id, date) 粒度聚合

全量日志只扫这一次。后续任意窗口/断面/行为映射都从这张表切片累加，不改结构。

输出: data/modeling/daily/{mode}  (Parquet)
用法: python scripts/modeling/aggregate.py --mode debug|dev|full
"""
import os
import sys
import time
import argparse
from pyspark.sql import functions as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.modeling.config import *


def build_daily(spark, mode):
    log_path = LOG_BY_MODE[mode]
    out_path = os.path.join(DAILY_DIR, mode)

    t0 = time.time()
    print(f"[aggregate] 读取日志: {log_path}")
    log = spark.read.parquet(log_path)

    # 只保留建模需要的列，列名按 config 映射重命名为固定名
    log = log.select(
        F.col(COL["user_id"]).alias("user_id"),
        F.col(COL["item_id"]).alias("item_id"),
        F.col(COL["action"]).alias("action"),
        F.col(COL["date"]).alias("action_date"),
    )

    print("[aggregate] 聚合 (user_id, item_id, action_date) 粒度...")
    # 四类行为计数列名由 ACTION_VALUES 动态生成，换行为取值无需改这里
    agg_exprs = [
        F.sum(F.when(F.col("action") == a, 1).otherwise(0)).alias(f"{a}_cnt")
        for a in ACTION_VALUES
    ]
    daily = log.groupBy("user_id", "item_id", "action_date").agg(
        *agg_exprs, F.count("*").alias("total_cnt")
    )

    daily.write.mode("overwrite").option("compression", "snappy").parquet(out_path)
    n = spark.read.parquet(out_path).count()
    print(f"[aggregate] 完成: {n:,} 行, 耗时 {time.time() - t0:.1f}s -> {out_path}")
    return daily


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["debug", "dev", "full"], default="debug")
    args = parser.parse_args()

    spark = create_spark(f"Modeling-Aggregate-{args.mode}")
    build_daily(spark, args.mode)
    spark.stop()


if __name__ == "__main__":
    main()
