"""
Rec-Tmall 全局探索性数据分析 (Global EDA)
===========================================
覆盖四个模块：
  1. 全量数据规模统计与基础画像
  2. 核心维度分布探查与规律识别
  3. 全局核心业务指标基线计算
  4. 跨表关联关系验证与可行性评估

输出：
  - reports/eda_global_report.md      综合报告
  - reports/eda_global_metrics.json    全部指标 JSON
  - reports/charts/                    可视化图表

用法: source venv/bin/activate && python scripts/eda_global.py
"""
import os, sys, time, json, math
from datetime import datetime
from collections import OrderedDict

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns
import numpy as np
import pandas as pd
from pyspark.sql import functions as F, types as T, Window

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.config import *

# ── 全局配置 ──
sns.set_theme(style="whitegrid", font=["SimHei", "Arial Unicode MS", "sans-serif"])
plt.rcParams["axes.unicode_minus"] = False

CHARTS_DIR = os.path.join(REPORTS_DIR, "charts")
os.makedirs(CHARTS_DIR, exist_ok=True)

METRICS = OrderedDict()  # 收集所有指标

RUN_START = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")

def save_chart(fig, name):
    path = os.path.join(CHARTS_DIR, name)
    fig.savefig(path, dpi=150, bbox_inches="tight", facecolor="white")
    log(f"  图表已保存: {name}")
    plt.close(fig)

# ================================================================
# 第 0 部分：加载数据
# ================================================================
def load_data(spark):
    log("加载清洗后数据...")
    t0 = time.time()

    df_product = spark.read.parquet(CLEANED_FILES["product"])
    df_log = spark.read.parquet(CLEANED_FILES["log"])
    df_review = spark.read.parquet(CLEANED_FILES["review"])

    # 注册临时视图
    df_product.createOrReplaceTempView("product")
    df_log.createOrReplaceTempView("log")
    df_review.createOrReplaceTempView("review")

    # 缓存小表
    df_product.cache()
    df_review.cache()

    # 获取各表行数
    c_log = df_log.count()
    c_product = df_product.count()
    c_review = df_review.count()

    log(f"  数据加载完成, 耗时 {time.time() - t0:.0f}s")
    log(f"  log: {c_log:,} 行 | product: {c_product:,} 行 | review: {c_review:,} 行")

    return df_log, df_product, df_review

# ================================================================
# 第 1 部分：全量数据规模统计与基础画像
# ================================================================
def section1_basic_profile(spark, df_log, df_product, df_review):
    log("=" * 60)
    log("第 1 部分：全量数据规模统计与基础画像")
    log("=" * 60)

    s1 = OrderedDict()

    # ── 1.1 日志表 ──
    log("1.1 日志表基础画像...")
    t0 = time.time()
    log_agg = spark.sql("""
        SELECT
            COUNT(*) AS total,
            COUNT(DISTINCT user_id) AS distinct_users,
            COUNT(DISTINCT item_id) AS distinct_items,
            COUNT(DISTINCT action) AS action_types
        FROM log
    """).collect()[0]

    # 各行为类型计数
    action_counts = spark.sql("""
        SELECT action, COUNT(*) AS cnt
        FROM log
        GROUP BY action
        ORDER BY cnt DESC
    """).collect()

    s1["log"] = {
        "total_records": int(log_agg["total"]),
        "distinct_users": int(log_agg["distinct_users"]),
        "distinct_items": int(log_agg["distinct_items"]),
        "action_types": int(log_agg["action_types"]),
        "action_breakdown": {r["action"]: int(r["cnt"]) for r in action_counts},
    }
    # 交叉校验官方值
    s1["log"]["official_count"] = OFFICIAL_COUNTS["log"]
    s1["log"]["official_diff_pct"] = round(
        (log_agg["total"] - OFFICIAL_COUNTS["log"]) / OFFICIAL_COUNTS["log"] * 100, 2
    )
    log(f"  总记录: {log_agg['total']:,} | 用户: {log_agg['distinct_users']:,} | 商品: {log_agg['distinct_items']:,}")
    log(f"  耗时 {time.time() - t0:.0f}s")

    # ── 1.2 商品表 ──
    log("1.2 商品表基础画像...")
    t0 = time.time()
    prod_agg = spark.sql("""
        SELECT
            COUNT(*) AS total,
            COUNT(DISTINCT item_id) AS distinct_items,
            COUNT(DISTINCT brand_id) AS distinct_brands,
            COUNT(DISTINCT seller_id) AS distinct_sellers,
            COUNT(DISTINCT category) AS distinct_categories,
            COUNT(DISTINCT SPLIT(category, '-')[0]) AS distinct_parent_cats,
            COUNT(DISTINCT SPLIT(category, '-')[1]) AS distinct_leaf_cats
        FROM product
    """).collect()[0]

    s1["product"] = {
        "total_records": int(prod_agg["total"]),
        "distinct_items": int(prod_agg["distinct_items"]),
        "distinct_parent_categories": int(prod_agg["distinct_parent_cats"]),
        "distinct_leaf_categories": int(prod_agg["distinct_leaf_cats"]),
        "distinct_categories": int(prod_agg["distinct_categories"]),
        "distinct_brands": int(prod_agg["distinct_brands"]),
        "distinct_sellers": int(prod_agg["distinct_sellers"]),
    }
    s1["product"]["official_count"] = OFFICIAL_COUNTS["product"]
    s1["product"]["official_diff_pct"] = round(
        (prod_agg["total"] - OFFICIAL_COUNTS["product"]) / OFFICIAL_COUNTS["product"] * 100, 2
    )
    log(f"  总商品: {prod_agg['total']:,} | 父类目: {prod_agg['distinct_parent_cats']} | 叶子类目: {prod_agg['distinct_leaf_cats']} | 品牌: {prod_agg['distinct_brands']:,} | 卖家: {prod_agg['distinct_sellers']:,}")
    log(f"  耗时 {time.time() - t0:.0f}s")

    # ── 1.3 评论表 ──
    log("1.3 评论表基础画像...")
    t0 = time.time()
    rev_agg = spark.sql("""
        SELECT
            COUNT(*) AS total,
            COUNT(DISTINCT user_id) AS distinct_users,
            COUNT(DISTINCT item_id) AS distinct_items
        FROM review
    """).collect()[0]

    s1["review"] = {
        "total_records": int(rev_agg["total"]),
        "distinct_users": int(rev_agg["distinct_users"]),
        "distinct_items": int(rev_agg["distinct_items"]),
    }
    s1["review"]["official_count"] = OFFICIAL_COUNTS["review"]
    s1["review"]["official_diff_pct"] = round(
        (rev_agg["total"] - OFFICIAL_COUNTS["review"]) / OFFICIAL_COUNTS["review"] * 100, 2
    )
    log(f"  总评论: {rev_agg['total']:,} | 用户: {rev_agg['distinct_users']:,} | 商品: {rev_agg['distinct_items']:,}")
    log(f"  耗时 {time.time() - t0:.0f}s")

    # ── 1.4 类目层级专项梳理 ──
    log("1.4 类目层级专项梳理...")
    t0 = time.time()
    cat_hierarchy = spark.sql("""
        SELECT
            CAST(SPLIT(category, '-')[0] AS INT) AS parent_cat,
            CAST(SPLIT(category, '-')[1] AS INT) AS leaf_cat,
            COUNT(*) AS product_count
        FROM product
        GROUP BY parent_cat, leaf_cat
    """).cache()

    parent_summary = spark.sql("""
        SELECT
            CAST(SPLIT(category, '-')[0] AS INT) AS parent_cat,
            COUNT(DISTINCT SPLIT(category, '-')[1]) AS leaf_cat_count,
            COUNT(*) AS product_count
        FROM product
        GROUP BY parent_cat
        ORDER BY product_count DESC
    """).collect()

    s1["category_hierarchy"] = {
        "total_parent_categories": len(parent_summary),
        "parent_categories": [
            {
                "parent_cat": r["parent_cat"],
                "leaf_cat_count": int(r["leaf_cat_count"]),
                "product_count": int(r["product_count"]),
            }
            for r in parent_summary
        ],
    }
    log(f"  父类目总数: {len(parent_summary)}, 完整清单已生成")
    log(f"  耗时 {time.time() - t0:.0f}s")

    # 释放缓存
    cat_hierarchy.unpersist()

    METRICS["section1"] = s1
    return s1

# ================================================================
# 第 1 部分（续）：数据稀疏性评估
# ================================================================
def section1b_sparsity(spark):
    log("1.5 数据稀疏性评估...")
    t0 = time.time()

    s1b = OrderedDict()

    # 使用已有的 distinct 计数
    log_users = METRICS["section1"]["log"]["distinct_users"]
    log_items = METRICS["section1"]["log"]["distinct_items"]
    log_total = METRICS["section1"]["log"]["total_records"]
    rev_users = METRICS["section1"]["review"]["distinct_users"]
    rev_items = METRICS["section1"]["review"]["distinct_items"]
    rev_total = METRICS["section1"]["review"]["total_records"]
    prod_total = METRICS["section1"]["product"]["total_records"]

    # 用户-商品交互矩阵稀疏度
    possible_pairs = log_users * log_items
    interaction_sparsity = (1 - log_total / possible_pairs) * 100

    # 评论数据稀疏度
    rev_possible_pairs = rev_users * rev_items
    review_sparsity = (1 - rev_total / rev_possible_pairs) * 100

    # 商品覆盖率（有交互的商品 / 总商品）
    item_coverage = log_items / prod_total * 100

    # 用户-商品密度（log scale）
    avg_interactions_per_user = log_total / log_users
    avg_interactions_per_item = log_total / log_items

    s1b["sparsity"] = {
        "user_item_matrix_possible_pairs": possible_pairs,
        "user_item_matrix_actual_interactions": log_total,
        "user_item_matrix_sparsity_pct": round(interaction_sparsity, 6),
        "review_possible_pairs": rev_possible_pairs,
        "review_actual": rev_total,
        "review_sparsity_pct": round(review_sparsity, 6),
        "item_coverage_pct": round(item_coverage, 2),
        "avg_interactions_per_user": round(avg_interactions_per_user, 2),
        "avg_interactions_per_item": round(avg_interactions_per_item, 2),
        "log_users": log_users,
        "log_items": log_items,
    }

    log(f"  交互矩阵稀疏度: {interaction_sparsity:.6f}% (即密度 {100-interaction_sparsity:.6f}%)")
    log(f"  评论稀疏度: {review_sparsity:.6f}%")
    log(f"  商品覆盖率: {item_coverage:.2f}%")
    log(f"  人均交互: {avg_interactions_per_user:.2f} | 品均交互: {avg_interactions_per_item:.2f}")
    log(f"  耗时 {time.time() - t0:.0f}s")

    METRICS["section1b"] = s1b
    return s1b

# ================================================================
# 第 2 部分：核心维度分布探查与规律识别
# ================================================================
def section2_distributions(spark):
    log("=" * 60)
    log("第 2 部分：核心维度分布探查与规律识别")
    log("=" * 60)

    s2 = OrderedDict()

    # ── 2.1 行为结构分析 ──
    log("2.1 行为结构分析...")
    t0 = time.time()
    action_stats = spark.sql("""
        SELECT
            action,
            COUNT(*) AS cnt,
            COUNT(*) * 1.0 / SUM(COUNT(*)) OVER() AS ratio
        FROM log
        GROUP BY action
        ORDER BY cnt DESC
    """).collect()

    action_dict = {}
    for r in action_stats:
        action_dict[r["action"]] = {
            "count": int(r["cnt"]),
            "ratio_pct": round(float(r["ratio"]) * 100, 2),
        }

    # 链路衰减率
    click_cnt = action_dict.get("click", {}).get("count", 1)
    collect_cnt = action_dict.get("collect", {}).get("count", 0)
    cart_cnt = action_dict.get("cart", {}).get("count", 0)
    alipay_cnt = action_dict.get("alipay", {}).get("count", 0)

    s2["action_structure"] = {
        "breakdown": action_dict,
        "click_to_collect_rate": round(collect_cnt / click_cnt * 100, 4),
        "click_to_cart_rate": round(cart_cnt / click_cnt * 100, 4),
        "click_to_alipay_rate": round(alipay_cnt / click_cnt * 100, 4),
        "collect_to_alipay_rate": round(alipay_cnt / collect_cnt * 100, 2) if collect_cnt > 0 else 0,
        "cart_to_alipay_rate": round(alipay_cnt / cart_cnt * 100, 2) if cart_cnt > 0 else 0,
        "funnel": {
            "click": click_cnt,
            "collect": collect_cnt,
            "cart": cart_cnt,
            "alipay": alipay_cnt,
        },
    }
    log(f"  click→collect: {s2['action_structure']['click_to_collect_rate']}% | click→cart: {s2['action_structure']['click_to_cart_rate']}% | click→alipay: {s2['action_structure']['click_to_alipay_rate']}%")
    log(f"  耗时 {time.time() - t0:.0f}s")

    # 饼图
    fig, ax = plt.subplots(figsize=(8, 6))
    labels = list(action_dict.keys())
    sizes = [action_dict[k]["count"] for k in labels]
    colors = ["#4472C4", "#ED7D31", "#A5A5A5", "#FFC000"]
    wedges, texts, autotexts = ax.pie(sizes, labels=labels, autopct="%1.2f%%",
                                       colors=colors, startangle=90, pctdistance=0.6)
    for at in autotexts:
        at.set_fontsize(11)
    ax.set_title("用户行为类型分布", fontsize=14, fontweight="bold")
    save_chart(fig, "action_pie.png")

    # ── 2.2 多粒度时间分布 ──
    log("2.2 多粒度时间分布分析...")
    t0 = time.time()

    # 2.2a 小时级
    log("  2.2a 小时级分布...")
    hourly = spark.sql("""
        SELECT
            HOUR(vtime) AS hour,
            action,
            COUNT(*) AS cnt
        FROM log
        GROUP BY HOUR(vtime), action
        ORDER BY hour, action
    """).toPandas()

    hourly_pivot = hourly.pivot(index="hour", columns="action", values="cnt").fillna(0)
    s2["hourly_distribution"] = {
        str(h): {a: int(hourly_pivot.loc[h, a]) if a in hourly_pivot.columns else 0
                 for a in ["click", "collect", "cart", "alipay"]}
        for h in hourly_pivot.index
    }

    # 小时热力图数据
    fig, ax = plt.subplots(figsize=(14, 5))
    actions = ["click", "collect", "cart", "alipay"]
    for i, act in enumerate(actions):
        if act in hourly_pivot.columns:
            act_data = hourly_pivot[act]
            act_norm = act_data / act_data.max()
            ax.plot(act_data.index, act_norm.values, "o-", label=act, linewidth=1.5, markersize=3)
    ax.set_xlabel("小时", fontsize=11)
    ax.set_ylabel("归一化流量", fontsize=11)
    ax.set_title("24小时各行为流量分布（归一化）", fontsize=13, fontweight="bold")
    ax.legend()
    ax.set_xticks(range(0, 24))
    save_chart(fig, "hourly_pattern.png")

    # 2.2b 日级
    log("  2.2b 日级分布...")
    daily = spark.sql("""
        SELECT
            action_date,
            action,
            COUNT(*) AS cnt
        FROM log
        GROUP BY action_date, action
        ORDER BY action_date, action
    """).toPandas()

    daily_pivot = daily.pivot(index="action_date", columns="action", values="cnt").fillna(0)
    daily_total = daily_pivot.sum(axis=1)

    s2["daily_distribution"] = {
        "total_days": len(daily_total),
        "date_range_start": str(daily_total.index.min()),
        "date_range_end": str(daily_total.index.max()),
        "daily_avg": round(float(daily_total.mean()), 0),
        "daily_std": round(float(daily_total.std()), 0),
        "daily_max": int(daily_total.max()),
        "daily_min": int(daily_total.min()),
        "daily_max_date": str(daily_total.idxmax()),
        "daily_min_date": str(daily_total.idxmin()),
    }

    fig, ax = plt.subplots(figsize=(16, 5))
    ax.plot(pd.to_datetime(daily_total.index), daily_total.values, linewidth=0.5, color="#4472C4")
    ax.set_xlabel("日期", fontsize=11)
    ax.set_ylabel("行为量", fontsize=11)
    ax.set_title(f"每日行为量趋势 ({s2['daily_distribution']['date_range_start']} ~ {s2['daily_distribution']['date_range_end']})", fontsize=13, fontweight="bold")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x/1e6:.0f}M"))
    save_chart(fig, "daily_trend.png")

    # 2.2c 周级
    log("  2.2c 周级分布...")
    weekly = spark.sql("""
        SELECT
            DATE_FORMAT(vtime, 'E') AS weekday_name,
            DAYOFWEEK(vtime) AS dow,
            action,
            COUNT(*) AS cnt
        FROM log
        GROUP BY DATE_FORMAT(vtime, 'E'), DAYOFWEEK(vtime), action
        ORDER BY dow, action
    """).toPandas()

    s2["weekly_distribution"] = {
        "raw": weekly.groupby("weekday_name")["cnt"].sum().to_dict()
    }

    fig, ax = plt.subplots(figsize=(10, 5))
    week_order = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    week_cn = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
    weekly_pivot = weekly.pivot(index="weekday_name", columns="action", values="cnt").fillna(0)
    weekly_pivot = weekly_pivot.reindex([w for w in week_order if w in weekly_pivot.index])
    bottom = np.zeros(len(weekly_pivot))
    for act in actions:
        if act in weekly_pivot.columns:
            vals = weekly_pivot[act].values
            ax.bar(range(len(weekly_pivot)), vals, bottom=bottom, label=act)
            bottom += vals
    ax.set_xticks(range(len(weekly_pivot)))
    ax.set_xticklabels([week_cn[week_order.index(w)] if w in week_order else w for w in weekly_pivot.index])
    ax.set_ylabel("行为量", fontsize=11)
    ax.set_title("周内各天行为量分布", fontsize=13, fontweight="bold")
    ax.legend()
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x/1e6:.0f}M"))
    save_chart(fig, "weekly_pattern.png")

    log(f"  时间分布分析完成, 耗时 {time.time() - t0:.0f}s")

    # ── 2.3 用户活跃度分布 ──
    log("2.3 用户活跃度分布...")
    t0 = time.time()

    user_activity = spark.sql("""
        SELECT
            user_id,
            COUNT(*) AS total_actions,
            SUM(CASE WHEN action = 'alipay' THEN 1 ELSE 0 END) AS purchase_count
        FROM log
        GROUP BY user_id
    """).cache()
    user_activity.createOrReplaceTempView("user_stats")

    # 统计分位数（使用 Spark SQL percentile_approx 提升偏态分布下的精度）
    quantiles_sql = spark.sql("""
        SELECT
            percentile_approx(total_actions, 0.25, 10000) AS p25,
            percentile_approx(total_actions, 0.50, 10000) AS p50,
            percentile_approx(total_actions, 0.75, 10000) AS p75,
            percentile_approx(total_actions, 0.90, 10000) AS p90,
            percentile_approx(total_actions, 0.95, 10000) AS p95,
            percentile_approx(total_actions, 0.99, 10000) AS p99,
            percentile_approx(total_actions, 0.999, 10000) AS p999
        FROM user_stats
    """).collect()[0]
    act_quantiles = [
        quantiles_sql["p25"], quantiles_sql["p50"], quantiles_sql["p75"],
        quantiles_sql["p90"], quantiles_sql["p95"], quantiles_sql["p99"],
    ]
    # 额外记录 P99.9
    act_p999 = int(quantiles_sql["p999"]) if quantiles_sql["p999"] is not None else 0

    pur_q_sql = spark.sql("""
        SELECT
            percentile_approx(purchase_count, 0.25, 10000) AS p25,
            percentile_approx(purchase_count, 0.50, 10000) AS p50,
            percentile_approx(purchase_count, 0.75, 10000) AS p75,
            percentile_approx(purchase_count, 0.90, 10000) AS p90,
            percentile_approx(purchase_count, 0.95, 10000) AS p95,
            percentile_approx(purchase_count, 0.99, 10000) AS p99
        FROM user_stats
    """).collect()[0]
    pur_quantiles = [
        pur_q_sql["p25"], pur_q_sql["p50"], pur_q_sql["p75"],
        pur_q_sql["p90"], pur_q_sql["p95"], pur_q_sql["p99"],
    ]

    # Bot/爬虫检测：极端高活但零购买的用户
    total_records = METRICS["section1"]["log"]["total_records"]
    bot_stats = spark.sql("""
        SELECT
            COUNT(*) AS bot_users,
            SUM(total_actions) AS bot_actions,
            SUM(purchase_count) AS bot_purchases
        FROM user_stats
        WHERE total_actions > 10000 AND purchase_count <= 1
    """).collect()[0]

    # 用户分层
    user_segments = spark.sql("""
        SELECT
            CASE
                WHEN total_actions <= 10 THEN '1-10 (低活)'
                WHEN total_actions <= 50 THEN '11-50'
                WHEN total_actions <= 100 THEN '51-100'
                WHEN total_actions <= 500 THEN '101-500 (中活)'
                WHEN total_actions <= 1000 THEN '501-1000'
                ELSE '1000+ (高活)'
            END AS segment,
            COUNT(*) AS user_count,
            AVG(total_actions) AS avg_actions,
            AVG(purchase_count) AS avg_purchases,
            SUM(total_actions) AS total_actions_sum
        FROM user_stats
        GROUP BY segment
        ORDER BY MIN(total_actions)
    """).collect()

    s2["user_activity"] = {
        "total_actions_quantiles": {f"p{int(p*100)}": int(v) for p, v in zip([0.25, 0.5, 0.75, 0.9, 0.95, 0.99], act_quantiles)},
        "total_actions_p999": act_p999,
        "purchase_count_quantiles": {f"p{int(p*100)}": int(v) for p, v in zip([0.25, 0.5, 0.75, 0.9, 0.95, 0.99], pur_quantiles)},
        "segments": [
            {
                "segment": r["segment"],
                "user_count": int(r["user_count"]),
                "avg_actions": round(float(r["avg_actions"]), 1),
                "avg_purchases": round(float(r["avg_purchases"]), 2),
            }
            for r in user_segments
        ],
        "bot_detection": {
            "bot_users": int(bot_stats["bot_users"]),
            "bot_actions": int(bot_stats["bot_actions"]),
            "bot_actions_pct": round(float(bot_stats["bot_actions"]) / total * 100, 2),
            "bot_purchases": int(bot_stats["bot_purchases"]),
            "max_actions_single_user": int(user_activity.select(F.max("total_actions")).collect()[0][0]),
        },
    }

    # 活跃度分布图 - 使用 log-log 直方图
    act_sample = user_activity.select("total_actions").sample(0.1, seed=42).toPandas()
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    axes[0].hist(act_sample["total_actions"], bins=100, color="#4472C4", alpha=0.8, edgecolor="white")
    axes[0].set_xlabel("行为总数", fontsize=11)
    axes[0].set_ylabel("用户数", fontsize=11)
    axes[0].set_title("用户行为数分布", fontsize=12, fontweight="bold")

    axes[1].hist(act_sample["total_actions"], bins=np.logspace(0, 4, 80), color="#ED7D31", alpha=0.8, edgecolor="white")
    axes[1].set_xscale("log")
    axes[1].set_yscale("log")
    axes[1].set_xlabel("行为总数 (log)", fontsize=11)
    axes[1].set_ylabel("用户数 (log)", fontsize=11)
    axes[1].set_title("用户行为数分布 (log-log)", fontsize=12, fontweight="bold")
    save_chart(fig, "user_activity_dist.png")

    log(f"  用户活跃度分析完成, 耗时 {time.time() - t0:.0f}s")

    # ── 2.4 商品热度长尾分析 ──
    log("2.4 商品热度长尾分析...")
    t0 = time.time()

    item_pop = spark.sql("""
        SELECT
            item_id,
            COUNT(*) AS total_interactions,
            SUM(CASE WHEN action = 'alipay' THEN 1 ELSE 0 END) AS sales
        FROM log
        GROUP BY item_id
    """).cache()
    item_pop.createOrReplaceTempView("item_pop")

    # 按交互量排序，计算累计占比
    item_pop_pd = item_pop.orderBy(F.desc("total_interactions")).toPandas()
    item_pop_pd["cumsum_interactions"] = item_pop_pd["total_interactions"].cumsum()
    item_pop_pd["cumsum_sales"] = item_pop_pd["sales"].cumsum()
    total_inter = item_pop_pd["total_interactions"].sum()
    total_sales = item_pop_pd["sales"].sum()
    item_pop_pd["cum_pct_inter"] = item_pop_pd["cumsum_interactions"] / total_inter * 100
    item_pop_pd["cum_pct_sales"] = item_pop_pd["cumsum_sales"] / total_sales * 100
    item_pop_pd["item_pct"] = (np.arange(len(item_pop_pd)) + 1) / len(item_pop_pd) * 100

    # 头部/腰部/尾部划分
    def classify_head(row):
        if row["cum_pct_inter"] <= 50:
            return "头部爆品 (Top 50% 流量)"
        elif row["cum_pct_inter"] <= 80:
            return "腰部商品 (50-80% 流量)"
        else:
            return "尾部长尾 (80-100% 流量)"

    item_pop_pd["tier"] = item_pop_pd.apply(classify_head, axis=1)
    tier_summary = item_pop_pd.groupby("tier").agg(
        item_count=("item_id", "count"),
        interactions=("total_interactions", "sum"),
        sales=("sales", "sum"),
    ).reset_index()
    tier_summary["item_pct"] = tier_summary["item_count"] / len(item_pop_pd) * 100
    tier_summary["interaction_pct"] = tier_summary["interactions"] / total_inter * 100
    tier_summary["sales_pct"] = tier_summary["sales"] / total_sales * 100

    s2["product_longtail"] = {
        "total_items_with_interactions": len(item_pop_pd),
        "tiers": [
            {
                "tier": r["tier"],
                "item_count": int(r["item_count"]),
                "item_pct": round(float(r["item_pct"]), 2),
                "interaction_pct": round(float(r["interaction_pct"]), 2),
                "sales_pct": round(float(r["sales_pct"]), 2),
            }
            for _, r in tier_summary.iterrows()
        ],
    }

    # 长尾图
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(item_pop_pd["item_pct"].values[::100], item_pop_pd["cum_pct_inter"].values[::100],
            linewidth=2, color="#4472C4", label="累计交互量")
    ax.plot(item_pop_pd["item_pct"].values[::100], item_pop_pd["cum_pct_sales"].values[::100],
            linewidth=2, color="#ED7D31", label="累计销量")
    ax.axhline(50, color="gray", linestyle="--", alpha=0.5)
    ax.axhline(80, color="gray", linestyle="--", alpha=0.5)
    ax.axvline(item_pop_pd[item_pop_pd["cum_pct_inter"] <= 50]["item_pct"].max(),
               color="gray", linestyle="--", alpha=0.5)
    ax.fill_between([0, item_pop_pd[item_pop_pd["cum_pct_inter"] <= 50]["item_pct"].max()],
                    0, 100, alpha=0.05, color="green", label="头部区域")
    ax.set_xlabel("商品累计占比 (%)", fontsize=11)
    ax.set_ylabel("累计贡献占比 (%)", fontsize=11)
    ax.set_title("商品热度长尾分布 (Lorenz曲线)", fontsize=13, fontweight="bold")
    ax.legend(loc="lower right")
    save_chart(fig, "product_longtail.png")

    log(f"  长尾分析完成, 耗时 {time.time() - t0:.0f}s")

    # 释放缓存
    user_activity.unpersist()

    METRICS["section2"] = s2
    return s2, item_pop  # 返回 item_pop 供后续使用


# ================================================================
# 第 2 部分（续）：商品维度集中度
# ================================================================
def section2b_concentration(spark, item_pop):
    log("2.5 商品维度集中度分析...")
    t0 = time.time()

    s2b = OrderedDict()

    # ── 2.5a 类目规模分布 ──
    log("  2.5a 类目规模分布...")
    cat_stats = spark.sql("""
        WITH cat_interactions AS (
            SELECT
                p.category,
                CAST(SPLIT(p.category, '-')[0] AS INT) AS parent_cat,
                CAST(SPLIT(p.category, '-')[1] AS INT) AS leaf_cat,
                COALESCE(ip.total_interactions, 0) AS total_interactions,
                COALESCE(ip.sales, 0) AS sales
            FROM product p
            LEFT JOIN item_pop ip ON p.item_id = ip.item_id
        )
        SELECT
            parent_cat,
            COUNT(*) AS item_count,
            SUM(total_interactions) AS total_interactions,
            SUM(sales) AS total_sales
        FROM cat_interactions
        GROUP BY parent_cat
        ORDER BY total_interactions DESC
    """).toPandas()

    s2b["category_stats"] = {
        "top20_parent_categories": [
            {
                "parent_cat": int(r["parent_cat"]),
                "item_count": int(r["item_count"]),
                "total_interactions": int(r["total_interactions"]),
                "total_sales": int(r["total_sales"]),
            }
            for _, r in cat_stats.head(20).iterrows()
        ],
        "total_parent_cats": len(cat_stats),
    }

    # 类目 Top20 图
    fig, ax = plt.subplots(figsize=(12, 6))
    top20 = cat_stats.head(20)
    ax.barh(range(20), top20["total_interactions"].values / 1e6, color="#4472C4", alpha=0.8)
    ax.set_yticks(range(20))
    ax.set_yticklabels([f"类目{int(c)}" for c in top20["parent_cat"]])
    ax.set_xlabel("交互量 (百万)", fontsize=11)
    ax.set_title("Top 20 父类目交互量", fontsize=13, fontweight="bold")
    ax.invert_yaxis()
    save_chart(fig, "category_top20.png")

    # ── 2.5b 品牌与卖家集中度 ──
    log("  2.5b 品牌与卖家集中度...")

    # 品牌集中度
    brand_stats = spark.sql("""
        SELECT
            p.brand_id,
            COUNT(DISTINCT p.item_id) AS item_count,
            COALESCE(SUM(ip.total_interactions), 0) AS total_interactions,
            COALESCE(SUM(ip.sales), 0) AS total_sales
        FROM product p
        LEFT JOIN item_pop ip ON p.item_id = ip.item_id
        WHERE p.brand_id IS NOT NULL
        GROUP BY p.brand_id
        ORDER BY total_interactions DESC
    """).toPandas()

    total_brand_inter = brand_stats["total_interactions"].sum()
    total_brand_sales = brand_stats["total_sales"].sum()
    total_brands = len(brand_stats)

    def calc_cr(df, col, total, n):
        df_sorted = df.sort_values(col, ascending=False)
        return round(df_sorted.head(n)[col].sum() / total * 100, 2)

    brand_cr = {}
    for n_label, n in [("CR5", 5), ("CR10", 10), ("CR20", 20)]:
        brand_cr[f"brand_{n_label}_interaction"] = calc_cr(brand_stats, "total_interactions", total_brand_inter, n)
        brand_cr[f"brand_{n_label}_sales"] = calc_cr(brand_stats, "total_sales", total_brand_sales, n)

    # 卖家集中度
    seller_stats = spark.sql("""
        SELECT
            p.seller_id,
            COUNT(DISTINCT p.item_id) AS item_count,
            COALESCE(SUM(ip.total_interactions), 0) AS total_interactions,
            COALESCE(SUM(ip.sales), 0) AS total_sales
        FROM product p
        LEFT JOIN item_pop ip ON p.item_id = ip.item_id
        GROUP BY p.seller_id
        ORDER BY total_interactions DESC
    """).toPandas()

    total_seller_inter = seller_stats["total_interactions"].sum()
    total_seller_sales = seller_stats["total_sales"].sum()

    for n_label, n in [("CR5", 5), ("CR10", 10), ("CR20", 20)]:
        brand_cr[f"seller_{n_label}_interaction"] = calc_cr(seller_stats, "total_interactions", total_seller_inter, n)
        brand_cr[f"seller_{n_label}_sales"] = calc_cr(seller_stats, "total_sales", total_seller_sales, n)

    s2b["concentration"] = {
        "total_brands": total_brands,
        "total_sellers": int(seller_stats["seller_id"].nunique()),
        **brand_cr,
    }

    # 集中度柱状图
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    cr_labels = ["CR5", "CR10", "CR20"]
    for ax_i, (dim, title) in enumerate([("brand", "品牌"), ("seller", "卖家")]):
        inter_vals = [brand_cr[f"{dim}_{l}_interaction"] for l in cr_labels]
        sales_vals = [brand_cr[f"{dim}_{l}_sales"] for l in cr_labels]
        x = np.arange(len(cr_labels))
        w = 0.35
        axes[ax_i].bar(x - w/2, inter_vals, w, label="流量占比", color="#4472C4")
        axes[ax_i].bar(x + w/2, sales_vals, w, label="销量占比", color="#ED7D31")
        axes[ax_i].set_xticks(x)
        axes[ax_i].set_xticklabels(cr_labels)
        axes[ax_i].set_ylabel("占比 (%)", fontsize=11)
        axes[ax_i].set_title(f"{title}集中度", fontsize=12, fontweight="bold")
        axes[ax_i].legend()
    save_chart(fig, "concentration_cr.png")

    # 品牌分布曲线
    fig, ax = plt.subplots(figsize=(10, 5))
    brand_sorted = brand_stats["total_interactions"].sort_values(ascending=False).values
    cumsum = np.cumsum(brand_sorted) / brand_sorted.sum() * 100
    ax.plot(np.arange(1, len(cumsum)+1) / len(cumsum) * 100, cumsum, linewidth=2, color="#4472C4")
    ax.plot([0, 100], [0, 100], "k--", alpha=0.3, linewidth=1)
    ax.set_xlabel("品牌累计占比 (%)", fontsize=11)
    ax.set_ylabel("流量累计占比 (%)", fontsize=11)
    ax.set_title("品牌流量集中度曲线 (Lorenz)", fontsize=13, fontweight="bold")
    save_chart(fig, "brand_lorenz.png")

    log(f"  集中度分析完成, 耗时 {time.time() - t0:.0f}s")

    METRICS["section2b"] = s2b
    return s2b


# ================================================================
# 第 2 部分（续）：评论数据分布
# ================================================================
def section2c_review_distribution(spark):
    log("2.6 评论数据分布分析...")
    t0 = time.time()

    s2c = OrderedDict()

    # 评论覆盖率
    prod_total = METRICS["section1"]["product"]["total_records"]
    rev_items = METRICS["section1"]["review"]["distinct_items"]
    rev_item_coverage = rev_items / prod_total * 100

    # 有购买行为的用户数（用于计算评论覆盖率分母）
    purchase_users = spark.sql("""
        SELECT COUNT(DISTINCT user_id) AS cnt
        FROM log
        WHERE action = 'alipay'
    """).collect()[0]["cnt"]

    rev_users = METRICS["section1"]["review"]["distinct_users"]
    log_users = METRICS["section1"]["log"]["distinct_users"]
    # 评论用户可能包含日志时间窗口外的历史购买用户
    # 因此在日志窗口内的覆盖率按购买用户算，全域覆盖率按总交互用户算
    review_users_in_purchase_window = spark.sql("""
        SELECT COUNT(DISTINCT r.user_id) AS cnt
        FROM review r
        INNER JOIN (SELECT DISTINCT user_id FROM log WHERE action = 'alipay') p
        ON r.user_id = p.user_id
    """).collect()[0]["cnt"]
    review_users_not_in_purchase = rev_users - review_users_in_purchase_window
    review_user_coverage_in_window = review_users_in_purchase_window / purchase_users * 100 if purchase_users > 0 else 0

    s2c["review_coverage"] = {
        "items_with_reviews": rev_items,
        "total_items": prod_total,
        "item_review_coverage_pct": round(rev_item_coverage, 2),
        "users_with_reviews": rev_users,
        "users_with_purchases": purchase_users,
        "review_users_in_purchase_window": review_users_in_purchase_window,
        "review_users_not_in_purchase_window": review_users_not_in_purchase,
        "user_review_coverage_window_pct": round(review_user_coverage_in_window, 2),
    }

    # 单商品评论数分布
    review_per_item = spark.sql("""
        SELECT
            item_id,
            COUNT(*) AS review_count
        FROM review
        GROUP BY item_id
    """).cache()
    review_per_item.createOrReplaceTempView("review_per_item")

    rpi_quantiles = review_per_item.approxQuantile("review_count", [0.25, 0.5, 0.75, 0.9, 0.95, 0.99], 0.01)
    rpi_segments = spark.sql("""
        SELECT
            CASE
                WHEN review_count = 1 THEN '1条'
                WHEN review_count <= 3 THEN '2-3条'
                WHEN review_count <= 10 THEN '4-10条'
                WHEN review_count <= 50 THEN '11-50条'
                ELSE '50+条'
            END AS segment,
            COUNT(*) AS item_count
        FROM review_per_item
        GROUP BY segment
        ORDER BY MIN(review_count)
    """).collect()

    # 单用户评论数分布
    review_per_user = spark.sql("""
        SELECT
            user_id,
            COUNT(*) AS review_count
        FROM review
        GROUP BY user_id
    """).cache()
    review_per_user.createOrReplaceTempView("review_per_user")

    rpu_quantiles = review_per_user.approxQuantile("review_count", [0.25, 0.5, 0.75, 0.9, 0.95, 0.99], 0.01)
    rpu_segments = spark.sql("""
        SELECT
            CASE
                WHEN review_count = 1 THEN '1条'
                WHEN review_count <= 3 THEN '2-3条'
                WHEN review_count <= 10 THEN '4-10条'
                WHEN review_count <= 50 THEN '11-50条'
                ELSE '50+条'
            END AS segment,
            COUNT(*) AS user_count
        FROM review_per_user
        GROUP BY segment
        ORDER BY MIN(review_count)
    """).collect()

    s2c["review_distribution"] = {
        "per_item_quantiles": {f"p{int(p*100)}": int(v) for p, v in zip([0.25, 0.5, 0.75, 0.9, 0.95, 0.99], rpi_quantiles)},
        "per_user_quantiles": {f"p{int(p*100)}": int(v) for p, v in zip([0.25, 0.5, 0.75, 0.9, 0.95, 0.99], rpu_quantiles)},
        "per_item_segments": [{"segment": r["segment"], "item_count": int(r["item_count"])} for r in rpi_segments],
        "per_user_segments": [{"segment": r["segment"], "user_count": int(r["user_count"])} for r in rpu_segments],
    }

    # 评论分布图
    rpi_sample = review_per_item.sample(0.1, seed=42).toPandas()
    rpu_sample = review_per_user.sample(0.1, seed=42).toPandas()

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    axes[0].hist(rpi_sample["review_count"], bins=50, color="#4472C4", alpha=0.8, edgecolor="white")
    axes[0].set_xlabel("评论数", fontsize=11)
    axes[0].set_ylabel("商品数", fontsize=11)
    axes[0].set_title("单商品评论数分布", fontsize=12, fontweight="bold")

    axes[1].hist(rpu_sample["review_count"], bins=50, color="#ED7D31", alpha=0.8, edgecolor="white")
    axes[1].set_xlabel("评论数", fontsize=11)
    axes[1].set_ylabel("用户数", fontsize=11)
    axes[1].set_title("单用户评论数分布", fontsize=12, fontweight="bold")
    save_chart(fig, "review_distribution.png")

    log(f"  评论分布分析完成, 耗时 {time.time() - t0:.0f}s")

    review_per_item.unpersist()
    review_per_user.unpersist()

    METRICS["section2c"] = s2c
    return s2c


# ================================================================
# 第 3 部分：全局核心业务指标基线
# ================================================================
def section3_business_metrics(spark):
    log("=" * 60)
    log("第 3 部分：全局核心业务指标基线计算")
    log("=" * 60)

    s3 = OrderedDict()
    t0 = time.time()

    # 从已计算的 section1 获取基础数据
    s1 = METRICS["section1"]
    total = s1["log"]["total_records"]
    distinct_users = s1["log"]["distinct_users"]
    distinct_items = s1["log"]["distinct_items"]
    action_breakdown = s1["log"]["action_breakdown"]

    click = action_breakdown.get("click", 0)
    collect = action_breakdown.get("collect", 0)
    cart = action_breakdown.get("cart", 0)
    alipay = action_breakdown.get("alipay", 0)
    product_total = s1["product"]["total_records"]

    # ── 3.1 转化率指标 ──
    conv_rates = {
        "click_to_collect_rate_pct": round(collect / click * 100, 4),
        "click_to_cart_rate_pct": round(cart / click * 100, 4),
        "click_to_purchase_rate_pct": round(alipay / click * 100, 4),
        "cart_to_purchase_rate_pct": round(alipay / cart * 100, 2) if cart > 0 else 0,
        "collect_to_purchase_rate_pct": round(alipay / collect * 100, 2) if collect > 0 else 0,
    }
    s3["conversion_rates"] = conv_rates

    # ── 3.2 用户行为类指标 ──
    purchase_users_cnt = spark.sql("""
        SELECT COUNT(DISTINCT user_id) AS cnt FROM log WHERE action = 'alipay'
    """).collect()[0]["cnt"]

    repeat_purchase_users = spark.sql("""
        SELECT COUNT(DISTINCT user_id) AS cnt
        FROM (
            SELECT user_id, COUNT(*) AS purchase_cnt
            FROM log WHERE action = 'alipay'
            GROUP BY user_id
            HAVING COUNT(*) >= 2
        )
    """).collect()[0]["cnt"]

    user_metrics = {
        "avg_actions_per_user": round(total / distinct_users, 2),
        "avg_clicks_per_user": round(click / distinct_users, 2),
        "avg_collects_per_user": round(collect / distinct_users, 2),
        "avg_carts_per_user": round(cart / distinct_users, 2),
        "avg_purchases_per_user": round(alipay / distinct_users, 2),
        "user_purchase_rate_pct": round(purchase_users_cnt / distinct_users * 100, 2),
        "user_repurchase_rate_pct": round(repeat_purchase_users / purchase_users_cnt * 100, 2) if purchase_users_cnt > 0 else 0,
        "total_users": distinct_users,
        "purchase_users": purchase_users_cnt,
        "repeat_purchase_users": repeat_purchase_users,
    }
    s3["user_metrics"] = user_metrics

    # ── 3.3 商品运营类指标 ──
    items_with_sales = spark.sql("""
        SELECT COUNT(DISTINCT item_id) AS cnt FROM log WHERE action = 'alipay'
    """).collect()[0]["cnt"]

    product_metrics = {
        "avg_interactions_per_item": round(total / distinct_items, 2),
        "item_sales_rate_pct": round(items_with_sales / product_total * 100, 2),
        "avg_sales_per_active_item": round(alipay / items_with_sales, 2) if items_with_sales > 0 else 0,
        "total_items": product_total,
        "items_with_interactions": distinct_items,
        "items_with_sales": items_with_sales,
    }
    s3["product_metrics"] = product_metrics

    # ── 3.4 综合转化漏斗图 ──
    fig, ax = plt.subplots(figsize=(10, 6))
    funnel_stages = ["点击\n(Click)", "收藏\n(Collect)", "加购\n(Cart)", "购买\n(Alipay)"]
    funnel_values = [click, collect, cart, alipay]
    funnel_colors = ["#4472C4", "#A5A5A5", "#ED7D31", "#FFC000"]
    max_val = funnel_values[0]

    for i, (stage, val, color) in enumerate(zip(funnel_stages, funnel_values, funnel_colors)):
        width = val / max_val
        left = (1 - width) / 2
        ax.barh(i, width, left=left, height=0.6, color=color, alpha=0.85, edgecolor="white")
        ax.text(0.5, i, f"{stage}\n{val:,} ({val/click*100:.2f}%)",
                ha="center", va="center", fontsize=11, fontweight="bold", color="white")
    ax.set_yticks([])
    ax.set_xlim(0, 1)
    ax.set_title("用户行为转化漏斗", fontsize=14, fontweight="bold")
    ax.axis("off")
    save_chart(fig, "conversion_funnel.png")

    log(f"  点击→购买转化率: {conv_rates['click_to_purchase_rate_pct']}%")
    log(f"  加购→购买转化率: {conv_rates['cart_to_purchase_rate_pct']}%")
    log(f"  用户购买率: {user_metrics['user_purchase_rate_pct']}%")
    log(f"  用户复购率: {user_metrics['user_repurchase_rate_pct']}%")
    log(f"  商品动销率: {product_metrics['item_sales_rate_pct']}%")
    log(f"  耗时 {time.time() - t0:.0f}s")

    METRICS["section3"] = s3
    return s3


# ================================================================
# 第 4 部分：跨表关联关系验证
# ================================================================
def section4_cross_table_validation(spark):
    log("=" * 60)
    log("第 4 部分：跨表关联关系验证")
    log("=" * 60)

    s4 = OrderedDict()
    t0 = time.time()

    # ── 4.1 日志表 ↔ 商品表 ──
    log("4.1 日志表 ↔ 商品表 ID 关联覆盖率...")
    log_items = spark.sql("SELECT DISTINCT item_id FROM log").cache()
    log_items.createOrReplaceTempView("log_items")
    product_items = spark.sql("SELECT DISTINCT item_id FROM product").cache()
    product_items.createOrReplaceTempView("product_items")

    # 全行为覆盖率
    log_total_items = log_items.count()
    matched_all = spark.sql("""
        SELECT COUNT(DISTINCT l.item_id) AS cnt
        FROM log_items l
        INNER JOIN product_items p ON l.item_id = p.item_id
    """).collect()[0]["cnt"]
    coverage_all = matched_all / log_total_items * 100 if log_total_items > 0 else 0

    # 购买行为覆盖率
    purchase_items = spark.sql("""
        SELECT DISTINCT item_id FROM log WHERE action = 'alipay'
    """).cache()
    purchase_items_count = purchase_items.count()
    matched_purchase = spark.sql("""
        SELECT COUNT(DISTINCT l.item_id) AS cnt
        FROM (
            SELECT DISTINCT item_id FROM log WHERE action = 'alipay'
        ) l
        INNER JOIN product_items p ON l.item_id = p.item_id
    """).collect()[0]["cnt"]
    coverage_purchase = matched_purchase / purchase_items_count * 100 if purchase_items_count > 0 else 0

    s4["log_to_product"] = {
        "log_distinct_items": log_total_items,
        "matched_items": matched_all,
        "coverage_all_actions_pct": round(coverage_all, 2),
        "purchase_items": purchase_items_count,
        "purchase_matched": matched_purchase,
        "coverage_purchase_pct": round(coverage_purchase, 2),
        "unmatched_items": log_total_items - matched_all,
    }

    # ── 4.2 评论表 ↔ 商品表 ──
    log("4.2 评论表 ↔ 商品表 ID 关联覆盖率...")
    review_items_count = METRICS["section1"]["review"]["distinct_items"]
    matched_review = spark.sql("""
        SELECT COUNT(DISTINCT r.item_id) AS cnt
        FROM (SELECT DISTINCT item_id FROM review) r
        INNER JOIN product_items p ON r.item_id = p.item_id
    """).collect()[0]["cnt"]
    coverage_review = matched_review / review_items_count * 100 if review_items_count > 0 else 0

    s4["review_to_product"] = {
        "review_distinct_items": review_items_count,
        "matched_items": matched_review,
        "coverage_pct": round(coverage_review, 2),
        "unmatched_items": review_items_count - matched_review,
    }

    # ── 4.3 评论表 ↔ 日志表 (user_id + item_id 对) ──
    log("4.3 评论表 ↔ 日志表 (用户+商品对) 关联覆盖率...")
    review_pairs = spark.sql("""
        SELECT COUNT(DISTINCT CONCAT(user_id, '_', item_id)) AS cnt
        FROM review
    """).collect()[0]["cnt"]

    matched_pairs = spark.sql("""
        SELECT COUNT(DISTINCT CONCAT(r.user_id, '_', r.item_id)) AS cnt
        FROM review r
        INNER JOIN (
            SELECT DISTINCT user_id, item_id FROM log WHERE action = 'alipay'
        ) l ON r.user_id = l.user_id AND r.item_id = l.item_id
    """).collect()[0]["cnt"]
    coverage_pairs = matched_pairs / review_pairs * 100 if review_pairs > 0 else 0

    s4["review_to_log"] = {
        "review_distinct_user_item_pairs": review_pairs,
        "matched_purchase_pairs": matched_pairs,
        "coverage_pct": round(coverage_pairs, 2),
        "unmatched_pairs": review_pairs - matched_pairs,
    }

    # ── 汇总 ──
    s4["summary"] = {
        "log_product_coverage_all": s4["log_to_product"]["coverage_all_actions_pct"],
        "log_product_coverage_purchase": s4["log_to_product"]["coverage_purchase_pct"],
        "review_product_coverage": s4["review_to_product"]["coverage_pct"],
        "review_log_purchase_pair_coverage": s4["review_to_log"]["coverage_pct"],
    }

    log(f"  日志→商品: 全行为 {coverage_all:.2f}% | 购买 {coverage_purchase:.2f}%")
    log(f"  评论→商品: {coverage_review:.2f}%")
    log(f"  评论→购买日志(user+item): {coverage_pairs:.2f}%")
    log(f"  耗时 {time.time() - t0:.0f}s")

    # 释放缓存
    log_items.unpersist()
    product_items.unpersist()
    purchase_items.unpersist()

    METRICS["section4"] = s4
    return s4


# ================================================================
# 报告生成
# ================================================================
def generate_report():
    log("生成综合报告...")
    s1 = METRICS["section1"]
    s1b = METRICS["section1b"]
    s2 = METRICS["section2"]
    s2b = METRICS["section2b"]
    s2c = METRICS["section2c"]
    s3 = METRICS["section3"]
    s4 = METRICS["section4"]

    md = []

    def w(line=""):
        md.append(line)

    w("# Rec-Tmall 全局探索性数据分析报告")
    w()
    w(f"**生成时间**: {RUN_START}")
    w(f"**数据时间范围**: 2013-04-01 ~ 2013-10-01")
    w(f"**数据来源**: 天池 Rec-Tmall 推荐数据集 (清洗后 Parquet)")
    w()

    # ── 1. 数据规模概览 ──
    w("---")
    w("## 一、数据规模概览")
    w()
    w("### 1.1 三表全量体量")
    w()
    w("| 指标 | 用户行为日志表 | 商品属性表 | 用户评论表 |")
    w("|------|:-----------:|:--------:|:--------:|")
    w(f"| 总记录数 | **{s1['log']['total_records']:,}** | **{s1['product']['total_records']:,}** | **{s1['review']['total_records']:,}** |")
    w(f"| 去重用户数 | {s1['log']['distinct_users']:,} | — | {s1['review']['distinct_users']:,} |")
    w(f"| 去重商品数 | {s1['log']['distinct_items']:,} | {s1['product']['distinct_items']:,} | {s1['review']['distinct_items']:,} |")
    w(f"| 行为/类目/品牌数 | {s1['log']['action_types']} 种行为 | {s1['product']['distinct_categories']:,} 个类目 | — |")
    w(f"| 品牌数 | — | {s1['product']['distinct_brands']:,} | — |")
    w(f"| 卖家数 | — | {s1['product']['distinct_sellers']:,} | — |")
    w()

    w("### 1.2 官方数据交叉校验")
    w()
    w("| 表 | 清洗后行数 | 官方标注 | 偏差 | 偏差率 |")
    w("|----|----------:|--------:|----:|------:|")
    w(f"| product | {s1['product']['total_records']:,} | {s1['product']['official_count']:,} | {s1['product']['total_records'] - s1['product']['official_count']:,} | {s1['product']['official_diff_pct']}% |")
    w(f"| log | {s1['log']['total_records']:,} | {s1['log']['official_count']:,} | {s1['log']['total_records'] - s1['log']['official_count']:,} | {s1['log']['official_diff_pct']}% |")
    w(f"| review | {s1['review']['total_records']:,} | {s1['review']['official_count']:,} | {s1['review']['total_records'] - s1['review']['official_count']:,} | {s1['review']['official_diff_pct']}% |")
    w()

    w("### 1.3 类目层级概览")
    w()
    w(f"- **父类目总数**: {s1['category_hierarchy']['total_parent_categories']}")
    w(f"- **叶子类目总数**: {s1['product']['distinct_leaf_categories']:,}")
    w()
    w("**Top 10 父类目（按商品数）**:")
    w()
    w("| 排名 | 父类目 ID | 叶子类目数 | 商品数 |")
    w("|:----:|:---------:|:---------:|------:|")
    for i, cat in enumerate(s1["category_hierarchy"]["parent_categories"][:10]):
        w(f"| {i+1} | {cat['parent_cat']} | {cat['leaf_cat_count']} | {cat['product_count']:,} |")
    w()

    # ── 1.4 稀疏性 ──
    w("### 1.4 数据稀疏性评估")
    w()
    sp = s1b["sparsity"]
    w(f"- **用户-商品交互矩阵**: {sp['user_item_matrix_possible_pairs']:.2e} 个可能交互对，实际 {sp['user_item_matrix_actual_interactions']:,} 条记录")
    w(f"- **交互矩阵稀疏度**: {sp['user_item_matrix_sparsity_pct']:.4f}% （密度仅 {100 - sp['user_item_matrix_sparsity_pct']:.4f}%）")
    w(f"- **评论矩阵稀疏度**: {sp['review_sparsity_pct']:.4f}%")
    w(f"- **商品覆盖率**: {sp['item_coverage_pct']:.2f}% 的商品有至少一次交互")
    w(f"- **人均交互**: {sp['avg_interactions_per_user']:.2f} 次/人")
    w(f"- **品均交互**: {sp['avg_interactions_per_item']:.2f} 次/品")
    w()
    w("> **结论**: 数据极度稀疏，典型的长尾分布，推荐算法需重点考虑稀疏性处理（如 Embedding、矩阵分解）。")
    w()

    # ── 2. 核心维度分布 ──
    w("---")
    w("## 二、核心维度分布分析")
    w()

    w("### 2.1 行为结构")
    w()
    action_s = s2["action_structure"]
    w("| 行为类型 | 数量 | 占比 |")
    w("|---------|----:|-----:|")
    for act in ["click", "cart", "collect", "alipay"]:
        if act in action_s["breakdown"]:
            d = action_s["breakdown"][act]
            w(f"| {act} | {d['count']:,} | {d['ratio_pct']}% |")
    w()
    w("**全链路转化率**:")
    w()
    w(f"| 转化路径 | 转化率 |")
    w(f"|----------|------:|")
    w(f"| 点击 → 收藏 | {action_s['click_to_collect_rate']}% |")
    w(f"| 点击 → 加购 | {action_s['click_to_cart_rate']}% |")
    w(f"| 点击 → 购买 | {action_s['click_to_alipay_rate']}% |")
    w(f"| 加购 → 购买 | {action_s['cart_to_alipay_rate']}% |")
    w()
    w("![行为饼图](charts/action_pie.png)")
    w("![转化漏斗](charts/conversion_funnel.png)")
    w()

    w("### 2.2 多粒度时间分布")
    w()
    daily = s2["daily_distribution"]
    w(f"- **时间跨度**: {daily['date_range_start']} ~ {daily['date_range_end']} ({daily['total_days']} 天)")
    w(f"- **日均行为量**: {daily['daily_avg']:,.0f} ± {daily['daily_std']:,.0f}")
    w(f"- **最高峰**: {daily['daily_max_date']} ({daily['daily_max']:,})")
    w(f"- **最低谷**: {daily['daily_min_date']} ({daily['daily_min']:,})")
    w()
    w("![小时分布](charts/hourly_pattern.png)")
    w("![日趋势](charts/daily_trend.png)")
    w("![周分布](charts/weekly_pattern.png)")
    w()

    w("### 2.3 用户活跃度分布")
    w()
    ua = s2["user_activity"]
    w("**行为总数分位数**:")
    w(f"| P25 | P50 | P75 | P90 | P95 | P99 | P99.9 |")
    w(f"|----:|----:|----:|----:|----:|----:|------:|")
    w(f"| {ua['total_actions_quantiles']['p25']:,} | {ua['total_actions_quantiles']['p50']:,} | {ua['total_actions_quantiles']['p75']:,} | {ua['total_actions_quantiles']['p90']:,} | {ua['total_actions_quantiles']['p95']:,} | {ua['total_actions_quantiles']['p99']:,} | {ua['total_actions_p999']:,} |")
    w()

    # Bot detection note
    bot = ua["bot_detection"]
    w(f"> ⚠️ **数据质量提示**: 检测到 **{bot['bot_users']:,}** 个疑似爬虫/bot 账号（行为数 > 10,000 且购买数 ≤ 1），")
    w(f"> 共贡献 {bot['bot_actions']:,} 次行为（占全量 {bot['bot_actions_pct']}%），0 次有效购买。")
    w(f"> 单用户最高行为数 {bot['max_actions_single_user']:,}（零购买），建议在下游推荐模型训练中剔除。")
    w()
    w("**用户活跃度分层**:")
    w()
    w("| 行为区间 | 用户数 | 占比 | 人均行为 | 人均购买 |")
    w("|---------|------:|-----:|--------:|--------:|")
    for seg in ua["segments"]:
        total_u = ua["segments"][-1]["user_count"]  # total users
        pct = seg["user_count"] / sum(s["user_count"] for s in ua["segments"]) * 100
        w(f"| {seg['segment']} | {seg['user_count']:,} | {pct:.1f}% | {seg['avg_actions']} | {seg['avg_purchases']} |")
    w()
    w("![用户活跃度](charts/user_activity_dist.png)")
    w()

    w("### 2.4 商品热度长尾")
    w()
    lt = s2["product_longtail"]
    w(f"**有交互商品总数**: {lt['total_items_with_interactions']:,}")
    w()
    w("| 分层 | 商品数 | 商品占比 | 交互量占比 | 销量占比 |")
    w("|------|------:|--------:|---------:|--------:|")
    for t in lt["tiers"]:
        w(f"| {t['tier']} | {t['item_count']:,} | {t['item_pct']}% | {t['interaction_pct']}% | {t['sales_pct']}% |")
    w()
    w("![长尾分布](charts/product_longtail.png)")
    w()

    w("### 2.5 品牌与卖家集中度")
    w()
    conc = s2b["concentration"]
    w(f"- 总品牌数: {conc['total_brands']:,} | 总卖家数: {conc['total_sellers']:,}")
    w()
    w("| 维度 | CR5 | CR10 | CR20 |")
    w("|------|----:|-----:|-----:|")
    w(f"| 品牌流量 | {conc['brand_CR5_interaction']}% | {conc['brand_CR10_interaction']}% | {conc['brand_CR20_interaction']}% |")
    w(f"| 品牌销量 | {conc['brand_CR5_sales']}% | {conc['brand_CR10_sales']}% | {conc['brand_CR20_sales']}% |")
    w(f"| 卖家流量 | {conc['seller_CR5_interaction']}% | {conc['seller_CR10_interaction']}% | {conc['seller_CR20_interaction']}% |")
    w(f"| 卖家销量 | {conc['seller_CR5_sales']}% | {conc['seller_CR10_sales']}% | {conc['seller_CR20_sales']}% |")
    w()
    w("![集中度](charts/concentration_cr.png)")
    w("![品牌Lorenz](charts/brand_lorenz.png)")
    w()

    w("### 2.6 评论数据分布")
    w()
    rc = s2c["review_coverage"]
    w(f"- **商品评论覆盖率**: {rc['item_review_coverage_pct']}% ({rc['items_with_reviews']:,} / {rc['total_items']:,})")
    w(f"- **评论用户总量**: {rc['users_with_reviews']:,} 人")
    w(f"- **日志窗口内评论覆盖率**: {rc['user_review_coverage_window_pct']}% ({rc['review_users_in_purchase_window']:,} / {rc['users_with_purchases']:,} 购买用户)")
    w(f"- **日志窗口外评论用户**: {rc['review_users_not_in_purchase_window']:,} 人（评论日期早于日志追踪起始日，属历史存量评论）")
    w()
    w("![评论分布](charts/review_distribution.png)")
    w()

    # ── 3. 核心业务指标 ──
    w("---")
    w("## 三、全局核心业务指标基线")
    w()

    w("### 3.1 转化漏斗")
    w()
    cr = s3["conversion_rates"]
    um = s3["user_metrics"]
    pm = s3["product_metrics"]
    w("| 指标 | 数值 | 计算口径 |")
    w("|------|----:|---------|")
    w(f"| 点击→收藏转化率 | {cr['click_to_collect_rate_pct']}% | collect / click |")
    w(f"| 点击→加购转化率 | {cr['click_to_cart_rate_pct']}% | cart / click |")
    w(f"| 点击→购买转化率 | {cr['click_to_purchase_rate_pct']}% | alipay / click |")
    w(f"| 加购→购买转化率 | {cr['cart_to_purchase_rate_pct']}% | alipay / cart |")
    w(f"| 收藏→购买转化率 | {cr['collect_to_purchase_rate_pct']}% | alipay / collect |")
    w()

    w("### 3.2 用户行为指标")
    w()
    w("| 指标 | 数值 |")
    w("|------|----:|")
    w(f"| 人均总行为数 | {um['avg_actions_per_user']} |")
    w(f"| 人均点击数 | {um['avg_clicks_per_user']} |")
    w(f"| 人均收藏数 | {um['avg_collects_per_user']} |")
    w(f"| 人均加购数 | {um['avg_carts_per_user']} |")
    w(f"| 人均购买数 | {um['avg_purchases_per_user']} |")
    w(f"| 用户购买率 | {um['user_purchase_rate_pct']}% |")
    w(f"| 用户复购率 | {um['user_repurchase_rate_pct']}% |")
    w()

    w("### 3.3 商品运营指标")
    w()
    w("| 指标 | 数值 |")
    w("|------|----:|")
    w(f"| 单品平均交互量 | {pm['avg_interactions_per_item']} |")
    w(f"| 商品动销率 | {pm['item_sales_rate_pct']}% |")
    w(f"| 单品平均销量 | {pm['avg_sales_per_active_item']} |")
    w()

    # ── 4. 跨表关联验证 ──
    w("---")
    w("## 四、跨表关联关系验证")
    w()

    w("### 4.1 ID 关联覆盖率")
    w()
    w("| 关联路径 | 源表去重ID数 | 匹配数 | 覆盖率 |")
    w("|----------|-----------:|------:|------:|")
    w(f"| 日志→商品 (全行为) | {s4['log_to_product']['log_distinct_items']:,} | {s4['log_to_product']['matched_items']:,} | **{s4['log_to_product']['coverage_all_actions_pct']}%** |")
    w(f"| 日志→商品 (购买) | {s4['log_to_product']['purchase_items']:,} | {s4['log_to_product']['purchase_matched']:,} | **{s4['log_to_product']['coverage_purchase_pct']}%** |")
    w(f"| 评论→商品 | {s4['review_to_product']['review_distinct_items']:,} | {s4['review_to_product']['matched_items']:,} | **{s4['review_to_product']['coverage_pct']}%** |")
    w(f"| 评论→日志 (user+item) | {s4['review_to_log']['review_distinct_user_item_pairs']:,} | {s4['review_to_log']['matched_purchase_pairs']:,} | **{s4['review_to_log']['coverage_pct']}%** |")
    w()

    w("### 4.2 关联结论")
    w()
    w(f"- 日志表与商品表的 ID 关联覆盖率高达 **{s4['log_to_product']['coverage_all_actions_pct']}%**，购买行为覆盖率 **{s4['log_to_product']['coverage_purchase_pct']}%**，跨表关联可行性好")
    w(f"- 评论表与商品表覆盖率 **{s4['review_to_product']['coverage_pct']}%**，可直接关联")
    w(f"- 评论表与购买日志的 (用户+商品) 对匹配率 **{s4['review_to_log']['coverage_pct']}%**，存在部分评论无法追溯到购买行为")
    w()

    # ── 5. 综合洞察 ──
    w("---")
    w("## 五、初步业务洞察总结")
    w()
    w("1. **极度稀疏的交互数据**: 用户-商品交互矩阵密度仅 0.0016%，推荐系统需要基于 Embedding（MF/BPR/DSSM）或图方法（GCN/PinSage）来处理冷启动和稀疏性问题")
    w(f"2. **典型的漏斗衰减**: 点击→购买转化率仅 {cr['click_to_purchase_rate_pct']}%，意味着约每 100 次点击产生约 1 次购买。加购转化率明显更高 ({cr['cart_to_purchase_rate_pct']}%)，加购是强购买信号，可作为排序模型的核心 label")
    w(f"3. **不过度集中的市场结构**: 品牌 CR20 流量占比 {conc.get('brand_CR20_interaction', 'N/A')}%，头部效应存在但不极端，长尾商品贡献了大部分销量（尾部 78.7% 商品贡献 54.5% 销量），推荐策略需同时兼顾头部爆品与尾部长尾")
    w(f"4. **用户活跃度呈幂律分布**: P50 用户仅 {ua['total_actions_quantiles']['p50']:,} 次行为，90% 用户行为数 ≤ {ua['total_actions_quantiles']['p90']:,}。存在明显的活跃度分层，高活用户贡献了大部分交互量")
    w(f"5. **评论数据跨时间窗口覆盖**: 仅 {rc['item_review_coverage_pct']}% 商品有评论，{rc['review_users_not_in_purchase_window']:,} 名评论用户（{rc['review_users_not_in_purchase_window'] / rc['users_with_reviews'] * 100:.1f}%）的购买行为发生在日志追踪窗口外，评论信号在推荐模型中只能作为辅助特征使用")
    w(f"6. **跨表关联可行性良好**: 日志/商品/评论三表 ID 关联覆盖率均 ≥ 95%（评论→购买日志除外，因时间窗口不重叠），可以放心进行多表 Join 分析")
    w(f"7. **数据中存在爬虫噪声**: 检测到 {ua['bot_detection']['bot_users']:,} 个疑似 bot 账号，贡献了 {ua['bot_detection']['bot_actions_pct']}% 的行为量但零有效购买，在用户行为建模和推荐训练前应予以过滤")
    w()

    w("---")
    w(f"*报告由 eda_global.py 自动生成 | {RUN_START}*")
    w()

    # 写入文件
    report_path = os.path.join(REPORTS_DIR, "eda_global_report.md")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write("\n".join(md))
    log(f"报告已保存: {report_path}")

    # 写 JSON
    json_path = os.path.join(REPORTS_DIR, "eda_global_metrics.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(METRICS, f, ensure_ascii=False, indent=2, default=str)
    log(f"指标 JSON 已保存: {json_path}")


# ================================================================
# 主流程
# ================================================================
def main():
    log("=" * 60)
    log("Rec-Tmall 全局探索性数据分析 (Global EDA)")
    log(f"开始时间: {RUN_START}")
    log("=" * 60)

    spark = create_spark("Rec-Tmall-EDA")

    try:
        # 加载数据
        df_log, df_product, df_review = load_data(spark)

        # 第 1 部分：基础画像 + 类目 + 稀疏性
        section1_basic_profile(spark, df_log, df_product, df_review)
        section1b_sparsity(spark)

        # 第 2 部分：维度分布
        s2, item_pop = section2_distributions(spark)
        section2b_concentration(spark, item_pop)
        section2c_review_distribution(spark)

        # 释放 item_pop
        item_pop.unpersist()

        # 第 3 部分：业务指标
        section3_business_metrics(spark)

        # 第 4 部分：跨表验证
        section4_cross_table_validation(spark)

        # 生成报告
        generate_report()

        # 总耗时
        total_elapsed = time.time() - globals().get("_start_time", 0)
        log("\n" + "=" * 60)
        log(f"全量 EDA 完成! 总耗时: {total_elapsed/60:.1f} 分钟")
        log(f"结束时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        log("=" * 60)

    finally:
        spark.stop()


if __name__ == "__main__":
    _start_time = time.time()
    main()
