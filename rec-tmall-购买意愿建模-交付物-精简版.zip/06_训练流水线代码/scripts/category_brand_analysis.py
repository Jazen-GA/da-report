"""
类目与品牌热度分析 (模块 a)
============================
a1. 多层级类目绩效统计与排名（父类目 + 叶子类目两级，三类榜单 + 类目结构）
a2. 品牌绩效评估与梯队划分（全维度明细 + CR5/10/20 + 三梯队 + 头部品牌类目布局）

数据源: data/cleaned/item_ops（由 build_item_ops.py 生成）
输出:
  - reports/parent_category_metrics.csv     父类目全维度指标
  - reports/leaf_category_metrics.csv       叶子类目全维度指标（全量）
  - reports/category_rank_traffic.csv       流量规模榜 Top50
  - reports/category_rank_sales.csv         销量规模榜 Top50
  - reports/category_rank_conversion.csv    转化效率榜 Top50
  - reports/category_structure.csv          类目结构（丰富度/竞争格局）
  - reports/brand_metrics.csv               品牌全维度明细（全量）
  - reports/brand_concentration.csv         品牌集中度 CR
  - reports/brand_tiers.csv                 品牌梯队汇总
  - reports/top_brand_category_layout.csv   头部品牌类目布局
  - reports/category_brand_charts/          图表
"""
import os, sys, warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

plt.rcParams["font.sans-serif"] = ["Arial Unicode MS", "SimHei", "Heiti SC"]
plt.rcParams["axes.unicode_minus"] = False

from pyspark.sql import functions as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import create_spark, REPORTS_DIR, ITEM_OPS_PATH

CHARTS_DIR = os.path.join(REPORTS_DIR, "category_brand_charts")
os.makedirs(CHARTS_DIR, exist_ok=True)

# 转化效率榜最小点击门槛（避免小样本高转化噪音）
MIN_CLICK_FOR_CONV = 10_000

spark = create_spark("Category-Brand")
item_ops = spark.read.parquet(ITEM_OPS_PATH)

# ═══════════════════════════════════════════════════════════════
# A1. 类目绩效统计
# ═══════════════════════════════════════════════════════════════
print("=" * 60)
print("A1: 多层级类目绩效统计")
print("=" * 60)

# ── 父类目聚合 ──
parent_metrics = item_ops.groupBy("parent_cat").agg(
    F.count("*").alias("item_count"),
    F.sum("click_cnt").alias("click_cnt"),
    F.sum("collect_cnt").alias("collect_cnt"),
    F.sum("cart_cnt").alias("cart_cnt"),
    F.sum("alipay_cnt").alias("sales_cnt"),
    F.countDistinct("leaf_cat").alias("leaf_cat_count"),
    F.countDistinct("brand_id").alias("brand_count"),
    F.sum(F.col("is_sold").cast("long")).alias("sold_item_count"),
).orderBy(F.desc("click_cnt")).toPandas()

parent_metrics["click_to_cart_rate"] = (parent_metrics["cart_cnt"] / parent_metrics["click_cnt"] * 100).round(3)
parent_metrics["click_to_alipay_rate"] = (parent_metrics["sales_cnt"] / parent_metrics["click_cnt"] * 100).round(3)
parent_metrics["sold_rate"] = (parent_metrics["sold_item_count"] / parent_metrics["item_count"] * 100).round(2)
parent_metrics.to_csv(os.path.join(REPORTS_DIR, "parent_category_metrics.csv"), index=False, encoding="utf-8-sig")
print(f"  父类目: {len(parent_metrics)} 个，已保存 parent_category_metrics.csv")

# ── 叶子类目聚合（以 category x-y 为唯一标识）──
leaf_metrics = item_ops.groupBy("category", "parent_cat", "leaf_cat").agg(
    F.count("*").alias("item_count"),
    F.sum("click_cnt").alias("click_cnt"),
    F.sum("collect_cnt").alias("collect_cnt"),
    F.sum("cart_cnt").alias("cart_cnt"),
    F.sum("alipay_cnt").alias("sales_cnt"),
    F.countDistinct("brand_id").alias("brand_count"),
    F.sum(F.col("is_sold").cast("long")).alias("sold_item_count"),
).orderBy(F.desc("click_cnt")).toPandas()

leaf_metrics["click_to_cart_rate"] = (leaf_metrics["cart_cnt"] / leaf_metrics["click_cnt"] * 100).round(3)
leaf_metrics["click_to_alipay_rate"] = (leaf_metrics["sales_cnt"] / leaf_metrics["click_cnt"] * 100).round(3)
leaf_metrics["sold_rate"] = (leaf_metrics["sold_item_count"] / leaf_metrics["item_count"] * 100).round(2)
leaf_metrics.to_csv(os.path.join(REPORTS_DIR, "leaf_category_metrics.csv"), index=False, encoding="utf-8-sig")
print(f"  叶子类目: {len(leaf_metrics)} 个，已保存 leaf_category_metrics.csv")

# ── 三类榜单（叶子类目层级）──
rank_traffic = leaf_metrics.nlargest(50, "click_cnt")[
    ["category", "parent_cat", "click_cnt", "collect_cnt", "cart_cnt", "sales_cnt", "click_to_alipay_rate", "sold_item_count"]
].rename(columns={"category": "叶子类目", "parent_cat": "父类目", "click_cnt": "点击量", "collect_cnt": "收藏量",
                  "cart_cnt": "加购量", "sales_cnt": "销量", "click_to_alipay_rate": "点击购买转化率%", "sold_item_count": "动销商品数"})
rank_traffic.to_csv(os.path.join(REPORTS_DIR, "category_rank_traffic.csv"), index=False, encoding="utf-8-sig")

rank_sales = leaf_metrics.nlargest(50, "sales_cnt")[
    ["category", "parent_cat", "sales_cnt", "click_cnt", "click_to_alipay_rate", "click_to_cart_rate", "sold_item_count"]
].rename(columns={"category": "叶子类目", "parent_cat": "父类目", "sales_cnt": "销量", "click_cnt": "点击量",
                  "click_to_alipay_rate": "点击购买转化率%", "click_to_cart_rate": "点击加购转化率%", "sold_item_count": "动销商品数"})
rank_sales.to_csv(os.path.join(REPORTS_DIR, "category_rank_sales.csv"), index=False, encoding="utf-8-sig")

_conv = leaf_metrics[leaf_metrics["click_cnt"] >= MIN_CLICK_FOR_CONV]
rank_conv = _conv.nlargest(50, "click_to_alipay_rate")[
    ["category", "parent_cat", "click_to_alipay_rate", "click_to_cart_rate", "click_cnt", "sales_cnt", "sold_item_count"]
].rename(columns={"category": "叶子类目", "parent_cat": "父类目", "click_to_alipay_rate": "点击购买转化率%",
                  "click_to_cart_rate": "点击加购转化率%", "click_cnt": "点击量", "sales_cnt": "销量", "sold_item_count": "动销商品数"})
rank_conv.to_csv(os.path.join(REPORTS_DIR, "category_rank_conversion.csv"), index=False, encoding="utf-8-sig")
print(f"  三类榜单已保存（流量/销量/转化，各 Top50）")

# ── 类目结构分析（丰富度 + 竞争格局）──
cat_structure = parent_metrics[["parent_cat", "leaf_cat_count", "item_count", "brand_count", "sold_item_count"]].copy()
cat_structure["品牌/叶子类目比"] = (cat_structure["brand_count"] / cat_structure["leaf_cat_count"]).round(1)
cat_structure["动销率%"] = (cat_structure["sold_item_count"] / cat_structure["item_count"] * 100).round(2)
cat_structure = cat_structure.rename(columns={
    "parent_cat": "父类目", "leaf_cat_count": "叶子类目数", "item_count": "商品数",
    "brand_count": "入驻品牌数", "sold_item_count": "动销商品数",
})
cat_structure.to_csv(os.path.join(REPORTS_DIR, "category_structure.csv"), index=False, encoding="utf-8-sig")
print(f"  类目结构已保存 category_structure.csv")

# ═══════════════════════════════════════════════════════════════
# A2. 品牌绩效评估与梯队划分
# ═══════════════════════════════════════════════════════════════
print("\n" + "=" * 60)
print("A2: 品牌绩效评估与梯队划分")
print("=" * 60)

# ── 品牌全维度聚合（null 单列「未标注」）──
brand_metrics = item_ops.withColumn(
    "brand_label", F.coalesce(F.col("brand_id"), F.lit("未标注"))
).groupBy("brand_label").agg(
    F.count("*").alias("item_count"),
    F.sum("click_cnt").alias("click_cnt"),
    F.sum("collect_cnt").alias("collect_cnt"),
    F.sum("cart_cnt").alias("cart_cnt"),
    F.sum("alipay_cnt").alias("sales_cnt"),
    F.sum(F.col("is_sold").cast("long")).alias("sold_item_count"),
    F.countDistinct("parent_cat").alias("parent_cat_count"),
).toPandas()

brand_metrics["click_to_alipay_rate"] = (brand_metrics["sales_cnt"] / brand_metrics["click_cnt"] * 100).round(3)
brand_metrics["click_to_cart_rate"] = (brand_metrics["cart_cnt"] / brand_metrics["click_cnt"] * 100).round(3)
brand_metrics["sold_rate"] = (brand_metrics["sold_item_count"] / brand_metrics["item_count"] * 100).round(2)
brand_metrics = brand_metrics.sort_values("sales_cnt", ascending=False).reset_index(drop=True)
brand_metrics.to_csv(os.path.join(REPORTS_DIR, "brand_metrics.csv"), index=False, encoding="utf-8-sig")
print(f"  品牌明细: {len(brand_metrics)} 组（含未标注），已保存 brand_metrics.csv")

# ── 品牌集中度 CR5/10/20（基于有标注品牌）──
brands_labeled = brand_metrics[brand_metrics["brand_label"] != "未标注"].reset_index(drop=True)
total_brand_click = brands_labeled["click_cnt"].sum()
total_brand_sales = brands_labeled["sales_cnt"].sum()
total_brands = len(brands_labeled)

def cr(df, col, total, n):
    # 按该指标自身降序取头部 n 个，避免「用销量排序算流量集中度」的口径错误
    return round(df.sort_values(col, ascending=False)[col].head(n).sum() / total * 100, 2)

concentration = {
    "指标": [],
    "CR5%": [], "CR10%": [], "CR20%": [],
    "品牌总数": total_brands,
}
concentration["指标"] = ["流量(点击)集中度", "销量(成交)集中度"]
concentration["CR5%"] = [cr(brands_labeled, "click_cnt", total_brand_click, 5), cr(brands_labeled, "sales_cnt", total_brand_sales, 5)]
concentration["CR10%"] = [cr(brands_labeled, "click_cnt", total_brand_click, 10), cr(brands_labeled, "sales_cnt", total_brand_sales, 10)]
concentration["CR20%"] = [cr(brands_labeled, "click_cnt", total_brand_click, 20), cr(brands_labeled, "sales_cnt", total_brand_sales, 20)]
conc_df = pd.DataFrame(concentration)
conc_df.to_csv(os.path.join(REPORTS_DIR, "brand_concentration.csv"), index=False, encoding="utf-8-sig")
print(f"  品牌集中度: CR5流量 {conc_df['CR5%'][0]}% / CR5销量 {conc_df['CR5%'][1]}%")

# ── 综合绩效得分 + 三梯队 ──
def mm(s):
    return (s - s.min()) / (s.max() - s.min()) if s.max() > s.min() else s * 0

brands_labeled = brands_labeled.copy()
brands_labeled["conv"] = brands_labeled["sales_cnt"] / brands_labeled["click_cnt"].replace(0, np.nan)
brands_labeled["score"] = (
    0.35 * mm(np.log1p(brands_labeled["click_cnt"])) +
    0.35 * mm(np.log1p(brands_labeled["sales_cnt"])) +
    0.30 * mm(brands_labeled["conv"].fillna(0))
)
brands_labeled["score_rank_pct"] = brands_labeled["score"].rank(ascending=False, pct=True)
brands_labeled["tier"] = np.where(
    brands_labeled["score_rank_pct"] <= 0.05, "头部",
    np.where(brands_labeled["score_rank_pct"] <= 0.25, "腰部", "尾部")
)

tier_summary = brands_labeled.groupby("tier").agg(
    品牌数量=("brand_label", "count"),
    商品数量=("item_count", "sum"),
    点击量=("click_cnt", "sum"),
    销量=("sales_cnt", "sum"),
    动销商品数=("sold_item_count", "sum"),
).reindex(["头部", "腰部", "尾部"]).reset_index()

tier_summary["品牌占比%"] = (tier_summary["品牌数量"] / total_brands * 100).round(2)
tier_summary["商品占比%"] = (tier_summary["商品数量"] / tier_summary["商品数量"].sum() * 100).round(2)
tier_summary["流量贡献%"] = (tier_summary["点击量"] / tier_summary["点击量"].sum() * 100).round(2)
tier_summary["销量贡献%"] = (tier_summary["销量"] / tier_summary["销量"].sum() * 100).round(2)
tier_summary["梯队动销率%"] = (tier_summary["动销商品数"] / tier_summary["商品数量"] * 100).round(2)
tier_summary.to_csv(os.path.join(REPORTS_DIR, "brand_tiers.csv"), index=False, encoding="utf-8-sig")
print(f"  品牌梯队: 头部 {tier_summary.loc[0,'品牌数量']:,} / 腰部 {tier_summary.loc[1,'品牌数量']:,} / 尾部 {tier_summary.loc[2,'品牌数量']:,}")

# ── 头部品牌类目布局 ──
head_brands = brands_labeled[brands_labeled["tier"] == "头部"]["brand_label"].tolist()
brand_cat = item_ops.filter(F.col("brand_id").isin(head_brands)).groupBy("brand_id", "parent_cat").agg(
    F.sum("alipay_cnt").alias("cat_sales"),
    F.count("*").alias("cat_items"),
).toPandas()

# 每个头部品牌的最大类目集中度
brand_cat = brand_cat.merge(brands_labeled[["brand_label", "sales_cnt", "item_count", "click_cnt"]],
                            left_on="brand_id", right_on="brand_label", how="left")
brand_cat["cat_sales_share"] = brand_cat["cat_sales"] / brand_cat["sales_cnt"]

layout = brand_cat.groupby("brand_id").agg(
    覆盖父类目数=("parent_cat", "nunique"),
    最大类目销量占比=("cat_sales_share", "max"),
    总销量=("sales_cnt", "first"),
    覆盖商品数=("item_count", "first"),
    总点击=("click_cnt", "first"),
).reset_index()

# 主营类目取值修正：用最大销量类目
def main_cat(g):
    row = brand_cat[brand_cat["brand_id"] == g].sort_values("cat_sales", ascending=False).iloc[0]
    return row["parent_cat"]
layout["主营类目"] = layout["brand_id"].apply(main_cat)
layout["布局类型"] = np.where(layout["最大类目销量占比"] >= 0.8, "单一品类深耕", "多品类扩张")
layout = layout.sort_values("总销量", ascending=False).reset_index(drop=True)
layout.to_csv(os.path.join(REPORTS_DIR, "top_brand_category_layout.csv"), index=False, encoding="utf-8-sig")

layout_stats = layout["布局类型"].value_counts()
print(f"  头部品牌类目布局: 单一深耕 {layout_stats.get('单一品类深耕',0)} / 多品类扩张 {layout_stats.get('多品类扩张',0)}")

# ═══════════════════════════════════════════════════════════════
# 可视化
# ═══════════════════════════════════════════════════════════════
print("\n" + "=" * 60)
print("生成图表")
print("=" * 60)

fig, axes = plt.subplots(2, 2, figsize=(20, 16))

# ── 图1: 父类目 Top20 流量 vs 销量 ──
ax = axes[0, 0]
top20p = parent_metrics.head(20).sort_values("click_cnt")
x = np.arange(len(top20p))
w = 0.38
ax.barh(x + w/2, top20p["click_cnt"], w, color="#4C72B0", label="点击量", alpha=0.9)
ax.barh(x - w/2, top20p["sales_cnt"], w, color="#DD8452", label="销量", alpha=0.9)
ax.set_yticks(x)
ax.set_yticklabels([f"类目{int(c)}" for c in top20p["parent_cat"]], fontsize=9)
ax.set_xlabel("数量")
ax.set_title("Top20 父类目 流量 vs 销量", fontsize=14, fontweight="bold")
ax.legend(fontsize=10)
ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"{v/1e6:.0f}M"))
ax.invert_yaxis()

# ── 图2: 叶子类目转化效率散点（点击量 vs 购买转化率）──
ax = axes[0, 1]
plot_leaf = leaf_metrics[leaf_metrics["click_cnt"] >= MIN_CLICK_FOR_CONV]
sc = ax.scatter(plot_leaf["click_cnt"], plot_leaf["click_to_alipay_rate"],
                s=np.log1p(plot_leaf["sales_cnt"]) * 15, c=plot_leaf["click_to_alipay_rate"],
                cmap="viridis", alpha=0.6, edgecolors="none")
ax.set_xscale("log")
ax.set_xlabel("点击量 (log)", fontsize=11)
ax.set_ylabel("点击→购买转化率 (%)", fontsize=11)
ax.set_title(f"叶子类目转化效率分布（气泡=销量，点击≥{MIN_CLICK_FOR_CONV}）", fontsize=13, fontweight="bold")
plt.colorbar(sc, ax=ax, label="转化率%")

# ── 图3: 品牌 Lorenz 曲线 ──
ax = axes[1, 0]
for col, label, color in [("click_cnt", "流量", "#4C72B0"), ("sales_cnt", "销量", "#DD8452")]:
    vals = brands_labeled.sort_values(col, ascending=False)[col].cumsum()
    vals = vals / vals.iloc[-1]
    ax.plot(np.linspace(0, 100, len(vals)), vals * 100, color=color, lw=2, label=label)
ax.plot([0, 100], [0, 100], "--", color="gray", lw=1, label="绝对均匀")
ax.set_xlabel("品牌累计占比 (%)", fontsize=11)
ax.set_ylabel("累计贡献占比 (%)", fontsize=11)
ax.set_title("品牌集中度 Lorenz 曲线", fontsize=14, fontweight="bold")
ax.legend(fontsize=10)

# ── 图4: 品牌梯队贡献对比 ──
ax = axes[1, 1]
tiers = ["头部", "腰部", "尾部"]
x = np.arange(3)
w = 0.25
ax.bar(x - w, tier_summary["品牌占比%"], w, label="品牌数占比", color="#4C72B0")
ax.bar(x, tier_summary["商品占比%"], w, label="商品数占比", color="#55A868")
ax.bar(x + w, tier_summary["销量贡献%"], w, label="销量贡献占比", color="#DD8452")
ax.set_xticks(x)
ax.set_xticklabels(tiers, fontsize=12)
ax.set_ylabel("占比 (%)", fontsize=11)
ax.set_title("品牌三梯队市场贡献结构", fontsize=14, fontweight="bold")
ax.legend(fontsize=10)
for i, (b, p, s) in enumerate(zip(tier_summary["品牌占比%"], tier_summary["商品占比%"], tier_summary["销量贡献%"])):
    ax.text(i - w, b + 0.5, f"{b:.1f}", ha="center", fontsize=8)
    ax.text(i, p + 0.5, f"{p:.1f}", ha="center", fontsize=8)
    ax.text(i + w, s + 0.5, f"{s:.1f}", ha="center", fontsize=8)

plt.tight_layout()
plt.savefig(os.path.join(CHARTS_DIR, "category_brand_overview.png"), dpi=150, bbox_inches="tight")
plt.close()
print("  ✓ 图表已保存: category_brand_charts/category_brand_overview.png")

# ── 额外图: 头部品牌类目数分布 ──
fig, ax = plt.subplots(figsize=(10, 5))
layout["覆盖父类目数"].value_counts().sort_index().plot(kind="bar", ax=ax, color="#4C72B0", alpha=0.85)
ax.set_xlabel("覆盖父类目数", fontsize=12)
ax.set_ylabel("品牌数量", fontsize=12)
ax.set_title("头部品牌覆盖父类目数分布（单一深耕 vs 多品类扩张）", fontsize=14, fontweight="bold")
plt.tight_layout()
plt.savefig(os.path.join(CHARTS_DIR, "top_brand_layout.png"), dpi=150, bbox_inches="tight")
plt.close()
print("  ✓ 图表已保存: category_brand_charts/top_brand_layout.png")

print("\n" + "=" * 60)
print("模块 a 完成!")
print("=" * 60)

spark.stop()
