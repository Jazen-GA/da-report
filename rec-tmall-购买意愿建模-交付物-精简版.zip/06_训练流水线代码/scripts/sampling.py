"""
Rec-Tmall 分层抽样脚本
功能: 从全量清洗数据中构建多级样本集（全量/开发/极限/调试）
      保持行为类型、类目分布与全量数据一致
用法: python scripts/sampling.py
"""
import os, sys, time, json
from datetime import datetime
from pyspark.sql import functions as F
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.config import *

def compute_distribution(spark, table_name, clean_path):
    """计算全量数据的分布（行为类型、类目）"""
    df = spark.read.parquet(clean_path)

    if table_name == "log":
        # 行为类型分布
        action_dist = df.groupBy("action").count().collect()
        total = df.count()
        dist = {}
        for row in action_dist:
            dist[row["action"]] = row["count"] / total
        return dist, total

    elif table_name == "product":
        # 类目分布（取父类别）
        total = df.count()
        # 父类别 = category 的 x 部分
        df_with_parent = df.withColumn(
            "parent_cat", F.split(F.col("category"), "-").getItem(0)
        )
        cat_dist = df_with_parent.groupBy("parent_cat").count().collect()
        dist = {}
        for row in cat_dist:
            dist[row["parent_cat"]] = row["count"] / total
        return dist, total

    return {}, df.count()

def stratified_sample_log(spark, df_full, sample_size, seed=42):
    """
    对日志表按行为类型做分层抽样
    """
    # 计算各行为类型的比例
    action_counts = df_full.groupBy("action").count().collect()
    total = sum(r["count"] for r in action_counts)

    sampled_dfs = []
    for row in action_counts:
        action = row["action"]
        frac = sample_size / total
        action_specific = df_full.filter(F.col("action") == action)
        sampled = action_specific.sample(fraction=frac, seed=seed + hash(action) % 1000)
        sampled_dfs.append(sampled)

    # 合并所有采样的分区
    if sampled_dfs:
        result = sampled_dfs[0]
        for df in sampled_dfs[1:]:
            result = result.union(df)
        return result
    return None

def build_user_sample(spark, df_log, df_product, df_review, fraction, mode, seed=42):
    """
    按用户随机抽样生成一档样本（log/product/review），保持行为类型、类目分布与全量一致。
    返回 (log_df, log_count, action_dist)，供调用方做一致性校验。
    """
    print(f"  按用户抽样 ({fraction:.0%}) ...")

    # 随机选 fraction 比例的用户
    users = df_log.select("user_id").distinct()
    total_users = users.count()
    sample_users = users.sample(fraction=fraction, seed=seed)
    sampled_users_count = sample_users.count()

    print(f"    总用户数: {total_users:,} → 采样 {sampled_users_count:,} 用户")

    # 提取这些用户的全部行为日志
    samp_log = df_log.join(sample_users, on="user_id", how="inner")
    samp_log_count = samp_log.count()
    print(f"    日志行数: {samp_log_count:,}")

    samp_action_dist = samp_log.groupBy("action").count().collect()

    # 提取关联的商品和评论
    samp_items = samp_log.select("item_id").distinct()
    samp_product = df_product.join(samp_items, on="item_id", how="inner")
    samp_users = samp_log.select("user_id").distinct()
    samp_review = df_review.join(samp_users, on="user_id", how="inner")

    # 写入样本集
    out_dir = SAMPLE_FILES[mode]
    print(f"    写入 {mode} 档 Parquet...")
    samp_product.write.mode("overwrite").option("compression", "snappy") \
        .parquet(os.path.join(out_dir, "product"))
    samp_log.write.mode("overwrite").option("compression", "snappy") \
        .partitionBy("action_date", "action_type") \
        .parquet(os.path.join(out_dir, "log"))
    samp_review.write.mode("overwrite").option("compression", "snappy") \
        .parquet(os.path.join(out_dir, "review"))

    print(f"    {mode} 档已保存: {out_dir}")
    print(f"      商品: {samp_product.count():,} 行")
    print(f"      日志: {samp_log_count:,} 行")
    print(f"      评论: {samp_review.count():,} 行")

    return samp_log, samp_log_count, samp_action_dist

def build_samples(spark):
    """构建多级样本集"""
    print("=" * 60)
    print("Rec-Tmall 分层抽样")
    print("=" * 60)

    # 检查清洗后数据是否存在
    for name, path in CLEANED_FILES.items():
        if not os.path.exists(path):
            print(f"  [ERROR] 清洗后数据不存在: {path}")
            print(f"  请先运行: python scripts/etl.py")
            return

    # ── 读取全量数据（各档共用）──
    df_log = spark.read.parquet(CLEANED_FILES["log"])
    log_total = df_log.count()

    # 获取行为分布
    action_dist = df_log.groupBy("action").count().collect()
    print("\n全量行为分布:")
    for r in action_dist:
        print(f"  {r['action']}: {r['count']:,} ({r['count']/log_total*100:.1f}%)")

    df_product = spark.read.parquet(CLEANED_FILES["product"])
    df_review = spark.read.parquet(CLEANED_FILES["review"])

    # ── 1. 全量数据集 ──
    print("\n1/4 全量数据集 — 直接使用清洗后的 Parquet 文件")
    print(f"  商品表: {CLEANED_FILES['product']}")
    print(f"  日志表: {CLEANED_FILES['log']}")
    print(f"  评论表: {CLEANED_FILES['review']}")

    # ── 2. 按用户抽样档（dev / limit）──
    step = 2
    dev_log = None
    dev_log_count = 0
    dev_action_dist = None
    for mode, fraction in USER_SAMPLE_FRACTIONS.items():
        seed = 42 if mode == "dev" else 43
        print(f"\n{step}/4 {mode} 样本集 — 按用户抽样")
        lg, cnt, adist = build_user_sample(spark, df_log, df_product, df_review,
                                            fraction, mode, seed=seed)
        if mode == "dev":
            dev_log, dev_log_count, dev_action_dist = lg, cnt, adist
        step += 1

    # ── 3. 调试样本集（随机万级）──
    print(f"\n{step}/4 调试样本集 — 随机抽样 (~1万行)")

    debug_log = df_log.sample(fraction=0.0001, seed=123)
    debug_count = debug_log.count()
    print(f"  调试集日志行数: {debug_count:,}")

    debug_items = debug_log.select("item_id").distinct()
    debug_users = debug_log.select("user_id").distinct()

    debug_product = df_product.join(debug_items, on="item_id", how="inner")
    debug_review = df_review.join(debug_users, on="user_id", how="inner")

    debug_product.write.mode("overwrite").option("compression", "snappy") \
        .parquet(os.path.join(SAMPLE_FILES["debug"], "product"))
    debug_log.write.mode("overwrite").option("compression", "snappy") \
        .parquet(os.path.join(SAMPLE_FILES["debug"], "log"))
    debug_review.write.mode("overwrite").option("compression", "snappy") \
        .parquet(os.path.join(SAMPLE_FILES["debug"], "review"))

    print(f"  调试集已保存: {SAMPLE_FILES['debug']}")
    print(f"    商品: {debug_product.count():,} 行")
    print(f"    日志: {debug_count:,} 行")
    print(f"    评论: {debug_review.count():,} 行")

    # ── 4. 一致性校验 ──
    print("\n" + "─" * 60)
    print("4. 一致性校验")
    print("─" * 60)

    # 检查字段结构一致
    full_cols = set(df_log.columns)
    dev_cols = set(spark.read.parquet(os.path.join(SAMPLE_FILES["dev"], "log")).columns)
    debug_cols = set(spark.read.parquet(os.path.join(SAMPLE_FILES["debug"], "log")).columns)

    if full_cols == dev_cols == debug_cols:
        print("  [OK] 各档样本集字段结构完全一致")
    else:
        print(f"  [WARN] 字段不一致: 全量={full_cols}, 开发={dev_cols}, 调试={debug_cols}")

    # 比较行为分布
    print("\n  行为分布对比:")
    print(f"  {'行为':>10} | {'全量':>10} | {'开发':>10} | {'调试':>10}")
    print(f"  {'─'*10}─┼─{'─'*10}─┼─{'─'*10}─┼─{'─'*10}")

    debug_dist = debug_log.groupBy("action").count().collect()
    debug_dict = {r["action"]: r["count"] for r in debug_dist}
    dev_dict = {r["action"]: r["count"] for r in (dev_action_dist or [])}
    full_dict = {r["action"]: r["count"] for r in action_dist}

    for action in ["click", "collect", "cart", "alipay"]:
        fp = full_dict.get(action, 0) / log_total * 100
        dp = dev_dict.get(action, 0) / dev_log_count * 100 if dev_log_count > 0 else 0
        dbp = debug_dict.get(action, 0) / debug_count * 100 if debug_count > 0 else 0
        print(f"  {action:>10} | {fp:>9.1f}% | {dp:>9.1f}% | {dbp:>9.1f}%")

    return True

def main():
    spark = create_spark()
    spark.sparkContext.setLogLevel("WARN")

    build_samples(spark)

    spark.stop()
    print("\n" + "=" * 60)
    print("分层抽样完成!")
    print("=" * 60)

if __name__ == "__main__":
    main()
