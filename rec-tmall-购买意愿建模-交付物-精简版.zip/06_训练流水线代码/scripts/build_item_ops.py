"""
商品级运营宽表构建
==================
扫一次全量日志，聚合出 810 万商品的四类行为计数，再关联商品属性表，
落成 item 级宽表，供「类目/品牌」「卖家」「长尾」三个分析模块共用，避免重复扫 13 亿行。

字段:
  item_id         商品ID
  click_cnt       点击量
  collect_cnt     收藏量
  cart_cnt        加购量
  alipay_cnt      购买量（订单次数，作为销量）
  total_actions   总行为量
  has_interaction 是否有交互
  is_sold         是否动销（销量 > 0）
  category        原始类目 (x-y)
  parent_cat      父类目ID
  leaf_cat        叶子类目ID
  brand_id        品牌ID（可空）
  seller_id       卖家ID

输出: data/cleaned/item_ops (Parquet)
用法: python scripts/build_item_ops.py [--force]
"""
import os, sys, time, argparse, warnings
warnings.filterwarnings("ignore")
from pyspark.sql import functions as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import create_spark, DATA_CLEANED, ITEM_OPS_PATH


def build(spark, force=False):
    if not force and os.path.exists(ITEM_OPS_PATH):
        print(f"  item_ops 已存在，跳过构建（--force 可重建）: {ITEM_OPS_PATH}")
        return spark.read.parquet(ITEM_OPS_PATH)

    t0 = time.time()

    # ── 1. 日志按商品聚合行为计数 ──
    print("  读取日志并聚合商品级行为计数...")
    log = spark.read.parquet(os.path.join(DATA_CLEANED, "log"))
    log_agg = log.groupBy("item_id").agg(
        F.count(F.when(F.col("action_type") == "click", 1)).alias("click_cnt"),
        F.count(F.when(F.col("action_type") == "collect", 1)).alias("collect_cnt"),
        F.count(F.when(F.col("action_type") == "cart", 1)).alias("cart_cnt"),
        F.count(F.when(F.col("action_type") == "alipay", 1)).alias("alipay_cnt"),
    )
    print(f"  日志聚合完成，耗时 {time.time() - t0:.1f}s")

    # ── 2. 商品属性表 + 解析两级类目 ──
    print("  读取商品属性表并解析类目层级...")
    product = spark.read.parquet(os.path.join(DATA_CLEANED, "product"))
    product = product.withColumn("parent_cat", F.split(F.col("category"), "-")[0].cast("int")) \
                     .withColumn("leaf_cat", F.split(F.col("category"), "-")[1].cast("int")) \
                     .select("item_id", "category", "parent_cat", "leaf_cat", "brand_id", "seller_id")

    # ── 3. 左关联（product 为左表，保留零交互商品）──
    print("  关联商品属性与行为计数...")
    item_ops = product.join(log_agg, "item_id", "left") \
        .fillna(0, subset=["click_cnt", "collect_cnt", "cart_cnt", "alipay_cnt"]) \
        .withColumn("total_actions",
                    F.col("click_cnt") + F.col("collect_cnt") + F.col("cart_cnt") + F.col("alipay_cnt")) \
        .withColumn("has_interaction", F.col("total_actions") > 0) \
        .withColumn("is_sold", F.col("alipay_cnt") > 0)

    # ── 4. 写入 Parquet ──
    print("  写入 item_ops Parquet...")
    item_ops.write.mode("overwrite").option("compression", "snappy").parquet(ITEM_OPS_PATH)

    n = spark.read.parquet(ITEM_OPS_PATH).count()
    print(f"  ✓ item_ops 构建完成: {n:,} 行，总耗时 {time.time() - t0:.1f}s")
    return item_ops


def main():
    parser = argparse.ArgumentParser(description="构建商品运营宽表")
    parser.add_argument("--force", action="store_true", help="强制重建")
    args = parser.parse_args()

    spark = create_spark("Build-Item-Ops")
    build(spark, force=args.force)
    spark.stop()


if __name__ == "__main__":
    main()
