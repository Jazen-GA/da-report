"""
评论口碑分析报告生成
====================
汇总模型效果 / 全量情感分布 / 口碑转化关联 / 负面口碑诊断 / 核心关键词，
生成 HTML 报告 + 配套图表到 reports/sentiment/。

用法: python scripts/sentiment/report.py
"""
import os, sys, json, base64
import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.config import *
from scripts.sentiment.features import TOPIC_WORDS

MODEL_DIR = SENTIMENT_MODEL_DIR
OUT_DIR = SENTIMENT_OUTPUT_DIR
SAMPLES_DIR = SENTIMENT_SAMPLES_DIR
VOCAB_DIR = SENTIMENT_VOCAB_DIR
REPORT_DIR = SENTIMENT_REPORTS_DIR
ITEM_OPS_PATH = os.path.join(DATA_CLEANED, "item_ops")

# 模型显示名映射（model_report.json 的 key → 报告展示名）
MODEL_NAMES = {"nb": "朴素贝叶斯", "lr": "逻辑回归", "lgbm": "LightGBM"}


def _set_chinese_font():
    for name in ["PingFang SC", "Hiragino Sans GB", "STHeiti", "Arial Unicode MS", "Heiti SC"]:
        installed = {f.name for f in font_manager.fontManager.ttflist}
        if name in installed:
            plt.rcParams["font.sans-serif"] = [name]
            break
    plt.rcParams["axes.unicode_minus"] = False


def _img_b64(path):
    if os.path.exists(path):
        with open(path, "rb") as f:
            return base64.b64encode(f.read()).decode()
    return ""


def load_all():
    d = {}
    for fn in ["label_distribution.json"]:
        p = os.path.join(SAMPLES_DIR, fn)
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                d["label_dist"] = json.load(f)
    for fn in ["vocab_stats.json"]:
        p = os.path.join(VOCAB_DIR, fn)
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                d["vocab"] = json.load(f)
    for fn in ["model_report.json"]:
        p = os.path.join(MODEL_DIR, fn)
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                d["model_report"] = json.load(f)
    for fn in ["infer_summary.json"]:
        p = os.path.join(OUT_DIR, fn)
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                d["infer"] = json.load(f)
    for fn in ["human_eval_report.json"]:
        p = os.path.join(SAMPLES_DIR, fn)
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                d["human_eval"] = json.load(f)
    for fn in ["per_category_f1.csv", "item_reputation.csv", "parent_cat_reputation.csv",
               "leaf_cat_reputation.csv", "global_pos_words.csv", "global_neg_words.csv",
               "per_category_keywords.csv", "theme_keyword_stats.csv"]:
        p = os.path.join(OUT_DIR if fn != "per_category_f1.csv" else MODEL_DIR, fn)
        if os.path.exists(p):
            d[fn.replace(".csv", "")] = pd.read_csv(p)
    return d


def make_charts(d):
    os.makedirs(REPORT_DIR, exist_ok=True)
    paths = {}

    # 1. 标注分布
    ld = d.get("label_dist", {})
    lc = ld.get("label_counts", {})
    if lc:
        fig, ax = plt.subplots(figsize=(5, 4))
        labels = {"1": "正向", "0": "负向", "-1": "中性"}
        vals = [lc.get(k, 0) for k in ["1", "0", "-1"]]
        names = [labels.get(k, k) for k in ["1", "0", "-1"]]
        ax.bar(names, vals, color=["#2ca02c", "#d62728", "#999999"])
        ax.set_title("弱监督标注样本分布")
        for i, v in enumerate(vals):
            ax.text(i, v, f"{v:,}", ha="center", va="bottom")
        fig.tight_layout(); fig.savefig(os.path.join(REPORT_DIR, "label_distribution.png"), dpi=120); plt.close(fig)
        paths["label"] = "label_distribution.png"

    # 2. 模型对比
    mr = d.get("model_report", {})
    if "models" in mr:
        models = mr["models"]
        fig, ax = plt.subplots(figsize=(6, 4))
        names = list(models)
        x = np.arange(len(names))
        w = 0.25
        ax.bar(x - w, [models[n]["f1"] for n in names], w, label="F1")
        ax.bar(x, [models[n]["f1_macro"] for n in names], w, label="macro-F1")
        ax.bar(x + w, [models[n].get("auc", 0) for n in names], w, label="AUC")
        ax.set_xticks(x); ax.set_xticklabels(names)
        ax.set_ylim(0, 1.05); ax.set_title("三模型测试集指标对比")
        ax.legend(); ax.grid(axis="y", alpha=0.3)
        fig.tight_layout(); fig.savefig(os.path.join(REPORT_DIR, "model_comparison.png"), dpi=120); plt.close(fig)
        paths["model"] = "model_comparison.png"

    # 3. 品类口碑排名（父类目 Top/Bottom）
    pc = d.get("parent_cat_reputation")
    if pc is not None and len(pc):
        pc = pc[pc["review_cnt"] >= 500].sort_values("pos_rate")
        fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
        top = pc.tail(10); bot = pc.head(10)
        axes[0].barh([str(x) for x in top["parent_cat"]], top["pos_rate"], color="#2ca02c")
        axes[0].set_title("口碑最好 Top10 父类目"); axes[0].set_xlabel("正向率")
        axes[1].barh([str(x) for x in bot["parent_cat"]], bot["pos_rate"], color="#d62728")
        axes[1].set_title("口碑最差 Top10 父类目"); axes[1].set_xlabel("正向率")
        fig.tight_layout(); fig.savefig(os.path.join(REPORT_DIR, "category_reputation.png"), dpi=120); plt.close(fig)
        paths["cat"] = "category_reputation.png"

    # 4. 主题正负占比
    ts = d.get("theme_keyword_stats")
    if ts is not None and len(ts):
        fig, ax = plt.subplots(figsize=(8, 4))
        x = np.arange(len(ts))
        ax.bar(x - 0.2, ts["positive"], 0.4, label="正向核心词", color="#2ca02c")
        ax.bar(x + 0.2, ts["negative"], 0.4, label="负向核心词", color="#d62728")
        ax.set_xticks(x); ax.set_xticklabels(ts["theme"], rotation=15)
        ax.set_title("各主题核心词正负分布"); ax.legend(); ax.grid(axis="y", alpha=0.3)
        fig.tight_layout(); fig.savefig(os.path.join(REPORT_DIR, "theme_stats.png"), dpi=120); plt.close(fig)
        paths["theme"] = "theme_stats.png"

    return paths


def compute_conversion(d):
    """口碑与转化关联：item_reputation join item_ops（销量/流量）"""
    item = d.get("item_reputation")
    if item is None or not os.path.exists(ITEM_OPS_PATH):
        return None
    ops = pd.read_parquet(ITEM_OPS_PATH, columns=["item_id", "click_cnt", "alipay_cnt"])
    m = item.merge(ops, on="item_id", how="inner")
    m = m[m["review_cnt"] >= 3]                       # 至少 3 条评论，口碑才稳定
    m["conversion"] = m["alipay_cnt"] / (m["click_cnt"] + 1e-6)
    corr = round(float(m["pos_rate"].corr(m["alipay_cnt"])), 3)

    # 分桶看转化
    m["bucket"] = pd.cut(m["pos_rate"], bins=[0, 0.6, 0.75, 0.85, 0.92, 0.97, 1.01],
                         labels=["<0.6", "0.6-0.75", "0.75-0.85", "0.85-0.92", "0.92-0.97", "0.97-1.0"])
    grp = m.groupby("bucket", observed=True).agg(
        items=("item_id", "count"),
        avg_alipay=("alipay_cnt", "mean"),
        avg_conversion=("conversion", "mean"),
        avg_pos_rate=("pos_rate", "mean"),
    ).reset_index()

    fig, ax = plt.subplots(figsize=(7, 4))
    ax2 = ax.twinx()
    x = np.arange(len(grp))
    ax.bar(x, grp["avg_alipay"], 0.4, color="#1f77b4", label="平均销量")
    ax2.plot(x, grp["avg_conversion"], "o-", color="#d62728", label="平均转化率")
    ax.set_xticks(x); ax.set_xticklabels(grp["bucket"])
    ax.set_xlabel("正向率分桶"); ax.set_ylabel("平均销量(alipay)")
    ax2.set_ylabel("平均转化率(alipay/click)")
    ax.set_title(f"口碑(正向率) 与 销量/转化 关联（相关系数 {corr}）")
    ax.legend(loc="upper left"); ax2.legend(loc="upper right")
    fig.tight_layout(); fig.savefig(os.path.join(REPORT_DIR, "conversion_correlation.png"), dpi=120); plt.close(fig)
    return {"corr": corr, "grp": grp}


def build_html(d, chart_paths, conv):
    css = "body{font-family:'PingFang SC',sans-serif;margin:40px;color:#222}h1{border-bottom:3px solid #2ca02c;padding-bottom:10px}h2{margin-top:32px;color:#1a7a1a}table{border-collapse:collapse;margin:12px 0}th,td{border:1px solid #ccc;padding:6px 12px;text-align:center;font-size:14px}th{background:#f0f0f0}img{max-width:100%;border:1px solid #ddd;margin:8px 0}.note{color:#888;font-size:13px}"
    def img(name):
        return f'<img src="data:image/png;base64,{_img_b64(os.path.join(REPORT_DIR, name))}">' if name in chart_paths.values() else ""

    parts = []
    parts.append(f"<html><head><meta charset='utf-8'><title>评论口碑情感分析报告</title><style>{css}</style></head><body>")
    parts.append("<h1>评论口碑情感分析与建模预测报告</h1>")

    # 1. 数据与标注
    parts.append("<h2>1. 数据与弱监督标注</h2>")
    ld = d.get("label_dist", {})
    vocab = d.get("vocab", {})
    if vocab:
        parts.append(f"<p>全量评论 <b>{vocab.get('total_reviews', 0):,}</b> 条，去重词 <b>{vocab.get('vocab_size', 0):,}</b> 个，"
                     f"单条评论有效关键词中位数 <b>{vocab.get('clean_token_count', {}).get('quantiles', {}).get('p50', '—')}</b> 个。</p>")
    if ld:
        lc = ld.get("label_counts", {})
        parts.append(f"<p>弱标注样本 <b>{ld.get('total_sampled', 0):,}</b> 条：正向 {lc.get('1', 0):,} / 负向 {lc.get('0', 0):,} / 中性 {lc.get('-1', 0):,}。</p>")
        parts.append(img("label_distribution.png"))

    # 2. 模型效果
    parts.append("<h2>2. 情感分类模型效果</h2>")
    mr = d.get("model_report", {})
    if "models" in mr:
        rows = ["<table><tr><th>模型</th><th>准确率</th><th>精确率</th><th>召回率</th><th>F1</th><th>macro-F1</th><th>AUC</th></tr>"]
        for n, m in mr["models"].items():
            rows.append(f"<tr><td>{MODEL_NAMES.get(n, n)}</td><td>{m['accuracy']}</td><td>{m['precision']}</td><td>{m['recall']}</td>"
                        f"<td>{m['f1']}</td><td>{m['f1_macro']}</td><td>{m.get('auc', '—')}</td></tr>")
        rows.append("</table>")
        parts.extend(rows)
        parts.append(f"<p>最优模型：<b>{MODEL_NAMES.get(mr.get('best_model'), mr.get('best_model'))}</b>。正样本占比 train {mr.get('class_distribution', {}).get('train_pos_rate')}。</p>")
        parts.append(img("model_comparison.png"))
        cm_path = os.path.join(MODEL_DIR, "confusion_matrix.png")
        if os.path.exists(cm_path):
            parts.append(f'<img src="data:image/png;base64,{_img_b64(cm_path)}" style="max-width:80%">')

    # 2.5 标注基线准确率（人工金标验证）——关键限定
    he = d.get("human_eval")
    if he:
        parts.append("<div style='background:#fff3cd;border:1px solid #ffc107;padding:12px 16px;margin:16px 0;border-radius:4px'>"
                     "<b>⚠ 标注基线准确率（人工金标验证）</b>"
                     f"<p>人工标注 <b>{he.get('n_labeled', 0)}</b> 条，弱监督标签基线准确率 <b>{he.get('accuracy', 0)*100:.1f}%</b>；"
                     f"正向精度 {he.get('positive_precision', 0)*100:.1f}%，负向精度 {he.get('negative_precision', 0)*100:.1f}%。</p>"
                     "<p>以上模型指标衡量的是模型「复现词典规则」的能力，<b>不等于真实情感准确率</b>；"
                     "弱监督标签本身约 83% 准确，故全量情感判断的真实上限约 83%。</p>"
                     "</div>")

    # 3. 分品类泛化
    parts.append("<h2>3. 分品类模型泛化</h2>")
    pcf = d.get("per_category_f1")
    if pcf is not None and len(pcf):
        best = mr.get("best_model", "")
        sub = pcf[pcf["model"] == best] if best else pcf
        weak = sub.sort_values("f1").head(8)
        parts.append("<p>薄弱品类（F1 最低）：</p><table><tr><th>父类目</th><th>样本数</th><th>F1</th><th>正样本占比</th></tr>")
        for _, r in weak.iterrows():
            parts.append(f"<tr><td>{r['parent_cat']}</td><td>{r['n']}</td><td>{r['f1']}</td><td>{r['pos_rate']}</td></tr>")
        parts.append("</table>")

    # 4. 全量情感分布
    parts.append("<h2>4. 全量评论情感分布</h2>")
    inf = d.get("infer", {})
    if inf:
        parts.append(f"<p>全量 <b>{inf.get('total', 0):,}</b> 条评论：整体正向率 <b>{inf.get('pos_rate', 0)*100:.1f}%</b>，"
                     f"综合情感得分 <b>{inf.get('avg_sentiment', 0):.3f}</b>。</p>")
        parts.append(img("category_reputation.png"))

    # 5. 口碑转化关联
    if conv is not None:
        parts.append("<h2>5. 口碑与转化关联</h2>")
        parts.append(f"<p>商品正向率与销量的相关系数 <b>{conv['corr']}</b>。</p>")
        parts.append("<table><tr><th>正向率分桶</th><th>商品数</th><th>平均销量</th><th>平均转化率</th></tr>")
        for _, r in conv["grp"].iterrows():
            parts.append(f"<tr><td>{r['bucket']}</td><td>{r['items']:,}</td><td>{r['avg_alipay']:.1f}</td><td>{r['avg_conversion']*100:.2f}%</td></tr>")
        parts.append("</table>")
        parts.append('<img src="data:image/png;base64,' + _img_b64(os.path.join(REPORT_DIR, "conversion_correlation.png")) + '">')

    # 6. 负面口碑诊断
    parts.append("<h2>6. 负面口碑专项诊断</h2>")
    lc = d.get("leaf_cat_reputation")
    if lc is not None and len(lc):
        lc2 = lc[lc["review_cnt"] >= 200].sort_values("pos_rate").head(10)
        parts.append("<p>叶子类目口碑最差 Top10：</p><table><tr><th>叶子类目</th><th>评论数</th><th>正向率</th><th>高置信负面占比</th></tr>")
        for _, r in lc2.iterrows():
            parts.append(f"<tr><td>{r['leaf_cat']}</td><td>{r['review_cnt']:,}</td><td>{r['pos_rate']:.3f}</td><td>{r['high_conf_neg_rate']:.3f}</td></tr>")
        parts.append("</table>")

    # 7. 核心关键词
    parts.append("<h2>7. 核心评价关键词与主题体系</h2>")
    gp = d.get("global_pos_words"); gn = d.get("global_neg_words")
    if gp is not None and len(gp):
        parts.append("<h3>全域正向核心词 Top20</h3><p>" + "、".join(gp["word"].head(20)) + "</p>")
    if gn is not None and len(gn):
        parts.append("<h3>全域负向核心词 Top20</h3><p>" + "、".join(gn["word"].head(20)) + "</p>")
    ts = d.get("theme_keyword_stats")
    if ts is not None and len(ts):
        parts.append(img("theme_stats.png"))
        parts.append("<table><tr><th>主题</th><th>正向核心词</th><th>负向核心词</th><th>正向占比</th></tr>")
        for _, r in ts.iterrows():
            parts.append(f"<tr><td>{r['theme']}</td><td>{r['positive']}</td><td>{r['negative']}</td><td>{r['pos_ratio']:.2f}</td></tr>")
        parts.append("</table>")

    parts.append("</body></html>")
    return "\n".join(parts)


def main():
    _set_chinese_font()
    print("=" * 60)
    print("评论口碑分析报告生成")
    print("=" * 60)
    d = load_all()
    chart_paths = make_charts(d)
    conv = compute_conversion(d)
    html = build_html(d, chart_paths, conv)
    out = os.path.join(REPORT_DIR, "comment_reputation_analysis_report.html")
    with open(out, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"  报告已生成: {out}")
    print(f"  图表: {REPORT_DIR}/")


if __name__ == "__main__":
    main()
