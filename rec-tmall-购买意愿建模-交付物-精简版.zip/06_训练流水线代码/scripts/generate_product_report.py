"""
商品与品类运营深度分析报告生成器
==================================
汇总类目/品牌、卖家、长尾三个模块结果，输出 HTML 报告。

输入: reports/ 下的各模块 CSV（category_brand / seller / longtail 生成）
输出: reports/product_operations_analysis_report.html
"""
import os, sys, warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import REPORTS_DIR

R = REPORTS_DIR

# ═══════════════════════════════════════════════════════════════
# 加载各模块结果
# ═══════════════════════════════════════════════════════════════
parent_cat = pd.read_csv(os.path.join(R, "parent_category_metrics.csv"))
leaf_cat = pd.read_csv(os.path.join(R, "leaf_category_metrics.csv"))
rank_traffic = pd.read_csv(os.path.join(R, "category_rank_traffic.csv"))
rank_sales = pd.read_csv(os.path.join(R, "category_rank_sales.csv"))
rank_conv = pd.read_csv(os.path.join(R, "category_rank_conversion.csv"))
cat_structure = pd.read_csv(os.path.join(R, "category_structure.csv"))
brand_metrics = pd.read_csv(os.path.join(R, "brand_metrics.csv"))
brand_conc = pd.read_csv(os.path.join(R, "brand_concentration.csv"))
brand_tiers = pd.read_csv(os.path.join(R, "brand_tiers.csv"))
top_brand_layout = pd.read_csv(os.path.join(R, "top_brand_category_layout.csv"))

seller_metrics = pd.read_csv(os.path.join(R, "seller_metrics.csv"))
seller_conc = pd.read_csv(os.path.join(R, "seller_concentration.csv"))
seller_tiers = pd.read_csv(os.path.join(R, "seller_tiers.csv"))
seller_compare = pd.read_csv(os.path.join(R, "seller_tier_compare.csv"))
seller_head_layout = pd.read_csv(os.path.join(R, "seller_head_layout.csv"))

head_contrib = pd.read_csv(os.path.join(R, "longtail_head_contribution.csv"))
power_law = pd.read_csv(os.path.join(R, "longtail_power_law.csv"))
longtail_value = pd.read_csv(os.path.join(R, "longtail_value.csv"))
invalid_tail = pd.read_csv(os.path.join(R, "invalid_longtail_profile.csv"))

# ═══════════════════════════════════════════════════════════════
# 提取关键指标
# ═══════════════════════════════════════════════════════════════
def val(df, cond_col, cond_val, target):
    row = df[df[cond_col] == cond_val]
    return row[target].values[0] if not row.empty else 0

def fmt(v, spec=".3f"):
    """安全格式化，NaN 显示为 —"""
    try:
        if pd.isna(v):
            return "—"
        return format(float(v), spec)
    except (TypeError, ValueError):
        return "—"

# 类目
n_parent = len(parent_cat)
n_leaf = len(leaf_cat)
top_flow_cat = parent_cat.head(1)["parent_cat"].values[0]
top_sales_cat = parent_cat.sort_values("sales_cnt", ascending=False).head(1)["parent_cat"].values[0]
_conv_leaf = leaf_cat[leaf_cat["click_cnt"] >= 10000].sort_values("click_to_alipay_rate", ascending=False).head(1)
top_conv_cat = _conv_leaf["category"].values[0]
top_conv_rate = _conv_leaf["click_to_alipay_rate"].values[0]

# 品牌
n_brand_labeled = int(val(brand_conc, "指标", "流量(点击)集中度", "品牌总数"))
brand_cr5_sales = val(brand_conc, "指标", "销量(成交)集中度", "CR5%")
brand_cr20_sales = val(brand_conc, "指标", "销量(成交)集中度", "CR20%")
head_brand_cnt = int(brand_tiers[brand_tiers["tier"] == "头部"]["品牌数量"].values[0])
head_brand_sales_share = float(brand_tiers[brand_tiers["tier"] == "头部"]["销量贡献%"].values[0])
single_brand = int((top_brand_layout["布局类型"] == "单一品类深耕").sum())
multi_brand = int((top_brand_layout["布局类型"] == "多品类扩张").sum())

# 卖家
n_seller = len(seller_metrics)
seller_cr10 = val(seller_conc, "指标", "销量(成交)集中度", "CR10%")
seller_cr50 = val(seller_conc, "指标", "销量(成交)集中度", "CR50%")
head_seller_cnt = int(seller_tiers[seller_tiers["tier"] == "头部"]["卖家数量"].values[0])
head_seller_sales_share = float(seller_tiers[seller_tiers["tier"] == "头部"]["销量贡献%"].values[0])
head_conv = float(seller_compare[seller_compare["卖家层级"] == "头部卖家"]["点击购买转化率%"].values[0])
waist_conv = float(seller_compare[seller_compare["卖家层级"] == "腰部卖家"]["点击购买转化率%"].values[0])
head_blast = float(seller_compare[seller_compare["卖家层级"] == "头部卖家"]["爆款占比%"].values[0])
waist_blast = float(seller_compare[seller_compare["卖家层级"] == "腰部卖家"]["爆款占比%"].values[0])
head_click_per_item = float(seller_compare[seller_compare["卖家层级"] == "头部卖家"]["品均点击(流量效率)"].values[0])
waist_click_per_item = float(seller_compare[seller_compare["卖家层级"] == "腰部卖家"]["品均点击(流量效率)"].values[0])

# 头部卖家品类布局
head_seller_single = int(seller_head_layout["单一品类垂直卖家数"].values[0])
head_seller_multi = int(seller_head_layout["多品类综合卖家数"].values[0])
head_seller_match = float(seller_head_layout["主营类目匹配平台优势品类率%"].values[0])

# 品牌口径（CR 分母说明）
unlabeled_sales = float(brand_metrics[brand_metrics["brand_label"] == "未标注"]["sales_cnt"].values[0])
total_sales_all = float(brand_metrics["sales_cnt"].sum())
labeled_sales = total_sales_all - unlabeled_sales
brand_cr5_all = (brand_cr5_sales / 100 * labeled_sales) / total_sales_all * 100
brand_cr20_all = (brand_cr20_sales / 100 * labeled_sales) / total_sales_all * 100

# 类目35 品牌缺失
total_items = int(cat_structure["商品数"].sum())
cat35_items = int(cat_structure[cat_structure["父类目"] == 35]["商品数"].values[0]) if 35 in cat_structure["父类目"].values else 0
cat35_share = cat35_items / total_items * 100

# 长尾（Gini / 幂律拟合从 longtail_power_law.csv 读取，避免硬编码）
def pw_val(metric, col):
    row = power_law[power_law["指标"] == metric]
    return row[col].values[0] if not row.empty else float("nan")

gini_flow = float(pw_val("流量(点击)", "Gini系数"))
gini_sales = float(pw_val("销量(成交)", "Gini系数"))
alpha_flow = pw_val("流量(点击)", "幂律指数α")
alpha_sales = pw_val("销量(成交)", "幂律指数α")
r2_flow = pw_val("流量(点击)", "拟合R²")
r2_sales = pw_val("销量(成交)", "拟合R²")
head20_flow = float(head_contrib[head_contrib["分层"] == "头部20%"]["流量贡献%"].values[0])
head20_sales = float(head_contrib[head_contrib["分层"] == "头部20%"]["销量贡献%"].values[0])
head5_sales = float(head_contrib[head_contrib["分层"] == "头部5%"]["销量贡献%"].values[0])
tail80_sales = float(head_contrib[head_contrib["分层"] == "尾部80%"]["销量贡献%"].values[0])
invalid_pct = float(invalid_tail["占全量商品比%"].values[0])
invalid_exposure_pct = float(invalid_tail["无效长尾中有曝光未成交商品占比%"].values[0])
invalid_cnt = int(invalid_tail["无效长尾(零成交)商品数"].values[0])
tail_leaf = int(longtail_value[longtail_value["商品分层"] == "长尾商品(后80%)"]["覆盖叶子类目数"].values[0])
head_leaf = int(longtail_value[longtail_value["商品分层"] == "头部商品(前20%)"]["覆盖叶子类目数"].values[0])
tail_only_leaf = n_leaf - head_leaf  # 长尾独有、头部未覆盖的细分叶子类目数

# ═══════════════════════════════════════════════════════════════
# 生成 HTML
# ═══════════════════════════════════════════════════════════════
def table_from_df(df, classes="data-table", max_rows=None):
    if max_rows:
        df = df.head(max_rows)
    return df.to_html(index=False, classes=classes, border=0, float_format="%.2f", na_rep="—")

html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>商品与品类运营深度分析报告 — Rec-Tmall</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Arial Unicode MS", sans-serif; background: #f5f7fa; color: #2c3e50; line-height: 1.8; }}
  .container {{ max-width: 1200px; margin: 0 auto; padding: 40px 20px; }}
  .header {{ background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); color: white; padding: 60px 40px; border-radius: 12px; margin-bottom: 40px; }}
  .header h1 {{ font-size: 30px; margin-bottom: 10px; }}
  .header .subtitle {{ font-size: 15px; opacity: 0.8; }}
  .section {{ background: white; border-radius: 12px; padding: 40px; margin-bottom: 30px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }}
  .section h2 {{ font-size: 24px; border-left: 4px solid #0f3460; padding-left: 16px; margin-bottom: 24px; color: #0f3460; }}
  .section h3 {{ font-size: 18px; margin: 24px 0 12px; color: #16213e; }}
  .kpi-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }}
  .kpi-card {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; text-align: center; }}
  .kpi-card.green {{ background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); }}
  .kpi-card.orange {{ background: linear-gradient(135deg, #f2994a 0%, #f2c94c 100%); }}
  .kpi-card.red {{ background: linear-gradient(135deg, #eb5757 0%, #f2994a 100%); }}
  .kpi-card.blue {{ background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); }}
  .kpi-value {{ font-size: 26px; font-weight: bold; }}
  .kpi-label {{ font-size: 13px; opacity: 0.9; margin-top: 4px; }}
  .data-table {{ width: 100%; border-collapse: collapse; margin: 16px 0; font-size: 13px; }}
  .data-table th {{ background: #f0f4ff; padding: 10px 12px; text-align: left; font-weight: 600; border-bottom: 2px solid #d0d8f0; }}
  .data-table td {{ padding: 8px 12px; border-bottom: 1px solid #e8ecf4; }}
  .data-table tr:hover {{ background: #f8faff; }}
  .finding-box {{ background: #fff8e1; border-left: 4px solid #ffa000; padding: 16px 20px; margin: 16px 0; border-radius: 0 8px 8px 0; }}
  .finding-box.suggestion {{ background: #e8f5e9; border-left-color: #4caf50; }}
  .finding-box.warning {{ background: #fce4ec; border-left-color: #e53935; }}
  .chart-container {{ text-align: center; margin: 24px 0; }}
  .chart-container img {{ max-width: 100%; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }}
  .toc {{ background: #f0f4ff; padding: 20px 30px; border-radius: 8px; margin-bottom: 30px; }}
  .toc a {{ color: #0f3460; text-decoration: none; }}
  .toc ol {{ padding-left: 20px; }}
  .toc li {{ margin: 6px 0; }}
  .highlight {{ background: #fff3cd; padding: 2px 6px; border-radius: 3px; font-weight: 600; }}
</style>
</head>
<body>
<div class="container">

<div class="header">
  <h1>商品与品类运营深度分析报告</h1>
  <div class="subtitle">
    数据集: Tianchi Rec-Tmall &nbsp;|&nbsp;
    商品规模: 8,133,507 &nbsp;|&nbsp;
    类目: {n_parent} 父类目 / {n_leaf} 叶子类目 &nbsp;|&nbsp;
    品牌: {n_brand_labeled:,}（另 200 万商品未标注）&nbsp;|&nbsp;
    卖家: {n_seller:,}
  </div>
</div>

<div class="toc">
  <strong>报告目录</strong>
  <ol>
    <li><a href="#sec1">类目格局分析</a></li>
    <li><a href="#sec2">品牌绩效与梯队</a></li>
    <li><a href="#sec3">卖家能力与头部卖家特征</a></li>
    <li><a href="#sec4">商品结构与长尾效应</a></li>
    <li><a href="#sec5">综合结论与运营建议</a></li>
  </ol>
</div>

<!-- ═══ 1. 类目格局 ═══ -->
<div class="section" id="sec1">
  <h2>1. 类目格局分析</h2>

  <h3>1.1 核心品类识别</h3>
  <div class="kpi-grid">
    <div class="kpi-card blue">
      <div class="kpi-value">类目 {int(top_flow_cat)}</div>
      <div class="kpi-label">核心流量品类（点击量第一）</div>
    </div>
    <div class="kpi-card green">
      <div class="kpi-value">类目 {int(top_sales_cat)}</div>
      <div class="kpi-label">核心成交品类（销量第一）</div>
    </div>
    <div class="kpi-card orange">
      <div class="kpi-value">叶子类目 {top_conv_cat}</div>
      <div class="kpi-label">高转化潜力叶子类目（{top_conv_rate:.2f}%）</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-value">{n_leaf:,}</div>
      <div class="kpi-label">叶子类目总数</div>
    </div>
  </div>

  <div class="chart-container">
    <img src="category_brand_charts/category_brand_overview.png" alt="类目与品牌总览">
  </div>

  <h3>1.2 流量规模榜 Top10（叶子类目）</h3>
  {table_from_df(rank_traffic, max_rows=10)}

  <h3>1.3 销量规模榜 Top10（叶子类目）</h3>
  {table_from_df(rank_sales, max_rows=10)}

  <h3>1.4 转化效率榜 Top10（叶子类目，点击≥1万）</h3>
  {table_from_df(rank_conv, max_rows=10)}

  <h3>1.5 类目结构（丰富度与竞争格局）</h3>
  {table_from_df(cat_structure.sort_values("商品数", ascending=False).head(15))}

  <div class="finding-box">
    <strong>核心发现：</strong>
    90 个父类目、{n_leaf:,} 个叶子类目，类目结构高度不均衡——头部父类目（如类目 {int(top_flow_cat)}）以少数叶子类目承载海量流量，
    而长尾类目数量庞大但商品稀疏。<strong>流量、成交、转化效率三类榜单的重合度低</strong>，说明"流量大"的品类不一定"转化好"，
    存在一批"高流量低转化"与"低流量高转化"的错配品类，是运营干预的优先目标。
  </div>
</div>

<!-- ═══ 2. 品牌绩效 ═══ -->
<div class="section" id="sec2">
  <h2>2. 品牌绩效与梯队划分</h2>

  <div class="kpi-grid">
    <div class="kpi-card blue">
      <div class="kpi-value">{n_brand_labeled:,}</div>
      <div class="kpi-label">入驻品牌数（有标注）</div>
    </div>
    <div class="kpi-card orange">
      <div class="kpi-value">{brand_cr5_sales:.2f}%</div>
      <div class="kpi-label">品牌销量 CR5</div>
    </div>
    <div class="kpi-card red">
      <div class="kpi-value">{brand_cr20_sales:.2f}%</div>
      <div class="kpi-label">品牌销量 CR20</div>
    </div>
    <div class="kpi-card green">
      <div class="kpi-value">{head_brand_sales_share:.1f}%</div>
      <div class="kpi-label">头部品牌（Top5%）销量贡献</div>
    </div>
  </div>

  <h3>2.1 品牌梯队市场贡献</h3>
  {table_from_df(brand_tiers)}

  <div class="chart-container">
    <img src="category_brand_charts/top_brand_layout.png" alt="头部品牌类目布局">
  </div>

  <div class="finding-box">
    <strong>核心发现：</strong>
    品牌市场 <span class="highlight">极度分散</span>——{n_brand_labeled:,} 个品牌，CR5 销量仅 {brand_cr5_sales:.2f}%、CR20 仅 {brand_cr20_sales:.2f}%。
    头部品牌（{head_brand_cnt:,} 个，Top5%）贡献了 {head_brand_sales_share:.1f}% 的销量，但其中 <span class="highlight">{single_brand:,} 个是单一品类深耕</span>、
    {multi_brand:,} 个是多品类扩张，说明头部品牌的壁垒主要来自"类目内深耕"而非"摊大饼"。
    另外约 200 万商品（24.6%）无品牌标注，是品牌化运营的空白区。
  </div>

  <div class="finding-box warning">
    <strong>口径与数据质量说明：</strong>
    ① 上表 CR5 / CR20 的分母仅含<strong>有品牌标注</strong>的销量（{labeled_sales/10000:.0f} 万单），已排除「未标注」品牌的 {unlabeled_sales/10000:.0f} 万单；
    若相对全平台（{total_sales_all/10000:.0f} 万单），CR5 约 {brand_cr5_all:.2f}%、CR20 约 {brand_cr20_all:.2f}%，分散程度更高。
    ② 父类目 35（约 {cat35_items/10000:.0f} 万商品、占全量 {cat35_share:.1f}%）的商品<strong>品牌字段几乎全部缺失</strong>（入驻品牌数 = 0），
    该品类的品牌梯队分析会失真，上述品牌结论对类目 35 不适用。
  </div>
</div>

<!-- ═══ 3. 卖家能力 ═══ -->
<div class="section" id="sec3">
  <h2>3. 卖家能力与头部卖家特征</h2>

  <div class="kpi-grid">
    <div class="kpi-card blue">
      <div class="kpi-value">{n_seller:,}</div>
      <div class="kpi-label">卖家总数</div>
    </div>
    <div class="kpi-card orange">
      <div class="kpi-value">{seller_cr10:.2f}%</div>
      <div class="kpi-label">卖家销量 CR10</div>
    </div>
    <div class="kpi-card red">
      <div class="kpi-value">{seller_cr50:.2f}%</div>
      <div class="kpi-label">卖家销量 CR50</div>
    </div>
    <div class="kpi-card green">
      <div class="kpi-value">{head_seller_sales_share:.1f}%</div>
      <div class="kpi-label">头部卖家（Top5%）销量贡献</div>
    </div>
  </div>

  <h3>3.1 卖家梯队市场贡献</h3>
  {table_from_df(seller_tiers)}

  <h3>3.2 头部 vs 腰部卖家运营效率对比</h3>
  {table_from_df(seller_compare)}

  <h3>3.3 头部卖家品类布局</h3>
  <div class="finding-box">
    <strong>头部卖家品类布局：</strong>
    头部卖家（{head_seller_cnt:,} 个）中 <span class="highlight">{head_seller_single:,} 个是单品类垂直深耕</span>（{head_seller_single/head_seller_cnt*100:.1f}%）、
    {head_seller_multi:,} 个是多品类综合布局（{head_seller_multi/head_seller_cnt*100:.1f}%），
    主营类目与平台优势品类（销量 Top10 父类目）的匹配率为 <span class="highlight">{head_seller_match:.1f}%</span>，
    说明头部卖家的成功路径是「垂直深耕 + 切入平台优势品类」，而非全品类摊大饼。
  </div>

  <div class="chart-container">
    <img src="seller_charts/seller_overview.png" alt="卖家分析总览">
  </div>

  <div class="finding-box">
    <strong>核心发现：</strong>
    卖家格局同样分散（CR10 {seller_cr10:.2f}%、CR50 {seller_cr50:.2f}%），不存在垄断性大卖家。
    头部卖家（{head_seller_cnt:,} 个）的壁垒在<strong>规模与爆款集中度</strong>——品均点击 {head_click_per_item:.0f} vs 腰部 {waist_click_per_item:.0f}、
    爆款占比 {head_blast:.2f}% vs {waist_blast:.2f}%（近翻倍），但<strong>转化率反而更低</strong>（{head_conv:.3f}% vs 腰部 {waist_conv:.3f}%）；
    腰部卖家转化更精准、是"小而美"型，瓶颈在流量规模。叠加品类布局看，头部卖家 8 成是单品类垂直深耕。
  </div>
</div>

<!-- ═══ 4. 商品结构与长尾 ═══ -->
<div class="section" id="sec4">
  <h2>4. 商品结构与长尾效应</h2>

  <div class="kpi-grid">
    <div class="kpi-card blue">
      <div class="kpi-value">{gini_flow:.3f}</div>
      <div class="kpi-label">流量侧 Gini 系数</div>
    </div>
    <div class="kpi-card orange">
      <div class="kpi-value">{gini_sales:.3f}</div>
      <div class="kpi-label">销量侧 Gini 系数</div>
    </div>
    <div class="kpi-card red">
      <div class="kpi-value">{head20_flow:.1f}%</div>
      <div class="kpi-label">头部20%商品流量占比</div>
    </div>
    <div class="kpi-card green">
      <div class="kpi-value">{invalid_pct:.1f}%</div>
      <div class="kpi-label">无效长尾（零成交）占比</div>
    </div>
  </div>

  <h3>4.1 幂律分布拟合结果</h3>
  <table class="data-table">
    <tr><th>指标</th><th>Gini 系数</th><th>幂律指数 α</th><th>拟合 R²</th></tr>
    <tr><td>流量（点击）</td><td>{fmt(gini_flow)}</td><td>{fmt(alpha_flow, '.4f')}</td><td>{fmt(r2_flow, '.4f')}</td></tr>
    <tr><td>销量（成交）</td><td>{fmt(gini_sales)}</td><td>{fmt(alpha_sales, '.4f')}</td><td>{fmt(r2_sales, '.4f')}</td></tr>
  </table>

  <h3>4.2 头部/长尾商品贡献分层</h3>
  {table_from_df(head_contrib)}

  <h3>4.3 长尾商品价值评估</h3>
  {table_from_df(longtail_value)}

  <div class="chart-container">
    <img src="longtail_charts/longtail_overview.png" alt="长尾分析总览">
  </div>

  <div class="finding-box">
    <strong>核心发现：</strong>
    商品热度呈现典型长尾，<span class="highlight">流量侧比销量侧更集中</span>（Gini {gini_flow:.3f} vs {gini_sales:.3f}），
    头部 20% 商品贡献 {head20_flow:.1f}% 流量、{head20_sales:.1f}% 销量，基本符合"二八定律"（流量侧甚至更极端）。
    销量侧长尾比流量侧更"值钱"——尾部 80% 商品贡献了 {tail80_sales:.1f}% 销量。
    幂律拟合 R² 均超 0.95（流量 α={fmt(alpha_flow, '.2f')}、销量 α={fmt(alpha_sales, '.2f')}），
    印证流量与销量分布均服从幂律；销量侧 α 更大（2.77 vs 1.43），说明销量向头部收敛更陡、长尾更"扁平"。
  </div>

  <div class="finding-box">
    <strong>口径说明：</strong>
    4.3 表中「头部商品(前 20%)动销率 100%」是<strong>定义导致</strong>的——按销量降序取前 20%，而全平台零成交商品仅占 40%，
    故前 20% 必然全部有成交，并非"头部商品全都好卖"；对比长尾的动销率（49.5%）才是真实差异所在。
  </div>

  <div class="finding-box warning">
    <strong>长尾结构警示：</strong>
    全平台 {invalid_pct:.1f}% 的商品（{invalid_cnt/10000:.1f} 万）是<strong>零成交的无效长尾</strong>，
    其中 <span class="highlight">{invalid_exposure_pct:.1f}% 是有曝光（有点击）但未转化</span>——说明这些商品不是"没人看"，而是"看了不买"，
    是商品汰换和详情页优化的重点对象。长尾商品覆盖 {tail_leaf:,} 个叶子类目，其中 {tail_only_leaf:,} 个是长尾独有的细分叶子类目（头部未覆盖），
    证明确实承担了满足差异化细分需求的作用，不能简单"一刀切"下架。
  </div>
</div>

<!-- ═══ 5. 综合结论与建议 ═══ -->
<div class="section" id="sec5">
  <h2>5. 综合结论与运营建议</h2>

  <h3>5.1 四大模块结论</h3>
  <table class="data-table">
    <tr><th>模块</th><th>核心结论</th></tr>
    <tr><td>类目格局</td><td>90 父类目 / {n_leaf:,} 叶子类目；流量、成交、转化三类榜单错配，存在高流量低转化品类</td></tr>
    <tr><td>品牌绩效</td><td>品牌极度分散（CR20 {brand_cr20_sales:.2f}%）；头部品牌靠类目深耕建立壁垒；24.6% 商品无品牌标注</td></tr>
    <tr><td>卖家能力</td><td>卖家格局分散（CR50 {seller_cr50:.2f}%）；头部卖家优势在规模与爆款集中度，转化率反而不及腰部</td></tr>
    <tr><td>商品结构</td><td>典型长尾，流量侧更集中；40% 商品是无效长尾，其中 99% 有曝光未转化</td></tr>
  </table>

  <h3>5.2 针对性运营建议</h3>

  <div class="finding-box suggestion">
    <strong>1. 品类错配治理（类目层）</strong>
    <ul>
      <li>对"高流量低转化"品类做详情页与价格带诊断，排查点击承接能力</li>
      <li>对"高转化低流量"品类加大曝光资源倾斜，复制其转化优势</li>
      <li>优先扶持高转化潜力品类（点击≥1万门槛下的高转化叶子类目）</li>
    </ul>
  </div>

  <div class="finding-box suggestion">
    <strong>2. 品牌梯队运营（品牌层）</strong>
    <ul>
      <li>腰部品牌是最大增量池（17,873 个），扶持其向头部跃迁</li>
      <li>头部品牌做"类目深耕"标杆复制，避免盲目多品类扩张</li>
      <li>推进 200 万"无品牌标注"商品的品牌化，填补运营空白</li>
    </ul>
  </div>

  <div class="finding-box suggestion">
    <strong>3. 卖家能力建设（卖家层）</strong>
    <ul>
      <li>头部卖家的核心资产是"规模 + 爆款集中度"，将爆款打造与流量获取方法论沉淀为腰部卖家赋能</li>
      <li>腰部卖家转化率反而更高（{waist_conv:.3f}% vs 头部 {head_conv:.3f}%），瓶颈在流量规模——主攻曝光与流量获取，把转化优势放大</li>
    </ul>
  </div>

  <div class="finding-box suggestion">
    <strong>4. 长尾商品汰换与激活（商品层）</strong>
    <ul>
      <li>无效长尾中"有曝光未成交"（326 万）优先诊断：是价格、详情、还是选品问题</li>
      <li>完全零交互商品（2.8 万）直接汰换，释放库存与流量</li>
      <li>长尾覆盖了更多细分叶子类目，保留其"差异化需求"价值，用推荐系统精准匹配而非简单下架</li>
    </ul>
  </div>
</div>

<hr style="margin: 40px 0; opacity: 0.3;">
<p style="text-align:center; color:#999; font-size:13px;">
  Generated by Rec-Tmall Product Operations Analysis Pipeline &nbsp;|&nbsp; 2026-08-21
</p>

</div>
</body>
</html>
"""

report_path = os.path.join(R, "product_operations_analysis_report.html")
with open(report_path, "w", encoding="utf-8") as f:
    f.write(html)

print(f"报告已生成: {report_path}")
print(f"文件大小: {os.path.getsize(report_path):,} bytes")
print("完成!")
