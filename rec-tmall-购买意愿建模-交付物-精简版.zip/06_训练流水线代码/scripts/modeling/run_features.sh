#!/bin/bash
# 购买意愿与转化预测：特征工程 + 样本构建 一键入口
# 三档推进：debug（万级日志）→ dev（1% 用户）→ full（全量）
# 用法: bash scripts/modeling/run_features.sh [debug|dev|full]
set -e

MODE="${1:-debug}"

PROJECT_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$PROJECT_ROOT"

# 优先用 venv 里的 Python（与项目其他 run_*.sh 一致）
PY="python"
if [ -f venv/bin/python ]; then
    PY="venv/bin/python"
fi

echo "=========================================================="
echo "建模 pipeline: 特征工程 + 样本构建  (mode=$MODE)"
echo "=========================================================="

echo "[1/4] 每日行为中间表 (日志 → user-item-date 粒度)"
"$PY" scripts/modeling/aggregate.py --mode "$MODE"

echo "[2/4] 特征 + 标签 + 数据集组装 (按断面 → train/val/test)"
"$PY" scripts/modeling/dataset.py --mode "$MODE"

echo "[3/4] 泄露校验 + 分布一致性"
"$PY" scripts/modeling/leakage_check.py --mode "$MODE"

echo "[4/4] 特征预处理 (缺失填充/截断/标准化/相关性筛选，train 拟合)"
"$PY" scripts/modeling/preprocess.py --mode "$MODE"

echo "=========================================================="
echo "完成。产物: data/modeling/daily|dataset|preprocessed|reports"
echo "=========================================================="
