"""
多维度模型效果评估（第二部分 a.2）
====================================
基于 train.py 落盘的 test 预测做三类评估：
  1. 核心指标：AUC / AP / 精确率 / 召回率 / F1 / 准确率 + PR 曲线（不平衡样本核心依据）
  2. 分维度泛化：一级类目 / 用户活跃度层级 / 商品热度层级分别算 AUC，识别薄弱场景
  3. 横向对比：预测精度 / 训练效率 / 推理效率 / 可解释性 四维度

切分维度与阈值全部来自 config.EVAL_DIMENSIONS，换数据只改 config。
输出: data/modeling/metrics/{mode}/evaluation.json
用法: python scripts/modeling/evaluate.py --mode debug|dev|full
"""
import os
import sys
import json
import argparse
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.modeling.config import *
from scripts.modeling import model_utils as mu
from sklearn.metrics import roc_auc_score


# 模型可解释性定性评估（模型固有属性，非数据相关配置）
MODEL_INTERPRETABILITY = {
    "lr": "高（线性系数，特征方向与幅度直接可读）",
    "gbdt": "中（gain 重要性可排序，非线性交互难直读）",
    "xgb": "中（gain 重要性可排序，非线性交互难直读）",
}


def split_groups(col, y, cfg):
    """按 config 维度把样本下标分层：categorical 取 top_k 值，quantile 分 n_bins 层"""
    groups = {}
    if cfg["type"] == "categorical":
        top = col.value_counts().head(cfg.get("top_k", 10)).index.tolist()
        for v in top:
            idx = np.where(col.values == v)[0]
            if len(idx) > 0:
                groups[f"cat_{v}"] = idx
        top_set = set(top)
        others = np.where(~col.isin(top_set).values)[0]
        if len(others) > 0:
            groups["cat_其他"] = others
    elif cfg["type"] == "quantile":
        n = cfg.get("n_bins", 5)
        ranked = col.rank(method="first")
        q = pd.qcut(ranked, n, labels=False)
        for b in range(n):
            idx = np.where(q.values == b)[0]
            if len(idx) > 0:
                groups[f"bin_{b + 1}"] = idx
    return groups


def evaluate(mode):
    import joblib
    tr = joblib.load(os.path.join(MODEL_DIR, mode, "test_predictions.pkl"))
    y_test = tr["label"]
    probas = tr["proba"]
    meta = tr["meta"]

    with open(os.path.join(MODEL_DIR, mode, "val_metrics.json"), encoding="utf-8") as f:
        vm = json.load(f)

    model_names = list(probas.keys())

    # 1) 核心指标 + PR 曲线
    print("[evaluate] 核心指标（test 集）...")
    test_metrics, pr_data = {}, {}
    for name in model_names:
        test_metrics[name] = mu.compute_metrics(y_test, probas[name])
        prec, recall, _ = mu.compute_pr_curve(y_test, probas[name])
        pr_data[name] = {"precision": prec.tolist(), "recall": recall.tolist()}
        print(f"  {name}: AUC={test_metrics[name]['auc']} AP={test_metrics[name]['ap']} "
              f"F1={test_metrics[name]['f1']}")

    # 2) 分维度泛化
    print("[evaluate] 分维度泛化性...")
    dim_auc = {}
    for dim, cfg in EVAL_DIMENSIONS.items():
        col = cfg["col"]
        if col not in meta.columns:
            print(f"  跳过维度 {dim}（列 {col} 不存在）")
            continue
        groups = split_groups(meta[col], y_test, cfg)
        dim_auc[dim] = {name: {} for name in model_names}
        for gname, gidx in groups.items():
            if len(gidx) < 20 or len(np.unique(y_test[gidx])) < 2:
                continue
            for name in model_names:
                dim_auc[dim][name][gname] = round(
                    float(roc_auc_score(y_test[gidx], probas[name][gidx])), 4)
        print(f"  {dim}: {len(groups)} 层, 列 {col}")

    # 3) 横向对比
    comparison = {
        "predictive_accuracy": {n: test_metrics[n]["auc"] for n in model_names},
        "train_efficiency": {n: vm["models"][n]["train_time_sec"] for n in model_names},
        "inference_efficiency": {
            n: round(vm["models"][n]["infer_time_sec"] / max(vm["models"][n]["infer_n"], 1), 6)
            for n in model_names},
        "interpretability": {n: MODEL_INTERPRETABILITY[n] for n in model_names},
    }

    out = {
        "mode": mode,
        "best_model": vm["best_model"],
        "test_metrics": test_metrics,
        "pr_data": pr_data,
        "dim_auc": dim_auc,
        "comparison": comparison,
    }
    mu.write_json(out, os.path.join(METRICS_DIR, mode, "evaluation.json"))
    print(f"[evaluate] 完成 -> {os.path.join(METRICS_DIR, mode, 'evaluation.json')}")
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=MODES, default="dev")
    args = parser.parse_args()

    pred_path = os.path.join(MODEL_DIR, args.mode, "test_predictions.pkl")
    if not os.path.exists(pred_path):
        print(f"[evaluate] 未找到 {pred_path}，跳过（先跑 train.py）。")
        return
    evaluate(args.mode)


if __name__ == "__main__":
    main()
