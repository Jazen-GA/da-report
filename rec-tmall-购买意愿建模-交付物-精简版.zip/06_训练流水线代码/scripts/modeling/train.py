"""
主样本基线模型训练 + 调优（第二部分 a.1）
==========================================
对 preprocessed 样本训练三类基线模型：
  - LR     (sklearn LogisticRegression)：线性基准，配标准化数值 + 目标编码类别 + 交叉特征
  - GBDT   (LightGBM)：梯度提升树，val 早停
  - XGBoost：高性能极端梯度提升，val 早停，scale_pos_weight 按负:正比动态算

统一调优策略：config.MODEL_PARAMS 集中超参；树模型 eval_set 早停防过拟合；
不平衡用 class_weight（LR/GBDT）或 scale_pos_weight（XGB）。

输出:
  data/modeling/model/{mode}/{name}.joblib   三模型文件
  data/modeling/model/{mode}/val_metrics.json  val 指标 + 训练耗时 + 最优模型 + feature_names
  data/modeling/model/{mode}/test_predictions.pkl  test 标签/概率/元数据（供 evaluate.py 复用）
用法: python scripts/modeling/train.py --mode debug|dev|full
"""
import os
import sys
import time
import argparse
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.modeling.config import *
from scripts.modeling import model_utils as mu


def train_all(mode):
    train, val, test = mu.load_all(mode)
    y_train = train["label"].values
    y_val = val["label"].values
    y_test = test["label"].values

    # 目标编码：train OOF（fold 内），val/test 用全 train 统计（防泄露）
    print(f"[train] 目标编码（{len(CAT_COLS)} 个类别特征, {TARGET_ENCODING_FOLDS} fold）...")
    te_train = mu.target_encode_train(train[CAT_COLS], train["label"])
    te_val = mu.target_encode_apply(val[CAT_COLS], train[CAT_COLS], train["label"])
    te_test = mu.target_encode_apply(test[CAT_COLS], train[CAT_COLS], train["label"])

    results = {}
    probas = {}
    best_name, best_auc = None, -1.0

    for name in ["lr", "gbdt", "xgb"]:
        cross = LR_CROSS_FEATURES if name == "lr" else None
        X_train, names = mu.build_feature_matrix(train, te_train, cross)
        X_val, _ = mu.build_feature_matrix(val, te_val, cross)
        X_test, _ = mu.build_feature_matrix(test, te_test, cross)
        print(f"\n[train] {name}: {X_train.shape[0]:,} 训练样本 × {X_train.shape[1]} 特征")

        t0 = time.time()
        model, val_prob = mu.fit_model(name, X_train, y_train, X_val, y_val)
        train_time = time.time() - t0

        val_metrics = mu.compute_metrics(y_val, val_prob)
        t1 = time.time()
        test_prob = model.predict_proba(X_test)[:, 1]
        infer_time = time.time() - t1

        best_iter = getattr(model, "best_iteration_", None) or getattr(model, "best_iteration", None)
        mu.save_model(model, os.path.join(MODEL_DIR, mode, f"{name}.joblib"))
        probas[name] = test_prob

        results[name] = {
            "val_metrics": val_metrics,
            "train_time_sec": round(train_time, 2),
            "infer_time_sec": round(infer_time, 3),
            "infer_n": int(X_test.shape[0]),
            "best_iteration": best_iter,
            "n_features": int(X_train.shape[1]),
            "feature_names": names,
        }
        print(f"  val AUC={val_metrics['auc']} AP={val_metrics['ap']} F1={val_metrics['f1']} "
              f"耗时 {train_time:.1f}s (best_iter={best_iter})")

        if val_metrics["auc"] > best_auc:
            best_auc = val_metrics["auc"]
            best_name = name

    # 落盘 val 指标 + 最优模型标记
    summary = {
        "mode": mode,
        "best_model": best_name,
        "best_val_auc": best_auc,
        "models": results,
    }
    mu.write_json(summary, os.path.join(MODEL_DIR, mode, "val_metrics.json"))

    # 保存推理包（整改 #2）：封装最优模型名 + 目标编码映射 + 特征名 + 交叉特征，
    # 供 infer.py 独立推理，不再重读 train 集重算目标编码。
    import joblib
    bundle = {
        "best_model": best_name,
        "target_encoding_map": mu.target_encode_fit(train[CAT_COLS], train["label"]),
        "global_mean": float(train["label"].mean()),
        "feature_names": results[best_name]["feature_names"],
        "cat_cols": CAT_COLS,
        "cross_features": LR_CROSS_FEATURES if best_name == "lr" else None,
    }
    joblib.dump(bundle, os.path.join(MODEL_DIR, mode, "inference_bundle.joblib"))

    # 落盘 test 预测（标签 + 三模型概率 + 分维度元数据），供 evaluate.py 复用
    meta_cols = ["user_id", "item_id", "parent_cat", "u_active_days", "i_click_cnt_30d"]
    meta_cols = [c for c in meta_cols if c in test.columns]
    test_result = {
        "label": y_test,
        "proba": probas,
        "meta": test[meta_cols].reset_index(drop=True),
    }
    import joblib
    os.makedirs(os.path.join(MODEL_DIR, mode), exist_ok=True)
    joblib.dump(test_result, os.path.join(MODEL_DIR, mode, "test_predictions.pkl"))

    print(f"\n[train] 完成。最优模型={best_name} (val AUC={best_auc})")
    print(f"  模型 -> {os.path.join(MODEL_DIR, mode)}")
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=MODES, default="dev")
    args = parser.parse_args()

    train_path = os.path.join(PREPROCESSED_DIR, args.mode, "train")
    if not os.path.isdir(train_path):
        print(f"[train] 未找到 preprocessed/{args.mode}/train，跳过（先跑 run_features.sh）。")
        return

    train_all(args.mode)


if __name__ == "__main__":
    main()
