"""
特征重要性分析 + 业务解释 + 特征字典（第二部分 a.3）
======================================================
基于最优模型输出：
  1. 特征重要性排序（Top 核心驱动特征）
  2. 典型样本解释（高购买意愿 vs 低购买意愿的核心特征差异）
  3. 特征字典 markdown（每个特征的计算逻辑 / 时间窗口 / 类型 / 重要性排名）

特征描述由列名规则 + 固定映射自动生成，重要性来自模型（LR 用 |coef|，树用 gain）。
输出:
  data/modeling/metrics/{mode}/feature_importance.json
  reports/modeling/{mode}_特征字典.md
用法: python scripts/modeling/feature_importance.py --mode debug|dev|full
"""
import os
import sys
import re
import json
import argparse
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.modeling.config import *
from scripts.modeling import model_utils as mu


ACTION_CN = {ACTION_CLICK: "点击", ACTION_COLLECT: "收藏", ACTION_CART: "加购", ACTION_BUY: "购买"}
ACTIONS = "|".join(ACTION_VALUES)

_FIXED_DESC = {
    "u_first_days_ago": "用户首次行为距观察窗口结束的天数",
    "u_recency_days": "用户最近一次行为距观察窗口结束的天数（近因）",
    "u_active_days": "用户观察窗口内累计活跃天数",
    "u_consecutive_active_days": "用户观察窗口内连续活跃天数",
    "u_avg_visit_interval": "用户平均访问间隔（天）",
    "u_cat_hhi": "用户品类集中度 HHI（各类目行为占比平方和）",
    "i_listing_days": "商品上架时长（以日志最早出现日期近似）",
    "i_sell_days": "商品观察窗口内动销天数（有购买行为的天数）",
    "i_sell_rate": "商品动销率（动销天数 / 观察窗口长度）",
    "i_review_cnt": "商品评论数（口碑，已剔除：无时间戳含未来信息，整改 #5）",
    "i_pos_rate": "商品好评率（口碑，已剔除：无时间戳含未来信息）",
    "i_avg_sentiment": "商品平均情感分（口碑，已剔除：无时间戳含未来信息）",
    "x_interact_days": "观察窗口内该用户-商品对交互天数",
    "x_recency_days": "该用户-商品对最近交互距观察窗口结束天数",
    "x_first_days_ago": "该用户-商品对首次交互距观察窗口结束天数",
    "x_depth": "交互深度评分（点击×1+收藏×2+加购×3+购买×4）",
    "x_has_full_path": "是否走完点击→收藏→加购完整意向路径（0/1）",
    "x_stage": "决策阶段（0仅点击/1已收藏/2已加购/3已购买）",
    "s_day_growth_7d": "用户近 7 天日均行为量环比增长率",
    "s_day_gap_median": "用户相邻活跃日间隔中位数（天）",
    "s_days_since_last_buy": "用户距最近一次购买的天数",
    "parent_cat": "商品一级类目（类别，目标编码）",
    "leaf_cat": "商品叶子类目（类别，目标编码）",
    "brand_id": "商品品牌（类别，目标编码）",
    "seller_id": "商品卖家（类别，目标编码）",
    "u_top1_cat": "用户最常交互的一级类目（类别，目标编码）",
    "u_top2_cat": "用户次常交互的一级类目（类别，目标编码）",
    "u_top3_cat": "用户第三常交互的一级类目（类别，目标编码）",
    "u_top1_brand": "用户最常交互品牌（类别，目标编码）",
    # 购物车专项特征（cart 模型专属，主样本不含）
    "cart_cnt": "观察窗口内该用户-商品对的加购次数",
    "cart_days_since": "最近一次加购距观察窗口结束的天数",
    "cart_item_total": "用户观察窗口内加购过的不同商品总数（购物车商品总数）",
    "cart_pre_path": "最近一次加购之前是否有点击/收藏（0/1）",
    "cart_same_cat": "是否同时加购同类商品（同 parent_cat 的不同商品 > 1）",
}


def describe_feature(name):
    """根据列名规则自动生成特征描述（计算逻辑 + 时间窗口）"""
    if name.endswith("_te"):
        return "类别目标编码（fold 内 OOF，该类别成交率的平滑估计）"
    if "__x__" in name:
        a, b = name.split("__x__")
        return f"交叉特征：{a} × {b}"

    m = re.match(rf"^([ui])_({ACTIONS})_cnt_(\d+)d$", name)
    if m:
        side = "用户" if m.group(1) == "u" else "商品"
        return f"{side}近 {m.group(3)} 天{ACTION_CN[m.group(2)]}次数"
    m = re.match(rf"^u_({ACTIONS})_ratio_30d$", name)
    if m:
        return f"用户近 30 天{ACTION_CN[m.group(1)]}占比（该行为次数/总行为次数）"
    m = re.match(rf"^u_({ACTIONS})_to_({ACTIONS})$", name)
    if m:
        return f"用户近 30 天转化率：{ACTION_CN[m.group(1)]} → {ACTION_CN[m.group(2)]}"
    m = re.match(rf"^i_({ACTIONS})_cnt_prev7d$", name)
    if m:
        return f"商品前 7 天（7~14 天前）{ACTION_CN[m.group(1)]}次数（环比基准）"
    m = re.match(rf"^i_({ACTIONS})_growth_7d$", name)
    if m:
        return f"商品{ACTION_CN[m.group(1)]}近 7 天环比增长率"
    m = re.match(rf"^i_({ACTIONS})_to_({ACTIONS})$", name)
    if m:
        return f"商品近 30 天转化率：{ACTION_CN[m.group(1)]} → {ACTION_CN[m.group(2)]}"
    m = re.match(rf"^x_({ACTIONS})_cnt$", name)
    if m:
        return f"观察窗口内该用户-商品对 {ACTION_CN[m.group(1)]} 次数"
    m = re.match(r"^s_day_(mean|var)_(\d+)d$", name)
    if m:
        return f"用户近 {m.group(2)} 天日均行为量{'均值' if m.group(1) == 'mean' else '方差'}"

    return _FIXED_DESC.get(name, "（未识别特征，请补充描述）")


def feature_type(name):
    if name.endswith("_te"):
        return "目标编码"
    if "__x__" in name:
        return "交叉"
    if name in CAT_COLS:
        return "类别"
    return "数值"


def run(mode):
    vm_path = os.path.join(MODEL_DIR, mode, "val_metrics.json")
    with open(vm_path, encoding="utf-8") as f:
        vm = json.load(f)
    best = vm["best_model"]
    names = vm["models"][best]["feature_names"]
    cross = LR_CROSS_FEATURES if best == "lr" else None
    print(f"[importance] 最优模型={best}, 特征数={len(names)}")

    # 重新读 test + 目标编码 + 构建特征矩阵（用于典型样本解释）
    train, val, test = mu.load_all(mode)
    te_train = mu.target_encode_train(train[CAT_COLS], train["label"])
    te_test = mu.target_encode_apply(test[CAT_COLS], train[CAT_COLS], train["label"])
    X_test, _ = mu.build_feature_matrix(test, te_test, cross)
    y_test = test["label"].values

    model = mu.load_model(os.path.join(MODEL_DIR, mode, f"{best}.joblib"))
    proba = model.predict_proba(X_test)[:, 1]

    # 1) 特征重要性
    imp = mu.feature_importance(best, model, names)
    top = imp.head(20)
    print("[importance] Top 10 特征:")
    for i, (f, s) in enumerate(imp.head(10).items()):
        print(f"  {i + 1:2d}. {f:30s} {s:.4f}")

    # 2) 单样本解释（整改 #15）：具体 user-item 的预测概率 + 关键特征取值 + 群体对比
    pos_idx = np.where(y_test == 1)[0]
    neg_idx = np.where(y_test == 0)[0]
    top_feats = imp.head(10).index.tolist()

    # 单样本：概率最高的 3 个正样本 + 概率最低的 3 个负样本，逐个给 user-item/概率/标签/关键特征取值
    sample_rows = []
    for idx_arr, order_fn, tag in [
        (pos_idx, lambda p: np.argsort(p)[::-1], "高意向正样本"),
        (neg_idx, lambda p: np.argsort(p), "低意向负样本"),
    ]:
        if len(idx_arr) == 0:
            continue
        order = order_fn(proba[idx_arr])[:3]
        for i in idx_arr[order]:
            sample_rows.append({
                "user_id": str(test["user_id"].iloc[i]),
                "item_id": int(test["item_id"].iloc[i]),
                "label": int(y_test[i]),
                "proba": round(float(proba[i]), 4),
                "tag": tag,
                "top_features": {
                    f: round(float(X_test[f].iloc[i]), 3)
                    for f in top_feats if f in X_test.columns
                },
            })

    # 群体对比（补充）：高意向正样本 vs 低意向负样本的 top 特征均值差异
    k = 200
    high = pos_idx[np.argsort(proba[pos_idx])[::-1][:min(k, len(pos_idx))]]
    low = neg_idx[np.argsort(proba[neg_idx])[:min(k, len(neg_idx))]]
    sample_diff = []
    for f in top_feats:
        if f not in X_test.columns:
            continue
        h = float(X_test[f].iloc[high].mean())
        l = float(X_test[f].iloc[low].mean())
        sample_diff.append({
            "feature": f, "desc": describe_feature(f),
            "high_mean": round(h, 3), "low_mean": round(l, 3),
            "diff": round(h - l, 3),
        })

    # 3) 特征字典
    dict_rows = []
    for rank, (f, score) in enumerate(imp.items(), start=1):
        dict_rows.append({
            "rank": rank, "feature": f, "type": feature_type(f),
            "importance": round(float(score), 4), "desc": describe_feature(f),
        })

    # 落盘 json
    out = {
        "mode": mode,
        "best_model": best,
        "importance": {f: round(float(s), 4) for f, s in imp.items()},
        "top20": [{"feature": f, "importance": round(float(s), 4)} for f, s in top.items()],
        "sample_interpretation": {
            "samples": sample_rows,
            "high_n": int(len(high)), "low_n": int(len(low)),
            "high_avg_proba": round(float(proba[high].mean()), 4),
            "low_avg_proba": round(float(proba[low].mean()), 4),
            "feature_diff": sample_diff,
        },
    }
    mu.write_json(out, os.path.join(METRICS_DIR, mode, "feature_importance.json"))

    # 落盘特征字典 markdown
    write_feature_dict_md(mode, best, dict_rows, imp)

    print(f"[importance] 完成 -> {os.path.join(METRICS_DIR, mode, 'feature_importance.json')}")
    return out


def write_feature_dict_md(mode, best, dict_rows, imp):
    os.makedirs(MODELING_REPORTS_DIR, exist_ok=True)
    path = os.path.join(MODELING_REPORTS_DIR, f"{mode}_特征字典.md")
    lines = [
        f"# 特征字典（{mode} 档，最优模型 {best}）",
        "",
        "每个特征含：计算逻辑、时间窗口、数据类型、重要性排序。",
        "重要性：LR 用 |回归系数|，GBDT/XGBoost 用 gain（分裂增益）。",
        "",
        "| 排名 | 特征 | 类型 | 重要性 | 计算逻辑 |",
        "|------|------|------|--------|----------|",
    ]
    for r in dict_rows:
        lines.append(
            f"| {r['rank']} | `{r['feature']}` | {r['type']} | {r['importance']} | {r['desc']} |")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print(f"[importance] 特征字典 -> {path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=MODES, default="dev")
    args = parser.parse_args()

    vm_path = os.path.join(MODEL_DIR, args.mode, "val_metrics.json")
    if not os.path.exists(vm_path):
        print(f"[importance] 未找到 {vm_path}，跳过（先跑 train.py）。")
        return
    run(args.mode)


if __name__ == "__main__":
    main()
