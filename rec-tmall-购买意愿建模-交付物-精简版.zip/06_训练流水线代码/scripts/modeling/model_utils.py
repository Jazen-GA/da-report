"""
建模共享框架（第二部分）
========================
主样本与购物车专项共用的「读样本 → 编码 → 训练 → 指标 → 重要性」通用函数：

  - load_*:            读 preprocessed 的 train/val/test → pandas DataFrame
  - target_encode_*:   fold 内 OOF 目标编码（train 用 fold 内统计，val/test 用全 train 统计，防泄露）
  - build_feature_matrix: 数值特征 + 目标编码类别 + 可选交叉特征 → 特征矩阵 + 列名
  - fit_model:         三模型训练（LR / LightGBM / XGBoost），树模型 val 早停
  - compute_metrics / compute_pr_curve: AUC / AP / 精确率 / 召回率 / F1 / PR 曲线
  - feature_importance: 三模型统一重要性输出

配置驱动：模型超参、类别列、交叉特征对全部来自 config.py，换数据只改 config 不改本文件。
"""
import os
import sys
import json
import time
import warnings
import numpy as np
import pandas as pd

# sklearn 1.6 + numpy 2.0 下 liblinear 预测阶段的已知数值溢出（extmath.safe_sparse_dot），
# 最终概率经 clip 后结果正确，抑制这三类数值 RuntimeWarning 避免污染日志。
warnings.filterwarnings("ignore", message=".*overflow encountered.*")
warnings.filterwarnings("ignore", message=".*invalid value encountered.*")
warnings.filterwarnings("ignore", message=".*divide by zero encountered.*")

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.modeling.config import *

from sklearn.model_selection import KFold
from sklearn.metrics import (
    roc_auc_score, average_precision_score, accuracy_score,
    precision_score, recall_score, f1_score, precision_recall_curve,
)


# ── 数据读取 ──

def load_split(mode, split):
    """读 preprocessed 的单个 split 为 pandas DataFrame（pyarrow 读 spark 落盘 parquet 目录）"""
    path = os.path.join(PREPROCESSED_DIR, mode, split)
    return pd.read_parquet(path)


def load_all(mode):
    """读 train/val/test 三份样本"""
    train = load_split(mode, "train")
    val = load_split(mode, "val")
    test = load_split(mode, "test")
    return train, val, test


def numeric_cols(df):
    """数值特征列 = 全部列 - 元数据 - 类别（类别列由 config.CAT_COLS 定义）"""
    return [c for c in df.columns if c not in META_COLS and c not in CAT_COLS]


# ── 目标编码（fold 内 OOF，防标签泄露）──

def _smoothed(stats, global_mean, smooth):
    """平滑后的类别 target mean：向全局均值收缩，类别样本越少收缩越强"""
    return (stats["count"] * stats["mean"] + smooth * global_mean) / (stats["count"] + smooth)


def target_encode_train(X_cat, y, folds=TARGET_ENCODING_FOLDS, smooth=TARGET_ENCODING_SMOOTH):
    """对 train 做 OOF 目标编码：每个 fold 的类别均值只用其余 fold 的样本计算。

    返回 DataFrame（index 对齐 X_cat，列同 CAT_COLS），未知/缺失类别 → 全局均值。
    """
    global_mean = float(y.mean())
    kf = KFold(n_splits=folds, shuffle=True, random_state=42)
    enc = pd.DataFrame(index=X_cat.index, columns=X_cat.columns, dtype=float)

    for col in X_cat.columns:
        col_enc = pd.Series(np.nan, index=X_cat.index, dtype=float)
        for tr_idx, va_idx in kf.split(X_cat):
            tr_col = X_cat[col].iloc[tr_idx]
            tr_y = y.iloc[tr_idx]
            stats = tr_y.groupby(tr_col, dropna=False).agg(["mean", "count"])
            smoothed = _smoothed(stats, global_mean, smooth)
            col_enc.iloc[va_idx] = X_cat[col].iloc[va_idx].map(smoothed).values
        enc[col] = col_enc.fillna(global_mean)
    return enc


def target_encode_apply(X_cat, train_X_cat, y, smooth=TARGET_ENCODING_SMOOTH):
    """用 train 的 (类别, label) 统计编码 val/test（不学习 val/test 任何标签信息）。

    train_X_cat / y 均为 train 侧数据：映射 = train 类别 → train label 平滑均值，
    再 map 到 X_cat（val/test 的类别列）。此前误用 y.groupby(X_cat[col])，
    等于拿 val 的类别列去切 train 的 label（index 错配），已修正。
    """
    global_mean = float(y.mean())
    enc = pd.DataFrame(index=X_cat.index, columns=X_cat.columns, dtype=float)
    for col in X_cat.columns:
        stats = y.groupby(train_X_cat[col], dropna=False).agg(["mean", "count"])
        smoothed = _smoothed(stats, global_mean, smooth)
        enc[col] = X_cat[col].map(smoothed).fillna(global_mean).values
    return enc


def target_encode_fit(X_cat, y, smooth=TARGET_ENCODING_SMOOTH):
    """返回 {col: Series(类别 -> 平滑均值)}，供推理侧封装，不再依赖重读 train（整改 #2）。"""
    global_mean = float(y.mean())
    maps = {}
    for col in X_cat.columns:
        stats = y.groupby(X_cat[col], dropna=False).agg(["mean", "count"])
        maps[col] = _smoothed(stats, global_mean, smooth)
    return maps


def target_encode_apply_map(X_cat, maps, global_mean):
    """用预计算的映射 maps（{col: Series(类别->均值)}）编码 X_cat，未知/缺失类别 -> global_mean。"""
    enc = pd.DataFrame(index=X_cat.index, columns=X_cat.columns, dtype=float)
    for col in X_cat.columns:
        enc[col] = X_cat[col].map(maps[col]).fillna(global_mean).values
    return enc


# ── 特征矩阵构建 ──

def build_feature_matrix(df, target_enc, cross_features=None):
    """数值特征 + 目标编码类别 + 可选交叉特征 → (X DataFrame, feature_names list)

    返回 DataFrame 保留列名，供树模型正确识别 feature names；交叉特征用两列乘积，
    引用列不存在时跳过并提示（换数据删列不崩）。
    """
    num = [c for c in df.columns if c not in META_COLS and c not in CAT_COLS]
    X = df[num].astype(float).copy()
    names = list(num)

    # 目标编码列（8 个类别 → 8 列数值）
    for c in CAT_COLS:
        if c in target_enc.columns:
            X[f"{c}_te"] = target_enc[c].astype(float).values
            names.append(f"{c}_te")

    # 交叉特征（LR 等线性模型捕捉交互）
    if cross_features:
        for a, b in cross_features:
            if a in X.columns and b in X.columns:
                nm = f"{a}__x__{b}"
                X[nm] = X[a] * X[b]
                names.append(nm)
            else:
                print(f"[model_utils] 跳过交叉特征 {a} x {b}（列不存在）")

    return X, names


# ── 模型训练 ──

def fit_model(model_name, X_train, y_train, X_val, y_val):
    """训练单个模型，返回 (model, val_pred_proba)。

    gbdt/xgb 用 val 集早停（config 里的 early_stopping_rounds 是训练参数，非构造参数）。
    xgb 的 scale_pos_weight 按 train 实际负:正比动态计算，不硬编码。
    """
    params = dict(MODEL_PARAMS[model_name])

    if model_name == "lr":
        from sklearn.linear_model import LogisticRegression
        # 轻量调优：在 config.LR_C_GRID 上搜 C，用 val AUC 选最优（统一调优策略）
        best_auc, best_m = -1.0, None
        for C in LR_C_GRID:
            p = {**params, "C": C}
            cand = LogisticRegression(**p)
            cand.fit(X_train, y_train)
            auc = roc_auc_score(y_val, cand.predict_proba(X_val)[:, 1])
            if auc > best_auc:
                best_auc, best_m = auc, cand
        m = best_m

    elif model_name == "gbdt":
        import lightgbm as lgb
        # 网格搜索：learning_rate × num_leaves，各组合 val 早停，按 val AUC 选最优（整改 #7）
        best_auc, best_m = -1.0, None
        for lr in GBDT_GRID["learning_rate"]:
            for nl in GBDT_GRID["num_leaves"]:
                p = {**params, "learning_rate": lr, "num_leaves": nl}
                esr = p.pop("early_stopping_rounds", 100)
                cand = lgb.LGBMClassifier(**p)
                cand.fit(X_train, y_train,
                         eval_set=[(X_val, y_val)], eval_metric="auc",
                         callbacks=[lgb.early_stopping(esr, verbose=False)])
                auc = roc_auc_score(y_val, cand.predict_proba(X_val)[:, 1])
                if auc > best_auc:
                    best_auc, best_m = auc, cand
        m = best_m

    elif model_name == "xgb":
        import xgboost as xgb
        # 网格搜索：learning_rate × max_depth；scale_pos_weight 按 train 负:正动态算（整改 #7）
        n_pos = int(y_train.sum())
        n_neg = len(y_train) - n_pos
        best_auc, best_m = -1.0, None
        for lr in XGB_GRID["learning_rate"]:
            for md in XGB_GRID["max_depth"]:
                p = {**params, "learning_rate": lr, "max_depth": md}
                if not p.get("scale_pos_weight"):
                    p["scale_pos_weight"] = n_neg / max(n_pos, 1)
                # XGBoost 2.x sklearn API：early_stopping_rounds 是构造参数（fit 不接受），留在 params 里
                cand = xgb.XGBClassifier(**p)
                cand.fit(X_train, y_train,
                         eval_set=[(X_val, y_val)], verbose=False)
                auc = roc_auc_score(y_val, cand.predict_proba(X_val)[:, 1])
                if auc > best_auc:
                    best_auc, best_m = auc, cand
        m = best_m

    else:
        raise ValueError(f"未知模型: {model_name}（可选 lr/gbdt/xgb）")

    val_prob = m.predict_proba(X_val)[:, 1]
    return m, val_prob


# ── 指标计算 ──

def compute_metrics(y_true, y_prob, threshold=0.5):
    """核心指标：AUC / AP（PR-AUC）/ 精确率 / 召回率 / F1 / 准确率"""
    auc = roc_auc_score(y_true, y_prob)
    ap = average_precision_score(y_true, y_prob)
    y_pred = (y_prob >= threshold).astype(int)
    return {
        "auc": round(float(auc), 4),
        "ap": round(float(ap), 4),
        "accuracy": round(float(accuracy_score(y_true, y_pred)), 4),
        "precision": round(float(precision_score(y_true, y_pred, zero_division=0)), 4),
        "recall": round(float(recall_score(y_true, y_pred, zero_division=0)), 4),
        "f1": round(float(f1_score(y_true, y_pred, zero_division=0)), 4),
    }


def compute_pr_curve(y_true, y_prob):
    """PR 曲线数据（供报告绘图）"""
    precision, recall, thresholds = precision_recall_curve(y_true, y_prob)
    return precision, recall, thresholds


# ── 特征重要性 ──

def feature_importance(model_name, model, feature_names):
    """三模型统一重要性：LR 用 |coef|，树模型用 gain/split 增益，输出 Series 降序"""
    if model_name == "lr":
        imp = np.abs(model.coef_[0])
    elif model_name == "gbdt":
        imp = model.booster_.feature_importance(importance_type="gain")
    elif model_name == "xgb":
        # feature_importances_ 已按训练列顺序对齐（DataFrame 训练时长度 == 特征数）
        imp = np.asarray(model.feature_importances_, dtype=float)
    else:
        raise ValueError(f"未知模型: {model_name}")

    s = pd.Series(imp, index=feature_names, name="importance")
    return s.sort_values(ascending=False)


# ── 模型持久化 ──

def save_model(model, path):
    import joblib
    os.makedirs(os.path.dirname(path), exist_ok=True)
    joblib.dump(model, path)


def load_model(path):
    import joblib
    return joblib.load(path)


def write_json(obj, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, default=str)
