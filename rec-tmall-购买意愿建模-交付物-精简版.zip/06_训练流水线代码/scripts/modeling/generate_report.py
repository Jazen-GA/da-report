"""
综合建模报告生成（第二部分交付物）
====================================
聚合主样本基线 + 购物车专项的全部产出，生成 HTML 报告：
  1. 主样本三模型对比（val/test 指标、训练/推理效率、可解释性）
  2. 核心指标 + PR 曲线（不平衡样本核心依据）
  3. 分维度泛化性（类目 / 用户活跃度 / 商品热度）
  4. 特征重要性 Top + 典型样本解释
  5. 购物车专项（三模型 + 业务价值测算 + 高意向清单）

图表用 matplotlib 生成 PNG 嵌入 HTML；中文用 macOS PingFang 字体。
输出: reports/modeling/{mode}_modeling_report.html + 图表
用法: python scripts/modeling/generate_report.py --mode debug|dev|full
"""
import os
import sys
import json
import argparse

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.modeling.config import *


plt.rcParams["font.sans-serif"] = ["PingFang SC", "Hiragino Sans GB", "Arial Unicode MS", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False


def _load(mode):
    def read_json(p):
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    vm = read_json(os.path.join(MODEL_DIR, mode, "val_metrics.json"))
    ev = read_json(os.path.join(METRICS_DIR, mode, "evaluation.json"))
    fi = read_json(os.path.join(METRICS_DIR, mode, "feature_importance.json"))
    cm = read_json(os.path.join(CART_DIR, mode, "cart_metrics.json"))
    ce = read_json(os.path.join(CART_DIR, mode, "cart_export.json"))
    return vm, ev, fi, cm, ce


def _fig_pr(ev, out):
    fig, ax = plt.subplots(figsize=(7, 5))
    for name, d in ev["pr_data"].items():
        ax.plot(d["recall"], d["precision"], label=f"{name} (AP={ev['test_metrics'][name]['ap']})")
    ax.set_xlabel("召回率 Recall")
    ax.set_ylabel("精确率 Precision")
    ax.set_title("三模型 PR 曲线（test 集）")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out, dpi=120)
    plt.close(fig)


def _fig_importance(fi, out):
    top = fi["top20"][::-1]  # 反转让最重要在上
    names = [t["feature"] for t in top]
    vals = [t["importance"] for t in top]
    fig, ax = plt.subplots(figsize=(7, 8))
    ax.barh(names, vals, color="#2c7fb8")
    ax.set_xlabel("重要性（gain / |coef|）")
    ax.set_title(f"特征重要性 Top 20（最优模型 {fi['best_model']}）")
    fig.tight_layout()
    fig.savefig(out, dpi=120)
    plt.close(fig)


def _fig_dim(ev, out):
    dims = [k for k, v in ev["dim_auc"].items() if v]
    if not dims:
        return
    fig, axes = plt.subplots(1, len(dims), figsize=(5 * len(dims), 4))
    if len(dims) == 1:
        axes = [axes]
    for ax, dim in zip(axes, dims):
        # dim_auc[dim] 结构为 {model: {group: auc}}；取第一个模型的 group 名作 x 轴（各模型 group 一致）
        first_model = next(iter(ev["dim_auc"][dim]))
        groups = list(ev["dim_auc"][dim][first_model].keys())
        for name in ev["dim_auc"][dim]:
            aucs = [ev["dim_auc"][dim][name].get(g) for g in groups]
            ax.plot(groups, aucs, marker="o", label=name)
        ax.set_title(dim)
        ax.set_ylabel("AUC")
        ax.tick_params(axis="x", rotation=45)
        ax.legend()
        ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out, dpi=120)
    plt.close(fig)


def _fig_cart_value(ce, out):
    rows = ce["value_assessment"]
    thr = [r["threshold"] for r in rows]
    recall = [r["recall"] for r in rows]
    prec = [r["precision"] for r in rows]
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(thr, recall, marker="o", label="成交召回率")
    ax.plot(thr, prec, marker="s", label="精确率")
    ax.set_xlabel("概率阈值")
    ax.set_ylabel("比例")
    ax.set_title("购物车专项业务价值测算")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out, dpi=120)
    plt.close(fig)


def _metric_table(metrics):
    """把 {name: {auc, ap, ...}} 渲染成 HTML 表"""
    keys = ["auc", "ap", "accuracy", "precision", "recall", "f1"]
    zh = {"auc": "AUC", "ap": "AP(PR-AUC)", "accuracy": "准确率", "precision": "精确率",
          "recall": "召回率", "f1": "F1"}
    header = "".join(f"<th>{zh[k]}</th>" for k in keys)
    rows = ""
    for name, m in metrics.items():
        cells = "".join(f"<td>{m[k]}</td>" for k in keys)
        rows += f"<tr><td><b>{name}</b></td>{cells}</tr>"
    return (f'<table><thead><tr><th>模型</th>{header}</tr></thead>'
            f'<tbody>{rows}</tbody></table>')


def _comparison_table(comp):
    names = list(comp["predictive_accuracy"].keys())
    dims = [("predictive_accuracy", "预测精度(AUC)"), ("train_efficiency", "训练耗时(s)"),
            ("inference_efficiency", "推理耗时(ms/样本)"), ("interpretability", "可解释性")]
    header = "".join(f"<th>{zh}</th>" for _, zh in dims)
    rows = ""
    for n in names:
        cells = ""
        for k, _ in dims:
            v = comp[k].get(n, "")
            if k == "inference_efficiency":
                v = f"{v * 1000:.3f}"
            cells += f"<td>{v}</td>"
        rows += f"<tr><td><b>{n}</b></td>{cells}</tr>"
    return (f'<table><thead><tr><th>模型</th>{header}</tr></thead>'
            f'<tbody>{rows}</tbody></table>')


def _sample_table(fi):
    rows = fi["sample_interpretation"]["feature_diff"]
    tr = ""
    for r in rows[:15]:
        tr += (f"<tr><td><code>{r['feature']}</code></td><td>{r['desc']}</td>"
               f"<td>{r['high_mean']}</td><td>{r['low_mean']}</td>"
               f"<td>{r['diff']}</td></tr>")
    return (f'<table><thead><tr><th>特征</th><th>含义</th><th>高意愿均值</th>'
            f'<th>低意愿均值</th><th>差异</th></tr></thead><tbody>{tr}</tbody></table>')


def build_report(mode):
    vm, ev, fi, cm, ce = _load(mode)
    chart_dir = os.path.join(MODELING_REPORTS_DIR, "charts")
    os.makedirs(chart_dir, exist_ok=True)

    _fig_pr(ev, os.path.join(chart_dir, f"{mode}_pr.png"))
    _fig_importance(fi, os.path.join(chart_dir, f"{mode}_importance.png"))
    _fig_dim(ev, os.path.join(chart_dir, f"{mode}_dim_auc.png"))
    _fig_cart_value(ce, os.path.join(chart_dir, f"{mode}_cart_value.png"))

    si = fi["sample_interpretation"]
    best = vm["best_model"]

    html = f"""<!DOCTYPE html>
<html lang="zh"><head><meta charset="utf-8">
<title>购买意愿与转化预测建模报告（{mode}）</title>
<style>
body{{font-family:-apple-system,"PingFang SC","Hiragino Sans GB",sans-serif;max-width:960px;margin:24px auto;padding:0 20px;color:#222;line-height:1.6}}
h1{{border-bottom:3px solid #2c7fb8;padding-bottom:8px}}h2{{color:#2c7fb8;margin-top:36px}}
table{{border-collapse:collapse;width:100%;margin:12px 0;font-size:14px}}
th,td{{border:1px solid #ddd;padding:6px 10px;text-align:center}}
th{{background:#f0f5fa}}img{{max-width:100%;border:1px solid #eee;margin:8px 0}}
.note{{background:#fff8e1;border-left:4px solid #f0ad4e;padding:8px 12px;font-size:13px;color:#7a5c00}}
</style></head><body>
<h1>购买意愿与转化预测建模报告（{mode} 档）</h1>
<p>建模粒度 user-item，预测用户在预测窗口（7 天）内是否购买（alipay）。观察窗口 30 天，6 个时间断面时序切分 train/val/test。</p>

<h2>1. 主样本基线模型对比</h2>
<p>最优模型（按 val AUC）：<b>{best}</b>（val AUC={vm['best_val_auc']}）</p>
{_comparison_table(ev['comparison'])}

<h2>2. 核心指标（test 集）</h2>
{_metric_table(ev['test_metrics'])}
<img src="charts/{mode}_pr.png" alt="PR曲线">
<div class="note">样本负:正 ≈ 5:1，不平衡下 AUC/AP 为核心依据；精确率/召回率/F1 以 0.5 阈值计算。口碑特征（i_review_cnt/i_pos_rate/i_avg_sentiment）含未来信息，会高估绝对性能，见 README 约束。</div>

<h2>3. 分维度泛化性</h2>
<p>分一级类目 / 用户活跃度层级 / 商品热度层级评估 AUC，识别薄弱场景。</p>
<img src="charts/{mode}_dim_auc.png" alt="分维度AUC">

<h2>4. 特征重要性（最优模型 {fi['best_model']}）</h2>
<img src="charts/{mode}_importance.png" alt="特征重要性">
<h3>典型样本解释</h3>
<p>高购买意愿（真实成交且概率最高）vs 低购买意愿（真实未购且概率最低）各 {si['high_n']} / {si['low_n']} 条样本的核心特征差异：</p>
{_sample_table(fi)}

<h2>5. 购物车成交预测专项</h2>
<p>样本 = 观察窗口内加购且未立即支付（观察窗口内未购买）的 user-item 对；标签 = 预测窗口 7 天内是否购买。最优模型：<b>{cm['best_model']}</b>（val AUC={cm['best_val_auc']}）。</p>
{_metric_table({n: cm['models'][n]['test_metrics'] for n in cm['models']})}
<img src="charts/{mode}_cart_value.png" alt="业务价值测算">
<p>高意向未成交清单共 <b>{ce['high_intent_total']:,}</b> 条（已落盘 high_intent_list.csv）。阈值 0.5 时精确率约 {ce['value_assessment'][2]['precision']}，可召回 {ce['value_assessment'][2]['recall']*100:.1f}% 的实际成交。</p>

<h2>6. 交付物清单</h2>
<ul>
<li>模型文件：data/modeling/model/{mode}/*.joblib（LR/GBDT/XGBoost）+ cart_model.joblib</li>
<li>评估指标：data/modeling/metrics/{mode}/evaluation.json、feature_importance.json</li>
<li>特征字典：reports/modeling/{mode}_特征字典.md</li>
<li>购物车专项：data/modeling/cart/{mode}/（样本 + 高意向清单 + 价值测算）</li>
<li>标准化样本集：data/modeling/dataset/{mode}/（train/val/test）</li>
</ul>
</body></html>"""

    out_path = os.path.join(MODELING_REPORTS_DIR, f"{mode}_modeling_report.html")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"[report] 完成 -> {out_path}")
    return out_path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=MODES, default="dev")
    args = parser.parse_args()

    need = [os.path.join(MODEL_DIR, args.mode, "val_metrics.json"),
            os.path.join(CART_DIR, args.mode, "cart_metrics.json")]
    if not all(os.path.exists(p) for p in need):
        print("[report] 缺少前置产出（val_metrics.json / cart_metrics.json），跳过。请先跑 train + cart_model。")
        return
    build_report(args.mode)


if __name__ == "__main__":
    main()
