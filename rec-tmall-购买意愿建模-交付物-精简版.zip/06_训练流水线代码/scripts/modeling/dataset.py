"""
数据集组装 + 时序切分
======================
按断面循环：特征（features.py）join 标签（labels.py）→ 合并所有断面 →
按 split 归属切 train/val/test 并落盘 Parquet。

每个样本保留元数据列：slice_id / split / pred_start / obs_end，
供泄露校验与后续分析使用（pred_start 为标签窗口起点，obs_end 为观察窗口终点）。

输出: data/modeling/dataset/{mode}/{train|val|test}
用法: python scripts/modeling/dataset.py --mode debug|dev|full
"""
import os
import sys
import time
import argparse
from pyspark.sql import functions as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.modeling.config import *
from scripts.modeling.features import build_slice_features
from scripts.modeling.labels import build_labels


def load_shared(spark):
    """加载断面无关的共享输入（product 解析 / 口碑），原始 schema 映射全部来自 config.COL。

    这里把「原始表」适配成「内部规范视图」（item_id/parent_cat/leaf_cat/brand_id/seller_id 等），
    下游 features.py 只认规范视图的固定列名，换数据只改 config，不再动解析逻辑。
    """
    cat_col = F.col(COL["product_category"])
    product = spark.read.parquet(PRODUCT_PATH) \
        .withColumn("parent_cat", F.split(cat_col, CATEGORY_SPLIT).getItem(CATEGORY_PARENT_IDX).cast("int")) \
        .withColumn("leaf_cat", F.split(cat_col, CATEGORY_SPLIT).getItem(CATEGORY_LEAF_IDX).cast("int")) \
        .select(
            F.col(COL["item_id"]).alias("item_id"),
            "parent_cat", "leaf_cat",
            F.col(COL["product_brand"]).alias("brand_id"),
            F.col(COL["product_seller"]).alias("seller_id"),
        )

    item_rep = spark.read.option("header", True).option("inferSchema", True) \
        .csv(ITEM_REPUTATION_CSV) \
        .select(
            F.col(COL["item_id"]).alias("item_id"),
            F.col(COL["review_cnt"]).alias("review_cnt"),
            F.col(COL["review_pos_rate"]).alias("pos_rate"),
            F.col(COL["review_avg_sentiment"]).alias("avg_sentiment"),
        )

    return product, item_rep


def assemble_slice(sample, feats, w):
    """把一个断面的样本 join 上各组特征，并补 pred_start/obs_end 元数据"""
    df = sample
    if "user" in feats:
        df = df.join(feats["user"].drop("slice_id"), "user_id", "left")
    if "item" in feats:
        df = df.join(feats["item"].drop("slice_id"), "item_id", "left")
    if "cross" in feats:
        df = df.join(feats["cross"].drop("slice_id"), ["user_id", "item_id"], "left")
    if "sequence" in feats:
        df = df.join(feats["sequence"].drop("slice_id"), "user_id", "left")

    return df.withColumn("pred_start", F.lit(w["pred_start"])) \
             .withColumn("obs_end", F.lit(w["obs_end"]))


def build_dataset(spark, mode):
    daily_path = os.path.join(DAILY_DIR, mode)
    out_root = os.path.join(DATASET_DIR, mode)

    print(f"[dataset] 读取每日中间表: {daily_path}")
    # 不 persist daily：full 档 10 亿行中间表常驻内存会打满堆（OOM）。
    # 直接读 parquet 走谓词下推，各断面按窗口过滤只加载需要的行。
    daily = spark.read.parquet(daily_path)
    product, item_rep = load_shared(spark)
    # item 首现日期（813 万 item，很小）：6 断面复用，persist 避免每断面重扫全量 daily
    item_first_date = daily.groupBy("item_id").agg(F.min("action_date").alias("first_date")).persist()

    windows = slice_windows()
    all_samples = None
    for w in windows:
        sample, cand = build_labels(spark, daily, w)
        if sample is None:
            continue
        # 采样结果被特征过滤 + 组装多次复用，materialize 避免重复计算（默认 MEMORY_AND_DISK）
        sample = sample.persist()
        # 提取样本涉及的三个维度集合（去重 + 缓存），供特征最上游 left semi 过滤
        sample_users = sample.select("user_id").distinct().persist()
        sample_items = sample.select("item_id").distinct().persist()
        sample_pairs = sample.select("user_id", "item_id").distinct().persist()
        feats = build_slice_features(spark, daily, w, product, item_rep, item_first_date,
                                     sample_users, sample_items, sample_pairs)
        assembled = assemble_slice(sample, feats, w)
        n = assembled.count()
        cand.unpersist()  # sample 已 materialize，候选对缓存可释放
        print(f"[dataset] slice_id={w['slice_id']} 组装完成: {n:,} 样本")
        all_samples = assembled if all_samples is None else all_samples.unionByName(assembled)

    if all_samples is None:
        print("[dataset] 所有断面均无正样本，无法构建数据集（样本太小）。请用更大档位（dev/full）。")
        return None

    # 按 split 落盘
    for split in ["train", "val", "test"]:
        part = all_samples.filter(F.col("split") == split)
        part.write.mode("overwrite").option("compression", "snappy") \
            .parquet(os.path.join(out_root, split))
        print(f"[dataset] {split}: {part.count():,} 样本 -> {os.path.join(out_root, split)}")

    return all_samples


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=MODES, default="debug")
    args = parser.parse_args()

    spark = create_spark(f"Modeling-Dataset-{args.mode}")
    t0 = time.time()
    build_dataset(spark, args.mode)
    print(f"[dataset] 全部完成, 耗时 {(time.time() - t0) / 60:.1f} 分钟")
    spark.stop()


if __name__ == "__main__":
    main()
