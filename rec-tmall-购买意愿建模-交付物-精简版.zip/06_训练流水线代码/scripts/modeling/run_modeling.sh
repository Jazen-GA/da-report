#!/bin/bash
# 购买意愿与转化预测建模：第二部分一键入口
#   主样本训练 → 多维度评估 → 特征重要性 → 购物车专项 → 综合报告
# 用法: bash scripts/modeling/run_modeling.sh [debug|dev|full] [--all]
#   --all: 先跑第一部分（run_features.sh 特征工程 + 样本构建）
set -e

MODE="${1:-dev}"
RUN_FEATURES=0
for a in "$@"; do
  [ "$a" = "--all" ] && RUN_FEATURES=1
done

PROJECT_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$PROJECT_ROOT"

PY="python"
[ -f venv/bin/python ] && PY="venv/bin/python"

echo "=========================================================="
echo "建模 pipeline: 训练 + 评估 + 购物车专项  (mode=$MODE)"
echo "=========================================================="

if [ "$RUN_FEATURES" = "1" ]; then
  echo "[0/7] 第一部分：特征工程 + 样本构建"
  bash scripts/modeling/run_features.sh "$MODE"
fi

echo "[1/7] 主样本三模型训练（LR/GBDT/XGBoost）"
"$PY" scripts/modeling/train.py --mode "$MODE"

echo "[2/7] 多维度评估（核心指标/PR/分维度泛化/横向对比）"
"$PY" scripts/modeling/evaluate.py --mode "$MODE"

echo "[3/7] 特征重要性 + 典型样本解释 + 特征字典"
"$PY" scripts/modeling/feature_importance.py --mode "$MODE"

echo "[4/7] 最优模型推理（演示生产推理入口）"
"$PY" scripts/modeling/infer.py --mode "$MODE"

echo "[5/7] 购物车专项样本 + 专属特征"
"$PY" scripts/modeling/cart_dataset.py --mode "$MODE"

echo "[6/7] 购物车专项训练 + 推理 + 高意向清单 + 业务价值"
"$PY" scripts/modeling/cart_model.py --mode "$MODE"

echo "[7/7] 综合 HTML 报告"
"$PY" scripts/modeling/generate_report.py --mode "$MODE"

echo "=========================================================="
echo "完成。产物: data/modeling/{model,cart,metrics}, reports/modeling/"
echo "=========================================================="
