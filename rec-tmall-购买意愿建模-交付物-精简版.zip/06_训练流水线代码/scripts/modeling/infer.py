"""
购买意愿推理脚本（第二部分交付物）
====================================
加载最优基线模型，对样本集推理购买概率。可作为生产推理入口的范式：
  - 读最优模型（val_metrics.json 指定的 best_model）
  - 目标编码用 train 统计 apply（与训练侧一致，防泄露）
  - 构建特征矩阵 → predict_proba → 输出购买概率

输出: data/modeling/model/{mode}/inference_result.csv
      （user_id / item_id / label / purchase_prob，按概率降序）
用法: python scripts/modeling/infer.py --mode debug|dev|full [--split test|val|train]
"""
import os
import sys
import json
import argparse

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.modeling.config import *
from scripts.modeling import model_utils as mu


def infer(mode, split="test"):
    # 加载推理包（整改 #2）：目标编码映射 + 特征名 + 交叉特征，不再重读 train 重算目标编码
    import joblib
    bundle = joblib.load(os.path.join(MODEL_DIR, mode, "inference_bundle.joblib"))
    best = bundle["best_model"]
    cross = bundle.get("cross_features")

    target = mu.load_split(mode, split)
    te_target = mu.target_encode_apply_map(
        target[bundle["cat_cols"]], bundle["target_encoding_map"], bundle["global_mean"])
    X, _ = mu.build_feature_matrix(target, te_target, cross)

    model = mu.load_model(os.path.join(MODEL_DIR, mode, f"{best}.joblib"))
    proba = model.predict_proba(X)[:, 1]

    out = target[["user_id", "item_id", "label"]].copy()
    out["purchase_prob"] = proba
    out = out.sort_values("purchase_prob", ascending=False).reset_index(drop=True)

    out_path = os.path.join(MODEL_DIR, mode, f"inference_{split}.csv")
    out.to_csv(out_path, index=False, encoding="utf-8-sig")
    print(f"[infer] 最优模型={best}, {split} 集 {len(out):,} 条推理完成")
    print(f"  top5 概率: {[round(p, 4) for p in out['purchase_prob'].head(5).tolist()]}")
    print(f"  -> {out_path}")
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=MODES, default="dev")
    parser.add_argument("--split", choices=["train", "val", "test"], default="test")
    args = parser.parse_args()

    vm_path = os.path.join(MODEL_DIR, args.mode, "val_metrics.json")
    if not os.path.exists(vm_path):
        print(f"[infer] 未找到 {vm_path}，跳过（先跑 train.py）。")
        return
    infer(args.mode, args.split)


if __name__ == "__main__":
    main()
