# Rec-Tmall 购买意愿与转化预测建模 — 第一部分（特征工程 + 样本构建）

数据源：天猫推荐数据集（https://tianchi.aliyun.com/dataset/140281），日志 12.6 亿行，时间跨度 2013-04-01 ~ 2013-10-01。

## 任务

以 `user-item` 为建模粒度，预测用户在预测窗口内是否购买（`alipay`）。本模块为**第一部分 a+b**：多维度特征工程 + 样本构建 + 特征预处理。模型训练评估为第二部分。

## 设计（配置驱动，可复用）

核心原则：**换一个结构相似的数据集，只改 `config.py`，不改任何脚本。**

- 日志先聚合成 `(user_id, item_id, action_date)` 每日行为中间表，全量只扫一次
- 四维特征（user / item / cross / sequence）均从中间表按断面观察窗口切片累加
- 时间断面（滑动窗口）：`30 天观察 + 7 天预测`，6 个断面按时间切 train/val/test
- 时间合规硬保证：特征只用 `< pred_start`，标签只用 `[pred_start, pred_start+7)`，独立泄露校验脚本兜底
- 原始 schema 映射（日志 / product / 口碑列名、类目解析规则）全部集中在 `config.COL` 与 `CATEGORY_*`，脚本内只认规范视图
- 行为取值与语义位置集中在 `ACTION_VALUES` / `LABEL_ACTION` / `ACTION_CLICK`/`COLLECT`/`CART`/`BUY`，派生特征（转化率/决策阶段/动销率）不再硬编码具体行为名，换数据按「点击→收藏→加购→购买」语义顺序填 `ACTION_VALUES` 即可

## 结构

```
scripts/modeling/
  config.py            # 全部参数（字段/行为/窗口/断面/采样/预处理/类别权重开关）
  aggregate.py         # 日志 → 每日行为中间表
  features.py          # 四维特征（user/item/cross/sequence）
  labels.py            # 标签 + 分层负采样
  dataset.py           # 组装 + 时序切分
  preprocess.py        # 缺失填充/异常值截断/标准化/相关性筛选（train 拟合，防泄露）
  leakage_check.py     # 泄露校验 + 分布一致性
  run_features.sh      # 一键入口
data/modeling/
  daily/{mode}/            # 每日行为中间表
  dataset/{mode}/          # train/val/test 样本（99 特征 + label + 元数据）
  preprocessed/{mode}/     # 预处理后特征（84 列）
  reports/                 # 泄露校验 / 预处理参数清单 json
```

## 重跑

```bash
cd rec-tmall
source venv/bin/activate
bash scripts/modeling/run_features.sh dev      # 或 full
```

三档：
- `debug`：万级日志，**仅验证 aggregate 跑通**。样本过小（摊到 6 个月），观察窗口内无购买，无正样本，dataset/preprocess/leakage_check 会自动跳过并提示。
- `dev`：1% 用户，可完整验证正负样本、泄露、预处理全链路。
- `full`：全量。

## 特征概览（dataset 输出 99 列）

| 组 | 列前缀 | 说明 |
|----|--------|------|
| 用户 | `u_*` | 频次 / 结构占比与转化率 / 活跃属性 / 偏好（Top3 品类、HHI、Top 品牌） |
| 商品 | `i_*` | 静态属性 + 上架时长 / 热度与环比 / 转化绩效 + 动销率 / 口碑 |
| 交叉 | `x_*` | 四类交互次数 / 交互深度 / 完整意向路径 / 决策阶段（x_stage） |
| 序列 | `s_*` | 每日行为量均值·方差·增长率 / 行为间隔中位数 / 连续无购买天数 |

预处理后：缺失填充、异常值截断、标准化（train 拟合），相关性阈值剔除冗余列，低基数类别独热（本数据集无此类列，空转）。**目标编码放第二部分训练侧**（fold 内算，避免标签泄露）。

## 已知约束

1. **商品口碑特征含未来信息（无法修复）**：`i_review_cnt / i_pos_rate / i_avg_sentiment` 复用第 5 周情感分析的全量评论聚合。评论是购买后的行为，且 `cleaned/review` 表**无时间戳**（原始数据本身无评论时间），无法按观察窗口切滚动快照。该泄露对 train/val/test 均匀作用，不破坏时序切分的一致性，但会高估绝对性能；真实部署只能拿到「截至当前」的口碑，表现会下降。
2. **目标编码/类别权重留第二部分**：`config.USE_CLASS_WEIGHT` 已预留开关，训练时启用 `class_weight`；目标编码需 fold 内计算，不能在全量落盘阶段做。
3. **动销率定义**：`i_sell_rate = 观察窗口内动销天数 / 30`；`i_listing_days` 用商品在日志中的最早出现日期近似上架时长。

## dev 档验证结果

| 校验项 | 结果 |
|--------|------|
| 特征列数 | 99（预处理后 84） |
| 样本量 | train 12,108 / val 3,845 / test 10,971 |
| 负:正比 | 5.03 / 5.03 / 5.02 |
| 时间隔离（obs_end < pred_start） | PASS |
| 时序切分（train < val < test） | PASS |
| 标签重验（抽样 283 条） | 0 不一致 |
| 相关性筛选 | 剔除 15 列冗余 |

---

# 第二部分：模型训练 + 评估 + 购物车专项

## 任务

- **a. 基线预测模型训练与效果评估**：LR / GBDT(LightGBM) / XGBoost 三模型 + 多维评估 + 特征重要性
- **b. 购物车成交预测专项**：加购未成交召回 + 高意向清单 + 业务价值测算

## 新增脚本

```
scripts/modeling/
  model_utils.py            # 共享框架：读样本 → fold 内目标编码 → 三模型 → 指标 → 重要性
  train.py                  # a.1 主样本三模型训练+调优（树模型 val 早停）
  evaluate.py               # a.2 核心指标 + PR/AP + 分维度泛化 + 四维横向对比
  feature_importance.py     # a.3 特征重要性 + 典型样本解释 + 特征字典 md
  infer.py                  # 推理脚本（加载最优模型 → 输出购买概率）
  cart_dataset.py           # b.1 cart 样本 + 5 专属特征（PySpark，复用 features.py）
  cart_model.py             # b.2/b.3 专项训练 + 推理 + 高意向清单 + 价值测算
  generate_report.py        # 综合 HTML 报告
  run_modeling.sh           # 一键入口
```

关键设计：三模型统一用「数值特征 + fold 内目标编码类别 + （LR）交叉特征」矩阵，公平对比；
目标编码 train 用 OOF、val/test 用全 train 统计，防泄露；GBDT=LightGBM，XGB 的 scale_pos_weight 按负:正比动态算。

## 重跑

```bash
bash scripts/modeling/run_modeling.sh dev           # 仅第二部分（需先跑 run_features.sh）
bash scripts/modeling/run_modeling.sh dev --all     # 含第一部分
```

## 标准化样本集说明

- 路径：`data/modeling/dataset/{mode}/{train|val|test}`（99 特征）与 `preprocessed/{mode}`（84 列标准化后）
- 字段：7 元数据（user_id/item_id/label/slice_id/split/pred_start/obs_end）+ 8 高基数类别 + 69 数值
- 时间切分：6 断面，slice 1–3 train（5/6/7 月）、slice 4 val（8 月）、slice 5–6 test（9 月）
- 观察窗口 30 天 / 预测窗口 7 天；负:正 ≈ 5:1（分层负采样）

## dev 档结果

- 主样本 test AUC：LR 0.9296 / GBDT 0.9251 / XGB 0.925（val 最优 xgb 0.92）
- 特征重要性 Top：x_depth（交互深度）、x_stage（决策阶段）、x_recency_days（近因）、x_cart_cnt（加购次数）
- 购物车专项：最优 LR，val AUC 0.8255；阈值 0.5 时召回 71.3% 成交、精确率 51.8%

## 已知约束（补充）

- 口碑特征（i_review_cnt/i_pos_rate/i_avg_sentiment）含未来信息，高估绝对性能（同第一部分）。
- cart 专项自然转化率约 0.86%（加购后滞留 30 天未买的，未来 7 天成交本就稀疏），采样到 3:1 提升高意向召回。
