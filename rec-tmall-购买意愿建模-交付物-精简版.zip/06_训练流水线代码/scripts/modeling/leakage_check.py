"""
泄露校验 + 分布一致性校验（独立可跑）
======================================
对已落盘的 dataset 做四类校验：
  1. 时间隔离：每个样本 obs_end 严格早于 pred_start（特征时间 < 标签时间）
  2. 时序切分：train 的 pred_start 整体早于 val 早于 test，无重叠
  3. 标签重验：抽样样本从每日中间表独立重算 label，与 dataset 对比（抓构建逻辑 bug）
  4. 分布一致性：正负比 / 用户活跃度 / 类目分布 在 train/val/test 间无显著偏移

输出: data/modeling/reports/{mode}_leakage_report.json
用法: python scripts/modeling/leakage_check.py --mode debug|dev|full
"""
import os
import sys
import time
import json
import argparse
from pyspark.sql import functions as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.modeling.config import *


def _read_split(spark, mode, split):
    return spark.read.parquet(os.path.join(DATASET_DIR, mode, split))


def check_temporal_isolation(all_df):
    """校验 1：每个样本 obs_end < pred_start"""
    bad = all_df.filter(F.col("obs_end") >= F.col("pred_start")).count()
    return {"ok": bad == 0, "violations": int(bad)}


def check_temporal_split(spark, mode):
    """校验 2：train < val < test 的 pred_start 严格递增无重叠"""
    order = []
    for split in ["train", "val", "test"]:
        df = _read_split(spark, mode, split)
        r = df.agg(F.min("pred_start").alias("mn"), F.max("pred_start").alias("mx")).collect()[0]
        order.append({"split": split, "min_pred_start": r["mn"], "max_pred_start": r["mx"]})

    ok = order[0]["max_pred_start"] < order[1]["min_pred_start"] and \
         order[1]["max_pred_start"] < order[2]["min_pred_start"]
    return {"ok": ok, "splits": order}


def check_label_verify(spark, daily, all_df):
    """校验 3：抽样样本从 daily 独立重算 label，对比 dataset"""
    label_col = f"{LABEL_ACTION}_cnt"
    sampled = all_df.sample(0.01, seed=123).limit(5000) \
                    .select("user_id", "item_id", "slice_id", "pred_start", "label")

    pred_buy = sampled.join(daily, ["user_id", "item_id"], "inner") \
        .filter(
            (F.col("action_date") >= F.to_date(F.col("pred_start"))) &
            (F.col("action_date") <= F.date_add(F.to_date(F.col("pred_start")), PRED_WINDOW_DAYS - 1)) &
            (F.col(label_col) > 0)
        ).select("user_id", "item_id", "slice_id").distinct() \
        .withColumn("_recomputed", F.lit(1))

    verified = sampled.join(pred_buy, ["user_id", "item_id", "slice_id"], "left") \
                      .withColumn("_recomputed", F.coalesce(F.col("_recomputed"), F.lit(0)))
    mismatch = verified.filter(F.col("label") != F.col("_recomputed")).count()
    n = verified.count()
    return {"ok": mismatch == 0, "sampled": int(n), "mismatch": int(mismatch)}


def check_distribution(spark, mode):
    """校验 4：正负比 / 用户活跃度 / 类目分布一致性"""
    dist = {}
    top_cats = None

    for split in ["train", "val", "test"]:
        df = _read_split(spark, mode, split)
        pos_rate = df.agg(F.avg("label")).collect()[0][0]
        avg_active = df.agg(F.avg("u_active_days")).collect()[0][0]
        n = df.count()
        dist[split] = {
            "n": int(n),
            "pos_rate": round(float(pos_rate), 4),
            "neg_pos_ratio": round((1 - pos_rate) / pos_rate, 2) if pos_rate > 0 else None,
            "avg_u_active_days": round(float(avg_active), 3),
        }

        # 类目分布（top 10 parent_cat 占比）
        cat = df.filter(F.col("parent_cat").isNotNull()) \
                .groupBy("parent_cat").count() \
                .orderBy(F.desc("count")).limit(10)
        total_cat = df.filter(F.col("parent_cat").isNotNull()).count()
        dist[split]["top10_cat_share"] = [
            {"cat": int(r["parent_cat"]), "share": round(r["count"] / total_cat, 4)}
            for r in cat.collect()
        ]

    return dist


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=MODES, default="debug")
    args = parser.parse_args()

    # 容错：debug 档日志过小、观察窗口内无购买时，dataset.py 不会产出任何样本。
    # 此时跳过校验并正常退出，避免下游误读残留/空目录而抛无意义异常。
    if not os.path.isdir(os.path.join(DATASET_DIR, args.mode, "train")):
        print(f"[leakage_check] 未找到 dataset/{args.mode}/train，跳过校验。")
        print("  原因：样本过小（debug 档常见——观察窗口内无购买，dataset 无正样本未产出）。")
        print("  请用更大档位（dev/full）验证，或检查 dataset.py 日志。")
        return

    spark = create_spark(f"Modeling-LeakageCheck-{args.mode}")
    t0 = time.time()

    train = _read_split(spark, args.mode, "train")
    # 目录可能存在但残留 0 行空 parquet（历史无正样本运行），行数为 0 同样跳过
    if train.count() == 0:
        print(f"[leakage_check] dataset/{args.mode}/train 为空（0 行），跳过校验。")
        print("  原因：样本过小（debug 档常见——观察窗口内无购买，无正样本）。请用更大档位（dev/full）。")
        spark.stop()
        return
    val = _read_split(spark, args.mode, "val")
    test = _read_split(spark, args.mode, "test")
    all_df = train.unionByName(val).unionByName(test)
    daily = spark.read.parquet(os.path.join(DAILY_DIR, args.mode))

    report = {
        "mode": args.mode,
        "temporal_isolation": check_temporal_isolation(all_df),
        "temporal_split": check_temporal_split(spark, args.mode),
        "label_verify": check_label_verify(spark, daily, all_df),
        "distribution": check_distribution(spark, args.mode),
    }

    os.makedirs(REPORTS_DIR, exist_ok=True)
    out_path = os.path.join(REPORTS_DIR, f"{args.mode}_leakage_report.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    # 打印摘要
    print("=" * 60)
    print("泄露校验结果")
    print("=" * 60)
    print(f"  1. 时间隔离 (obs_end < pred_start): {'PASS' if report['temporal_isolation']['ok'] else 'FAIL'}")
    print(f"  2. 时序切分 (train < val < test):   {'PASS' if report['temporal_split']['ok'] else 'FAIL'}")
    print(f"  3. 标签重验 (抽样 {report['label_verify']['sampled']} 条, 不一致 {report['label_verify']['mismatch']}): "
          f"{'PASS' if report['label_verify']['ok'] else 'FAIL'}")
    for split, d in report["distribution"].items():
        print(f"  4. {split}: n={d['n']:,} 正样本率={d['pos_rate']:.4f} 负正比={d['neg_pos_ratio']}")
    print(f"报告 -> {out_path}")

    spark.stop()
    print(f"耗时 {time.time() - t0:.1f}s")


if __name__ == "__main__":
    main()
