"""
购物车成交预测专项：样本 + 标签 + 专属特征（第二部分 b.1）
============================================================
样本范围：观察窗口内产生加购（cart）、且加购当日未立即支付的 user-item 对，
贴合「购物车未成交召回」业务场景。

标签定义：最近一次加购后 7 天内是否购买（加购快照 + 7 天滚动窗口，整改 #8/#9）。
专属特征（5 个，从每日中间表算）：
  - cart_cnt          观察窗口内该 user-item 的加购次数
  - cart_days_since   最近一次加购距观察窗口结束的天数（加购越久未成交越难召回）
  - cart_item_total   观察窗口内用户加购过的不同商品总数（购物车商品总数）
  - cart_pre_path     加购前是否有点击/收藏（加购前行为路径）
  - cart_same_cat     是否同时加购同类商品（同 parent_cat 的不同商品 > 1）

四维特征复用 features.build_slice_features；购物车标签保留自然分布、不采样（整改 #6）。
输出: data/modeling/cart/{mode}/{train|val|test}
用法: python scripts/modeling/cart_dataset.py --mode debug|dev|full
"""
import os
import sys
import time
import argparse
from pyspark.sql import functions as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.modeling.config import *
from scripts.modeling.features import build_slice_features, obs_window
from scripts.modeling.labels import stratified_neg_sample
from scripts.modeling.dataset import load_shared, assemble_slice


def build_cart_labels(spark, daily, w):
    """cart 样本（整改 #8/#9，方案 A：统一预测窗口，无泄漏）。

    样本范围：观察窗口内有加购、且「最近一次加购当日」未立即支付的 user-item 对。
    标签：预测窗口 [pred_start, pred_end]（= obs_end 后 7 天）内是否购买。
    无泄漏：特征用 obs 内数据，标签用 pred 窗口数据，二者时间无交集。
    不采样：保留自然分布（正样本率 ~23.6%，负:正 ~3.2:1）。

    samples: (user_id, item_id, label, slice_id, split)
    cand:    候选对（已 persist），供调用方在 samples 落盘后 unpersist。
    """
    slice_id = w["slice_id"]
    cart_col = f"{ACTION_CART}_cnt"
    buy_col = f"{ACTION_BUY}_cnt"

    obs = daily.filter(
        (F.col("action_date") >= w["obs_start"]) &
        (F.col("action_date") <= w["obs_end"])
    )

    # 1) 快照：观察窗口内最近一次加购日期（用于「未立即支付」判定）
    last_cart = obs.filter(F.col(cart_col) > 0) \
                   .groupBy("user_id", "item_id") \
                   .agg(F.max("action_date").alias("cart_date"))

    # 2) 未立即支付（整改 #9）：排除「最近加购当日即购买」的对（不是 obs 内从未购买）
    obs_buy = obs.filter(F.col(buy_col) > 0) \
                 .select("user_id", "item_id", "action_date").distinct()
    immediate = last_cart.alias("c").join(
        obs_buy.alias("b"),
        (F.col("c.user_id") == F.col("b.user_id")) &
        (F.col("c.item_id") == F.col("b.item_id")) &
        (F.col("c.cart_date") == F.col("b.action_date")),
        "inner"
    ).select("c.user_id", "c.item_id")
    cand = last_cart.join(immediate, ["user_id", "item_id"], "left_anti") \
                    .select("user_id", "item_id")
    cand = cand.persist()

    # 3) 标签（方案 A）：预测窗口内是否购买（统一窗口，特征/标签时间无交集）
    pred_buy = daily.filter(
        (F.col("action_date") >= w["pred_start"]) &
        (F.col("action_date") <= w["pred_end"]) &
        (F.col(buy_col) > 0)
    ).select("user_id", "item_id").distinct()

    pos = cand.join(pred_buy, ["user_id", "item_id"], "inner").withColumn("label", F.lit(1))
    neg = cand.join(pred_buy, ["user_id", "item_id"], "left_anti").withColumn("label", F.lit(0))

    n_pos = pos.count()
    n_neg = neg.count()
    total = n_pos + n_neg
    print(f"[cart] slice_id={slice_id}: 候选 {total:,} (正 {n_pos:,} / 负 {n_neg:,}, 正样本率 {n_pos/total:.1%})")
    if n_pos == 0:
        print(f"[cart] slice_id={slice_id}: 无正样本，跳过")
        cand.unpersist()
        return None, None

    # train/val 负采样到 CART_POS_NEG_RATIO，test 不采样（反映自然分布，随机抽上限防 OOM）
    if w["split"] == "test":
        if n_neg > TEST_NEG_MAX:
            neg = neg.sample(fraction=TEST_NEG_MAX / n_neg, seed=NEG_SAMPLE_SEED)
    else:
        neg = stratified_neg_sample(neg, obs, n_pos, ratio=CART_POS_NEG_RATIO)

    samples = pos.unionByName(neg) \
                 .withColumn("slice_id", F.lit(slice_id)) \
                 .withColumn("split", F.lit(w["split"]))
    return samples, cand


def build_cart_features(obs_user, obs_pair, product, w):
    """5 个 cart 专属特征：user 级用 obs_user，pair 级用 obs_pair（均已按样本过滤）。

    - pair 级（cart_cnt / cart_days_since / cart_pre_path）用 obs_pair
    - user 级（cart_item_total / cart_same_cat）用 obs_user
    """
    cart_col = f"{ACTION_CART}_cnt"
    click_col = f"{ACTION_CLICK}_cnt"
    collect_col = f"{ACTION_COLLECT}_cnt"

    # 1) 该 user-item 的加购次数 + 最近一次加购距 obs_end 天数（pair 级）
    pair_cart = obs_pair.filter(F.col(cart_col) > 0).groupBy("user_id", "item_id").agg(
        F.sum(cart_col).alias("cart_cnt"),
        F.min("days_ago").alias("cart_days_since"),
    )

    # 2) 加购前行为路径：最近一次加购之前是否有点击/收藏（pair 级）
    last_cart = obs_pair.filter(F.col(cart_col) > 0).groupBy("user_id", "item_id") \
                   .agg(F.max("action_date").alias("_last_cart_date"))
    pre_path = obs_pair.join(last_cart, ["user_id", "item_id"]) \
        .filter(
            (F.col("action_date") < F.col("_last_cart_date")) &
            ((F.col(click_col) > 0) | (F.col(collect_col) > 0))
        ).select("user_id", "item_id").distinct().withColumn("cart_pre_path", F.lit(1))
    pair_cart = pair_cart.join(pre_path, ["user_id", "item_id"], "left") \
                         .fillna({"cart_pre_path": 0})

    # 3) 购物车商品总数：user 观察窗口内加购过的不同商品数（user 级）
    user_cart_items = obs_user.filter(F.col(cart_col) > 0).groupBy("user_id") \
                         .agg(F.countDistinct("item_id").alias("cart_item_total"))

    # 4) 是否同时加购同类商品（同 parent_cat 的不同商品 > 1）（user 级）
    item_cat = product.select("item_id", "parent_cat")
    user_cart_cat = obs_user.filter(F.col(cart_col) > 0).select("user_id", "item_id").distinct() \
                       .join(item_cat, "item_id", "left")
    same_cat_cnt = user_cart_cat.groupBy("user_id", "parent_cat") \
                                .agg(F.countDistinct("item_id").alias("_n_same_cat"))
    cand_with_cat = pair_cart.select("user_id", "item_id").join(item_cat, "item_id", "left")
    same_cat = cand_with_cat.join(same_cat_cnt, ["user_id", "parent_cat"], "left") \
        .select("user_id", "item_id",
                F.when(F.col("_n_same_cat") > 1, 1).otherwise(0).alias("cart_same_cat"))

    out = pair_cart.join(user_cart_items, "user_id", "left") \
                   .join(same_cat, ["user_id", "item_id"], "left")
    return out


def build_cart_dataset(spark, mode):
    daily_path = os.path.join(DAILY_DIR, mode)
    out_root = os.path.join(CART_DIR, mode)

    print(f"[cart] 读取每日中间表: {daily_path}")
    # 不 persist daily：full 档 10 亿行中间表常驻内存会打满堆（OOM），直接读 parquet 走谓词下推
    daily = spark.read.parquet(daily_path)
    product, item_rep = load_shared(spark)
    item_first_date = daily.groupBy("item_id").agg(F.min("action_date").alias("first_date")).persist()

    windows = slice_windows()
    all_samples = None
    for w in windows:
        sample, cand = build_cart_labels(spark, daily, w)
        if sample is None:
            continue
        sample = sample.persist()
        obs = obs_window(daily, w)
        # 提取三维集合（与 dataset.py 一致），供特征最上游 left semi 过滤
        sample_users = sample.select("user_id").distinct().persist()
        sample_items = sample.select("item_id").distinct().persist()
        sample_pairs = sample.select("user_id", "item_id").distinct().persist()
        feats = build_slice_features(spark, daily, w, product, item_rep, item_first_date,
                                     sample_users, sample_items, sample_pairs)
        # cart 专属特征：user 级用 sample_users，pair 级用 sample_pairs 过滤
        obs_user = obs.join(F.broadcast(sample_users), "user_id", "left_semi")
        obs_pair = obs.join(F.broadcast(sample_pairs), ["user_id", "item_id"], "left_semi")
        cart_feats = build_cart_features(obs_user, obs_pair, product, w)

        assembled = assemble_slice(sample, feats, w) \
            .join(cart_feats, ["user_id", "item_id"], "left")
        n = assembled.count()
        cand.unpersist()  # sample 已 materialize，候选对缓存释放
        print(f"[cart] slice_id={w['slice_id']} 组装完成: {n:,} 样本")
        all_samples = assembled if all_samples is None else all_samples.unionByName(assembled)

    if all_samples is None:
        print("[cart] 所有断面均无正样本，无法构建（样本太小）。请用更大档位（dev/full）。")
        return None

    for split in ["train", "val", "test"]:
        part = all_samples.filter(F.col("split") == split)
        part.write.mode("overwrite").option("compression", "snappy") \
            .parquet(os.path.join(out_root, split))
        print(f"[cart] {split}: {part.count():,} 样本 -> {os.path.join(out_root, split)}")

    return all_samples


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=MODES, default="debug")
    args = parser.parse_args()

    spark = create_spark(f"Modeling-CartDataset-{args.mode}")
    t0 = time.time()
    build_cart_dataset(spark, args.mode)
    print(f"[cart] 全部完成, 耗时 {(time.time() - t0) / 60:.1f} 分钟")
    spark.stop()


if __name__ == "__main__":
    main()
