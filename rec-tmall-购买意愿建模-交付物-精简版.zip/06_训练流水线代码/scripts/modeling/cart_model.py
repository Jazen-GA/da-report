"""
购物车成交预测专项：训练 + 推理 + 高意向清单 + 业务价值测算（第二部分 b.2/b.3）
==============================================================================
复用基线算法框架（model_utils 三模型 + 目标编码），针对购物车样本训练专属成交模型：
  1. 读 cart 样本 → 数值 fillna/clip/标准化（train 拟合）→ 类别目标编码
  2. 三模型训练（LR/GBDT/XGBoost），val 早停，选最优
  3. 对测试集全量推理，输出成交概率
  4. 高意向未成交清单（概率降序）+ 分品类/分用户层级统计
  5. 业务价值测算：各阈值下的成交召回率/精确率/覆盖样本数

输出:
  data/modeling/cart/{mode}/cart_model.joblib           最优专项模型
  data/modeling/cart/{mode}/cart_metrics.json           三模型指标 + 最优
  data/modeling/cart/{mode}/high_intent_list.csv        高意向未成交清单（概率降序）
  data/modeling/cart/{mode}/value_assessment.csv        业务价值测算
用法: python scripts/modeling/cart_model.py --mode debug|dev|full
"""
import os
import sys
import json
import time
import argparse
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.modeling.config import *
from scripts.modeling import model_utils as mu
from sklearn.preprocessing import StandardScaler


def load_cart_split(mode, split):
    return pd.read_parquet(os.path.join(CART_DIR, mode, split))


def preprocess_cart(train, val, test, num_cols):
    """数值特征 fillna + clip + 标准化（train 拟合，套 val/test；clip 分位数来自 config.PREPROCESS）"""
    lo, hi = PREPROCESS.get("clip_quantiles", (None, None))
    scaler = StandardScaler()

    def _apply(df):
        X = df[num_cols].astype(float).copy()
        X = X.fillna(float(PREPROCESS.get("fill_numeric_na", 0.0)))
        if lo is not None and hi is not None:
            X = X.clip(X.quantile(lo), X.quantile(hi), axis=1)
        return X

    X_train = _apply(train)
    X_val = _apply(val)
    X_test = _apply(test)

    X_train[:] = scaler.fit_transform(X_train)
    X_val[:] = scaler.transform(X_val)
    X_test[:] = scaler.transform(X_test)
    return X_train, X_val, X_test


def train_cart(mode):
    train = load_cart_split(mode, "train")
    val = load_cart_split(mode, "val")
    test = load_cart_split(mode, "test")

    num_cols = mu.numeric_cols(train)
    y_train = train["label"].values
    y_val = val["label"].values
    y_test = test["label"].values

    print(f"[cart_model] 样本: train {len(train):,} / val {len(val):,} / test {len(test):,}，"
          f"数值特征 {len(num_cols)}，类别 {len(CAT_COLS)}")
    print(f"[cart_model] 预处理（fillna/clip/标准化，train 拟合）...")
    Xn_train, Xn_val, Xn_test = preprocess_cart(train, val, test, num_cols)

    # 目标编码（复用 model_utils：train OOF，val/test 用全 train 统计）
    te_train = mu.target_encode_train(train[CAT_COLS], train["label"])
    te_val = mu.target_encode_apply(val[CAT_COLS], train[CAT_COLS], train["label"])
    te_test = mu.target_encode_apply(test[CAT_COLS], train[CAT_COLS], train["label"])

    results, probas = {}, {}
    best_name, best_auc, best_model_obj = None, -1.0, None

    for name in ["lr", "gbdt", "xgb"]:
        cross = LR_CROSS_FEATURES if name == "lr" else None
        # 数值特征（已标准化）+ 目标编码 + 交叉，复用 build_feature_matrix
        full_train = train[num_cols].astype(float).copy()
        full_val = val[num_cols].astype(float).copy()
        full_test = test[num_cols].astype(float).copy()
        full_train[:] = Xn_train
        full_val[:] = Xn_val
        full_test[:] = Xn_test

        X_train, names = mu.build_feature_matrix(full_train, te_train, cross)
        X_val, _ = mu.build_feature_matrix(full_val, te_val, cross)
        X_test, _ = mu.build_feature_matrix(full_test, te_test, cross)

        t0 = time.time()
        model, val_prob = mu.fit_model(name, X_train, y_train, X_val, y_val)
        train_time = time.time() - t0
        val_metrics = mu.compute_metrics(y_val, val_prob)
        test_prob = model.predict_proba(X_test)[:, 1]

        probas[name] = test_prob
        results[name] = {
            "val_metrics": val_metrics,
            "test_metrics": mu.compute_metrics(y_test, test_prob),
            "train_time_sec": round(train_time, 2),
        }
        print(f"  {name}: val AUC={val_metrics['auc']} test AUC={results[name]['test_metrics']['auc']} "
              f"耗时 {train_time:.1f}s")

        if val_metrics["auc"] > best_auc:
            best_auc = val_metrics["auc"]
            best_name = name
            best_model_obj = model

    mu.save_model(best_model_obj, os.path.join(CART_DIR, mode, "cart_model.joblib"))

    summary = {
        "mode": mode,
        "best_model": best_name,
        "best_val_auc": best_auc,
        "models": results,
        "test_proba": {n: probas[n].tolist() for n in probas},
    }
    mu.write_json(summary, os.path.join(CART_DIR, mode, "cart_metrics.json"))
    print(f"[cart_model] 最优模型={best_name} (val AUC={best_auc})")
    return summary, test, y_test, probas[best_name], best_name


def export_high_intent(mode, test, y_test, proba, best_name):
    """高意向清单 + 分维度统计 + 业务价值测算（整改 #10/#11/#12/#16）"""
    df = test[["user_id", "item_id", "label"]].copy()
    for c in ["parent_cat", "u_active_days"]:
        if c in test.columns:
            df[c] = test[c].values
    df["proba"] = proba

    # 去重（整改 #11）：同一 user-item 对可能落在多个 test 断面，保留最高概率，一 pair 一概率
    df = df.sort_values("proba", ascending=False) \
           .drop_duplicates(subset=["user_id", "item_id"], keep="first") \
           .reset_index(drop=True)

    # 高意向阈值：用 CART_THRESHOLDS 中值；正样本率已变（~23.6%），阈值需结合 value_assessment 定
    hi_thr = CART_THRESHOLDS[len(CART_THRESHOLDS) // 2]

    # 高意向未成交清单（整改 #10）：label=0 且概率 >= 阈值，不是 test 全 label=0
    high_intent = df[(df["label"] == 0) & (df["proba"] >= hi_thr)].copy()
    high_intent = high_intent.sort_values("proba", ascending=False).reset_index(drop=True)
    high_intent.to_csv(os.path.join(CART_DIR, mode, "high_intent_list.csv"),
                       index=False, encoding="utf-8-sig")
    print(f"[cart_model] 高意向未成交清单 {len(high_intent):,} 条 (proba >= {hi_thr}, 去重后) -> high_intent_list.csv")

    # 分品类 / 分用户活跃度层级统计（整改 #12）：只统计高意向未成交样本，用户按活跃度分桶
    hi = df[(df["label"] == 0) & (df["proba"] >= hi_thr)].copy()
    stat = {}
    if "parent_cat" in hi.columns:
        g = hi.groupby("parent_cat").agg(
            n=("user_id", "size"), avg_proba=("proba", "mean")).reset_index()
        stat["parent_cat"] = g.sort_values("n", ascending=False).to_dict("records")
    if "u_active_days" in hi.columns:
        hi["u_active_level"] = pd.qcut(hi["u_active_days"], 3,
                                       labels=["低活跃", "中活跃", "高活跃"], duplicates="drop")
        g = hi.groupby("u_active_level", observed=True).agg(
            n=("user_id", "size"), avg_proba=("proba", "mean")).reset_index()
        stat["u_active_level"] = g.to_dict("records")

    # 业务价值测算（整改 #16）：各阈值下的覆盖/精确率/召回率 + 预期增量成交 + GMV/ROI 框架
    total_pos = int((df["label"] == 1).sum())
    rows = []
    for t in CART_THRESHOLDS:
        hit = df[df["proba"] >= t]
        tp = int((hit["label"] == 1).sum())
        # 预期增量成交 = 未成交高意向样本的成交概率期望（触达后预期额外转化的单数）
        incremental = float(hit[hit["label"] == 0]["proba"].sum()) if len(hit) else 0.0
        rows.append({
            "threshold": t,
            "coverage": int(len(hit)),
            "coverage_rate": round(len(hit) / len(df), 4) if len(df) else 0.0,
            "precision": round(tp / len(hit), 4) if len(hit) else 0.0,
            "recall": round(tp / total_pos, 4) if total_pos else 0.0,
            "incremental_orders": round(incremental, 1),
            # GMV/ROI 需业务客单价与触达成本，数据无金额字段，此处仅按可配置假设外推
            "gmv_est": round(incremental * ASSUME_AOV, 0) if ASSUME_AOV else None,
            "roi_est": round((incremental * ASSUME_AOV - len(hit) * ASSUME_TOUCH_COST)
                             / max(len(hit) * ASSUME_TOUCH_COST, 1e-9), 3)
                       if (ASSUME_AOV and ASSUME_TOUCH_COST > 0) else None,
        })
    val_df = pd.DataFrame(rows)
    val_df.to_csv(os.path.join(CART_DIR, mode, "value_assessment.csv"),
                  index=False, encoding="utf-8-sig")

    mu.write_json({
        "mode": mode, "best_model": best_name,
        "high_intent_threshold": hi_thr,
        "high_intent_total": int(len(high_intent)),
        "dim_stat": stat,
        "value_assessment": rows,
    }, os.path.join(CART_DIR, mode, "cart_export.json"))

    print("[cart_model] 业务价值测算（阈值 → 覆盖/精确率/召回率/预期增量成交）:")
    for r in rows:
        print(f"  proba>={r['threshold']}: 覆盖 {r['coverage']:,} "
              f"精确率 {r['precision']} 召回率 {r['recall']} 增量 {r['incremental_orders']}")
    return val_df, stat


def run(mode):
    summary, test, y_test, proba, best_name = train_cart(mode)
    export_high_intent(mode, test, y_test, proba, best_name)
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=MODES, default="dev")
    args = parser.parse_args()

    if not os.path.isdir(os.path.join(CART_DIR, args.mode, "train")):
        print(f"[cart_model] 未找到 cart/{args.mode}/train，跳过（先跑 cart_dataset.py）。")
        return
    run(args.mode)


if __name__ == "__main__":
    main()
