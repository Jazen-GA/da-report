"""
四维特征工程（配置驱动，按断面观察窗口计算）
==============================================
从每日行为中间表出发，对每个时间断面分别计算：
  - user 侧特征：频次 / 结构 / 活跃 / 偏好
  - item 侧特征：静态 / 热度 / 转化 / 口碑
  - cross 交叉特征：user-item 交互
  - sequence 序列特征：user 每日行为时间序列

时间合规：所有特征只用观察窗口 [obs_start, obs_end] 内的数据，标签只用
预测窗口 [pred_start, pred_end]，二者无交集，从规则上杜绝时间穿越。

特征组由 config.FEATURE_GROUPS 控制，可插拔。
"""
import os
import sys
from pyspark.sql import functions as F
from pyspark.sql import Window

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.modeling.config import *


# 行为计数列名：从 config 语义常量动态生成，避免换数据时硬编码行为名。
# 源列随 ACTION_VALUES 变；输出特征名（u_click_ratio_30d 等）是稳定语义标签，保持不变。
BUY_COL = f"{ACTION_BUY}_cnt"

U_CLICK_30D = f"u_{ACTION_CLICK}_cnt_30d"
U_COLLECT_30D = f"u_{ACTION_COLLECT}_cnt_30d"
U_CART_30D = f"u_{ACTION_CART}_cnt_30d"
U_BUY_30D = f"u_{ACTION_BUY}_cnt_30d"

I_CLICK_30D = f"i_{ACTION_CLICK}_cnt_30d"
I_CART_30D = f"i_{ACTION_CART}_cnt_30d"
I_BUY_30D = f"i_{ACTION_BUY}_cnt_30d"

X_CLICK = f"x_{ACTION_CLICK}_cnt"
X_COLLECT = f"x_{ACTION_COLLECT}_cnt"
X_CART = f"x_{ACTION_CART}_cnt"
X_BUY = f"x_{ACTION_BUY}_cnt"


# ── 通用工具 ──

def obs_window(daily, w):
    """切出断面观察窗口数据，并加 days_ago 列（距 obs_end 的天数，0=obs_end 当天）"""
    obs = daily.filter(
        (F.col("action_date") >= w["obs_start"]) &
        (F.col("action_date") <= w["obs_end"])
    ).withColumn("days_ago", F.datediff(F.lit(w["obs_end"]).cast("date"), F.col("action_date")))
    return obs


def _ratio(num_col, den_col):
    """安全除法，分母 <= 0 时返回 0"""
    return F.when(F.col(den_col) > 0, F.col(num_col) / F.col(den_col)).otherwise(0.0)


def _freq_exprs(prefix, w_days):
    """近 w_days 天各行为频次 + 总行为（在已带 days_ago 的 obs 上做条件聚合）"""
    cond = F.col("days_ago") < w_days
    exprs = [
        F.sum(F.when(cond, F.col(f"{a}_cnt")).otherwise(0)).alias(f"{prefix}{a}_cnt_{w_days}d")
        for a in ACTION_VALUES
    ]
    exprs.append(F.sum(F.when(cond, F.col("total_cnt")).otherwise(0)).alias(f"{prefix}total_cnt_{w_days}d"))
    return exprs


# ── 用户侧特征 ──

def build_user_features(obs, w):
    """用户侧特征：频次 / 结构 / 活跃，输出 user_id + u_* 列（偏好另行合并）"""
    keys = ["user_id"]

    # 1) 频次（近 7/14/30 天）+ 时间衰减加权（近 30 天）
    freq_exprs = []
    for wd in FEATURE_WINDOWS:
        freq_exprs += _freq_exprs("u_", wd)
    decay = F.exp(-F.lit(TIME_DECAY_LAMBDA) * F.col("days_ago"))
    for a in ACTION_VALUES:
        freq_exprs.append(F.sum(F.col(f"{a}_cnt") * decay).alias(f"u_decay_{a}_cnt"))
    freq_exprs.append(F.sum(F.col("total_cnt") * decay).alias("u_decay_total_cnt"))

    u_freq = obs.groupBy(*keys).agg(*freq_exprs)

    # 2) 结构特征（近 30 天占比 + 转化率），在频次结果上派生
    u_freq = u_freq.withColumn("u_click_ratio_30d", _ratio(U_CLICK_30D, "u_total_cnt_30d")) \
                   .withColumn("u_collect_ratio_30d", _ratio(U_COLLECT_30D, "u_total_cnt_30d")) \
                   .withColumn("u_cart_ratio_30d", _ratio(U_CART_30D, "u_total_cnt_30d")) \
                   .withColumn("u_alipay_ratio_30d", _ratio(U_BUY_30D, "u_total_cnt_30d")) \
                   .withColumn("u_click_to_collect", _ratio(U_COLLECT_30D, U_CLICK_30D)) \
                   .withColumn("u_click_to_cart", _ratio(U_CART_30D, U_CLICK_30D)) \
                   .withColumn("u_cart_to_alipay", _ratio(U_BUY_30D, U_CART_30D))

    # 3) 活跃属性（基于 user-date 去重粒度）
    user_daily = obs.groupBy("user_id", "action_date").agg(
        F.sum("total_cnt").alias("_day_total"),
        F.sum(BUY_COL).alias("_day_buy"),
    ).withColumn("_days_ago", F.datediff(F.lit(w["obs_end"]).cast("date"), F.col("action_date")))

    w_desc = Window.partitionBy("user_id").orderBy(F.col("action_date").desc())
    active = user_daily.withColumn("_prev", F.lag("action_date").over(w_desc)) \
                       .withColumn("_gap", F.datediff(F.col("_prev"), F.col("action_date"))) \
                       .withColumn("_is_break", F.when(F.col("_gap") > 1, 1).otherwise(0)) \
                       .withColumn("_seg", F.sum(F.coalesce(F.col("_is_break"), F.lit(0))).over(w_desc))

    u_active = active.groupBy("user_id").agg(
        F.max("_days_ago").alias("u_first_days_ago"),           # 首次行为距 obs_end 天数
        F.min("_days_ago").alias("u_recency_days"),             # 最近行为距 obs_end 天数
        F.count("*").alias("u_active_days"),                    # 累计活跃天数
        F.sum(F.when(F.col("_seg") == 0, 1).otherwise(0)).alias("u_consecutive_active_days"),
        (F.datediff(F.max("action_date"), F.min("action_date")) /
         F.greatest(F.count("*") - 1, F.lit(1))).alias("u_avg_visit_interval"),
    )

    # 4) 偏好特征（Top3 品类 + 集中度 + Top 品牌）在 build_slice_features 中另行合并（需 product 表）

    return u_freq.join(u_active, keys, "left")


def build_user_preference(obs, product, w):
    """用户侧偏好特征（单独函数，需 product 表）：Top3 品类 / 集中度 / Top 品牌"""
    p = F.broadcast(product.select("item_id", "parent_cat", "brand_id"))

    user_cat = obs.join(p, "item_id", "left") \
                  .groupBy("user_id", "parent_cat") \
                  .agg(F.count("*").alias("_cat_cnt"))
    total = user_cat.groupBy("user_id").agg(F.sum("_cat_cnt").alias("_total"))
    user_cat = user_cat.join(total, "user_id") \
                       .withColumn("_share", F.col("_cat_cnt") / F.col("_total"))

    # 集中度 HHI = sum(share^2)
    u_hhi = user_cat.groupBy("user_id").agg(F.sum(F.col("_share") ** 2).alias("u_cat_hhi"))

    # Top3 品类
    wc = Window.partitionBy("user_id").orderBy(F.desc("_cat_cnt"))
    ranked = user_cat.withColumn("_rank", F.row_number().over(wc))
    u_top_cat = ranked.filter(F.col("_rank") <= 3).groupBy("user_id").agg(
        F.max(F.when(F.col("_rank") == 1, F.col("parent_cat"))).alias("u_top1_cat"),
        F.max(F.when(F.col("_rank") == 2, F.col("parent_cat"))).alias("u_top2_cat"),
        F.max(F.when(F.col("_rank") == 3, F.col("parent_cat"))).alias("u_top3_cat"),
        F.max(F.when(F.col("_rank") == 1, F.col("_share"))).alias("u_top1_cat_share"),
    )

    # Top1 品牌
    user_brand = obs.join(p, "item_id", "left") \
                    .groupBy("user_id", "brand_id") \
                    .agg(F.count("*").alias("_brand_cnt"))
    wb = Window.partitionBy("user_id").orderBy(F.desc("_brand_cnt"))
    u_top_brand = user_brand.withColumn("_rank", F.row_number().over(wb)) \
                            .filter(F.col("_rank") == 1) \
                            .select("user_id", F.col("brand_id").alias("u_top1_brand"))

    out = u_hhi.join(u_top_cat, "user_id", "left").join(u_top_brand, "user_id", "left")
    return out


# ── 商品侧特征 ──

def build_item_features(obs, w, product, item_rep, item_first_date):
    """商品侧特征：静态 / 热度 / 转化 / 口碑，输出 item_id + i_* 列"""
    keys = ["item_id"]

    # 1) 热度（近 7/14/30 天）+ 环比增长率（近 7 天 vs 前 7 天）
    heat_exprs = []
    for wd in FEATURE_WINDOWS:
        heat_exprs += _freq_exprs("i_", wd)
    # 前 7 天（7 <= days_ago < 14）用于环比
    prev_cond = (F.col("days_ago") >= 7) & (F.col("days_ago") < 14)
    for a in ACTION_VALUES:
        heat_exprs.append(F.sum(F.when(prev_cond, F.col(f"{a}_cnt")).otherwise(0)).alias(f"i_{a}_cnt_prev7d"))
    i_heat = obs.groupBy(*keys).agg(*heat_exprs)

    # 2) 转化绩效（观察窗口近 30 天）+ 动销率（动销天数 / 观察窗口长度）
    i_sell = obs.filter(F.col(BUY_COL) > 0).groupBy(*keys) \
                .agg(F.countDistinct("action_date").alias("i_sell_days"))
    i_heat = i_heat.join(i_sell, keys, "left") \
                   .withColumn("i_sell_days", F.coalesce(F.col("i_sell_days"), F.lit(0))) \
                   .withColumn("i_click_to_alipay", _ratio(I_BUY_30D, I_CLICK_30D)) \
                   .withColumn("i_cart_to_alipay", _ratio(I_BUY_30D, I_CART_30D)) \
                   .withColumn("i_sell_rate", F.col("i_sell_days") / F.lit(OBS_WINDOW_DAYS))
    # 环比增长率
    for a in ACTION_VALUES:
        i_heat = i_heat.withColumn(
            f"i_{a}_growth_7d",
            F.when(F.col(f"i_{a}_cnt_prev7d") > 0,
                   (F.col(f"i_{a}_cnt_7d") - F.col(f"i_{a}_cnt_prev7d")) / F.col(f"i_{a}_cnt_prev7d"))
             .otherwise(0.0))

    # 3) 静态属性 + 上架时长（商品首次出现日期近似）
    i_static = product.select(
        "item_id", "parent_cat", "leaf_cat", "brand_id", "seller_id"
    ).join(item_first_date, "item_id", "left") \
     .withColumn("i_listing_days", F.datediff(F.lit(w["obs_end"]).cast("date"), F.col("first_date"))) \
     .drop("first_date")

    # 4) 口碑特征（i_review_cnt/i_pos_rate/i_avg_sentiment）已剔除：
    #    来自全量评论（无时间戳），含预测时点之后的评论 → 未来信息泄漏。
    #    评论数据无时间戳，无法按时间截断修复，只能剔除（见整改方案 #5）。
    # 以观察窗口内的商品热度表为基表 left join 静态属性：
    # product 维表缺记录时，热度/转化特征仍保留，静态属性为 null（由 preprocess 处理），
    # 反之若以 product 为基表，维表缺记录会让已算好的热度特征整行丢失。
    out = i_heat.join(i_static, keys, "left")
    return out


# ── 交叉特征 ──

def build_cross_features(obs, w):
    """user-item 交叉特征：四类交互次数 / 最近交互 / 交互深度，输出 user_id+item_id+x_*"""
    keys = ["user_id", "item_id"]

    agg = [
        F.count("*").alias("x_interact_days"),  # 观察窗口内交互天数
        F.min("days_ago").alias("x_recency_days"),  # 最近交互距 obs_end
        F.max("days_ago").alias("x_first_days_ago"),
    ]
    for a in ACTION_VALUES:
        agg.append(F.sum(F.col(f"{a}_cnt")).alias(f"x_{a}_cnt"))

    x = obs.groupBy(*keys).agg(*agg)
    # 交互深度评分 = click*1 + collect*2 + cart*3 + alipay*4
    x = x.withColumn("x_depth",
                     F.col(X_CLICK) * 1 + F.col(X_COLLECT) * 2 +
                     F.col(X_CART) * 3 + F.col(X_BUY) * 4)
    # 完整意向路径：观察窗口内 click -> collect -> cart 均有记录
    x = x.withColumn("x_has_full_path",
                     ((F.col(X_CLICK) > 0) & (F.col(X_COLLECT) > 0) & (F.col(X_CART) > 0)).cast("int"))
    # 当前行为决策阶段（多值编码，越高越接近购买）：
    #   0=仅点击  1=已收藏  2=已加购  3=已购买（观察窗口内）
    x = x.withColumn("x_stage",
                     F.when(F.col(X_BUY) > 0, 3)
                      .when(F.col(X_CART) > 0, 2)
                      .when(F.col(X_COLLECT) > 0, 1)
                      .when(F.col(X_CLICK) > 0, 0)
                      .otherwise(-1))
    return x


# ── 序列特征 ──

def build_sequence_features(obs, w):
    """user 序列特征：每日行为量均值/方差/增长率 + 连续无购买天数，输出 user_id+s_*"""
    keys = ["user_id"]

    user_daily = obs.groupBy("user_id", "action_date").agg(
        F.sum("total_cnt").alias("_day_total"),
        F.sum(BUY_COL).alias("_day_buy"),
    ).withColumn("_days_ago", F.datediff(F.lit(w["obs_end"]).cast("date"), F.col("action_date")))

    # 均值/方差：近 wd 天无活跃 → avg/variance 为 null，coalesce 归 0（单活跃日方差定义为 0）
    s_exprs = []
    for wd in FEATURE_WINDOWS:
        cond = F.col("_days_ago") < wd
        s_exprs += [
            F.coalesce(F.avg(F.when(cond, F.col("_day_total"))), F.lit(0.0)).alias(f"s_day_mean_{wd}d"),
            F.coalesce(F.variance(F.when(cond, F.col("_day_total"))), F.lit(0.0)).alias(f"s_day_var_{wd}d"),
        ]
    # 增长率 = (近7天均值 - 前7天均值) / 前7天均值
    prev_cond = (F.col("_days_ago") >= 7) & (F.col("_days_ago") < 14)
    s = user_daily.groupBy("user_id").agg(
        *s_exprs,
        F.avg(F.when(prev_cond, F.col("_day_total"))).alias("_mean_prev7d"),
    )
    s = s.withColumn("s_day_growth_7d",
                     F.when(F.col("_mean_prev7d") > 0,
                            (F.col("s_day_mean_7d") - F.col("_mean_prev7d")) / F.col("_mean_prev7d"))
                      .otherwise(0.0)).drop("_mean_prev7d")

    # 行为间隔中位数：相邻活跃日之间的天数差（单活跃日无间隔，join 后填 0）
    w_gap = Window.partitionBy("user_id").orderBy(F.col("action_date"))
    gap_median = user_daily \
        .withColumn("_gap", F.datediff(F.col("action_date"), F.lag("action_date").over(w_gap))) \
        .filter(F.col("_gap").isNotNull()) \
        .groupBy("user_id").agg(F.percentile_approx(F.col("_gap"), 0.5).alias("s_day_gap_median"))
    s = s.join(gap_median, keys, "left").fillna({"s_day_gap_median": 0.0})

    # 连续无购买天数：观察窗口内最近一次 alipay 距 obs_end；无购买 → 观察窗口长度
    last_buy = obs.filter(F.col(BUY_COL) > 0).groupBy("user_id") \
                  .agg(F.max("action_date").alias("_last_buy_date"))
    last_buy = last_buy.withColumn(
        "s_days_since_last_buy",
        F.datediff(F.lit(w["obs_end"]).cast("date"), F.col("_last_buy_date"))
    ).select("user_id", "s_days_since_last_buy")

    # 未购买用户补默认值（观察窗口长度）
    s = s.join(last_buy, keys, "left") \
         .fillna({"s_days_since_last_buy": float(OBS_WINDOW_DAYS)})
    return s


# ── 断面组装 ──

def build_slice_features(spark, daily, w, product, item_rep, item_first_date,
                         sample_users=None, sample_items=None, sample_pairs=None):
    """对一个断面计算所有启用的特征组，返回 {组名: DataFrame}，每张统一带 slice_id。

    sample_users / sample_items / sample_pairs 为采样样本涉及的三个维度集合（上游
    已提取并缓存）。全量档下在特征计算最上游用 left semi join 把原始行为表收敛到这些
    实体，避免对全量行为表（上亿行）做全量聚合导致 OOM：
      user 特征 ← sample_users；item 特征 ← sample_items；cross 特征 ← sample_pairs。
    left semi 只过滤左表、不产生重复行，比 inner join 更贴合「过滤」语义。
    """
    slice_id = w["slice_id"]
    print(f"[features] 断面 slice_id={slice_id} (obs {w['obs_start']}~{w['obs_end']}) 计算特征...")
    obs = obs_window(daily, w)

    persisted = []
    if sample_users is not None:
        obs_user = obs.join(F.broadcast(sample_users), "user_id", "left_semi").persist()
        obs_item = obs.join(F.broadcast(sample_items), "item_id", "left_semi").persist()
        obs_pair = obs.join(F.broadcast(sample_pairs), ["user_id", "item_id"], "left_semi").persist()
        persisted += [obs_user, obs_item, obs_pair]
    else:
        obs_user = obs.persist()
        obs_item = obs
        obs_pair = obs
        persisted.append(obs_user)

    feats = {}
    if "user" in FEATURE_GROUPS:
        u = build_user_features(obs_user, w)
        if product is not None:
            u = u.join(build_user_preference(obs_user, product, w), "user_id", "left")
        feats["user"] = u.withColumn("slice_id", F.lit(slice_id))
    if "item" in FEATURE_GROUPS:
        feats["item"] = build_item_features(obs_item, w, product, item_rep, item_first_date) \
            .withColumn("slice_id", F.lit(slice_id))
    if "cross" in FEATURE_GROUPS:
        feats["cross"] = build_cross_features(obs_pair, w).withColumn("slice_id", F.lit(slice_id))
    if "sequence" in FEATURE_GROUPS:
        feats["sequence"] = build_sequence_features(obs_user, w).withColumn("slice_id", F.lit(slice_id))

    for d in persisted:
        d.unpersist()
    return feats
