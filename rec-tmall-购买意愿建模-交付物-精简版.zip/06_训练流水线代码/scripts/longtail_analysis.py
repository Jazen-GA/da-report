"""
商品结构与长尾效应验证分析 (模块 c)
====================================
c1. 商品热度分布拟合与长尾效应验证（频次分布 + 洛伦兹曲线 + 帕累托拟合 + Gini）
c2. 头部与长尾商品价值量化（头部 20%/10%/5% 贡献占比）
c3. 长尾商品价值评估（类目分布 + 转化率/动销率对比 + 有效/无效长尾）

数据源: data/cleaned/item_ops
输出:
  - reports/longtail_distribution.csv      频次分布（log 分箱）
  - reports/longtail_head_contribution.csv 头部贡献占比
  - reports/longtail_value.csv             长尾价值评估
  - reports/longtail_category.csv          长尾商品类目分布
  - reports/invalid_longtail_profile.csv   无效长尾特征
  - reports/longtail_charts/               图表
"""
import os, sys, warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

plt.rcParams["font.sans-serif"] = ["Arial Unicode MS", "SimHei", "Heiti SC"]
plt.rcParams["axes.unicode_minus"] = False

from pyspark.sql import functions as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import create_spark, REPORTS_DIR, ITEM_OPS_PATH

CHARTS_DIR = os.path.join(REPORTS_DIR, "longtail_charts")
os.makedirs(CHARTS_DIR, exist_ok=True)

spark = create_spark("Longtail-Analysis")
item_ops = spark.read.parquet(ITEM_OPS_PATH)

# ═══════════════════════════════════════════════════════════════
# C0. 商品级热度数据落地到 pandas
# ═══════════════════════════════════════════════════════════════
print("=" * 60)
print("C0: 加载商品级热度数据")
print("=" * 60)

item_df = item_ops.select(
    "item_id", "click_cnt", "alipay_cnt", "category", "parent_cat", "is_sold"
).toPandas()
print(f"  商品数: {len(item_df):,}")
print(f"  零交互商品: {(item_df['click_cnt']==0).sum():,}")
print(f"  零成交商品: {(item_df['alipay_cnt']==0).sum():,}")

# ═══════════════════════════════════════════════════════════════
# C1. 频次分布 + 洛伦兹 + 帕累托拟合
# ═══════════════════════════════════════════════════════════════
print("\n" + "=" * 60)
print("C1: 商品热度分布拟合与长尾效应验证")
print("=" * 60)

def gini_coefficient(values):
    """Gini 系数（0=绝对均匀，1=极端集中）"""
    v = np.sort(values)
    n = len(v)
    cum = np.cumsum(v)
    return (2 * np.sum((np.arange(1, n + 1) * v)) - (n + 1) * cum[-1]) / (n * cum[-1])

def fit_power_law(values):
    """幂律拟合：对非零值用 log-log 生存函数回归，返回指数 alpha 与 R²"""
    v = np.sort(values[values > 0])[::-1]  # 降序
    if len(v) < 100:
        return np.nan, np.nan
    ranks = np.arange(1, len(v) + 1)
    # 生存函数 S(x) = rank / n
    x = np.log(v)
    y = np.log(ranks / len(v))
    # 去掉尾部噪声（rank 过小/值重复导致的平台）
    mask = (ranks >= 10) & (v >= v[0] * 0.001)
    x, y = x[mask], y[mask]
    if len(x) < 50:
        return np.nan, np.nan
    slope, intercept = np.polyfit(x, y, 1)
    alpha = -slope
    y_pred = slope * x + intercept
    ss_res = np.sum((y - y_pred) ** 2)
    ss_tot = np.sum((y - y.mean()) ** 2)
    r2 = 1 - ss_res / ss_tot
    return alpha, r2

results = {}
for col, label in [("click_cnt", "流量(点击)"), ("alipay_cnt", "销量(成交)")]:
    vals = item_df[col].values
    gini = gini_coefficient(vals)
    alpha, r2 = fit_power_law(vals)
    results[label] = {"gini": gini, "alpha": alpha, "r2": r2}
    print(f"  {label}: Gini={gini:.4f}, 幂律指数 α={alpha:.3f}, R²={r2:.4f}")

# ── 幂律拟合结果落地（供报告引用）──
power_law_df = pd.DataFrame([
    {
        "指标": "流量(点击)",
        "Gini系数": round(results["流量(点击)"]["gini"], 4),
        "幂律指数α": round(results["流量(点击)"]["alpha"], 4),
        "拟合R²": round(results["流量(点击)"]["r2"], 4),
    },
    {
        "指标": "销量(成交)",
        "Gini系数": round(results["销量(成交)"]["gini"], 4),
        "幂律指数α": round(results["销量(成交)"]["alpha"], 4),
        "拟合R²": round(results["销量(成交)"]["r2"], 4),
    },
])
power_law_df.to_csv(os.path.join(REPORTS_DIR, "longtail_power_law.csv"), index=False, encoding="utf-8-sig")
print("  幂律拟合结果已保存 longtail_power_law.csv")

# ── 频次分布（log 分箱）──
def log_binned_freq(values, col_name, label):
    pos = values[values > 0]
    max_bin = int(np.log10(pos.max())) + 1
    bins = [0] + [10 ** i for i in range(max_bin + 1)]
    bin_labels = []
    for i in range(len(bins) - 1):
        bin_labels.append(f"[{bins[i]}, {bins[i+1]})")
    counts, _ = np.histogram(values, bins=bins)
    df = pd.DataFrame({"热度区间": bin_labels, "商品数": counts})
    df["商品占比%"] = (df["商品数"] / len(values) * 100).round(2)
    df["热度区间"] = df["热度区间"].replace("[0, 1)", "[0, 1) 零热度")
    return df

freq_click = log_binned_freq(item_df["click_cnt"].values, "click_cnt", "流量")
freq_sales = log_binned_freq(item_df["alipay_cnt"].values, "alipay_cnt", "销量")
freq_click["指标"] = "流量(点击)"
freq_sales["指标"] = "销量(成交)"
freq_all = pd.concat([freq_click, freq_sales], ignore_index=True)
freq_all.to_csv(os.path.join(REPORTS_DIR, "longtail_distribution.csv"), index=False, encoding="utf-8-sig")
print(f"  频次分布已保存 longtail_distribution.csv")

# ═══════════════════════════════════════════════════════════════
# C2. 头部与长尾商品价值量化
# ═══════════════════════════════════════════════════════════════
print("\n" + "=" * 60)
print("C2: 头部与长尾商品价值量化")
print("=" * 60)

def head_contribution(values, head_pcts=[0.20, 0.10, 0.05, 0.01]):
    """按降序排序，计算头部 X% 商品的贡献占比"""
    v = np.sort(values)[::-1]
    total = v.sum()
    n = len(v)
    out = {}
    for p in head_pcts:
        k = max(1, int(n * p))
        out[f"头部{int(p*100)}%"] = v[:k].sum() / total * 100
    out["尾部80%"] = v[int(n*0.20):].sum() / total * 100
    return out

head_flow = head_contribution(item_df["click_cnt"].values)
head_sales = head_contribution(item_df["alipay_cnt"].values)

head_df = pd.DataFrame({
    "分层": list(head_flow.keys()),
    "流量贡献%": [round(v, 2) for v in head_flow.values()],
    "销量贡献%": [round(head_sales[k], 2) for k in head_flow.keys()],
})
head_df.to_csv(os.path.join(REPORTS_DIR, "longtail_head_contribution.csv"), index=False, encoding="utf-8-sig")
print("  头部/长尾贡献占比:")
print(head_df.to_string(index=False))

# ═══════════════════════════════════════════════════════════════
# C3. 长尾商品价值评估
# ═══════════════════════════════════════════════════════════════
print("\n" + "=" * 60)
print("C3: 长尾商品价值评估")
print("=" * 60)

# 定义头部（销量前20%）与长尾（后80%）
n = len(item_df)
item_df = item_df.sort_values("alipay_cnt", ascending=False).reset_index(drop=True)
head_mask = item_df.index < int(n * 0.20)
tail_mask = ~head_mask

head_items = item_df[head_mask]
tail_items = item_df[tail_mask]

# 长尾内再区分 有效长尾（有成交）与 无效长尾（零成交）
valid_tail = tail_items[tail_items["alipay_cnt"] > 0]
invalid_tail = tail_items[tail_items["alipay_cnt"] == 0]

print(f"  头部商品: {len(head_items):,} | 长尾商品: {len(tail_items):,}")
print(f"  长尾中 有效长尾(有成交): {len(valid_tail):,} | 无效长尾(零成交): {len(invalid_tail):,}")

# ── 长尾 vs 头部 价值对比 ──
def seg_profile(df, label):
    return {
        "商品分层": label,
        "商品数": len(df),
        "总点击量": int(df["click_cnt"].sum()),
        "总销量": int(df["alipay_cnt"].sum()),
        "动销率%": round((df["alipay_cnt"] > 0).mean() * 100, 2),
        "点击购买转化率%": round(df["alipay_cnt"].sum() / df["click_cnt"].sum() * 100, 3) if df["click_cnt"].sum() > 0 else 0,
        "覆盖叶子类目数": df["category"].nunique(),
        "覆盖父类目数": df["parent_cat"].nunique(),
    }

value_rows = [
    seg_profile(head_items, "头部商品(前20%)"),
    seg_profile(tail_items, "长尾商品(后80%)"),
    seg_profile(valid_tail, "  └有效长尾(有成交)"),
    seg_profile(invalid_tail, "  └无效长尾(零成交)"),
]
value_df = pd.DataFrame(value_rows)
value_df.to_csv(os.path.join(REPORTS_DIR, "longtail_value.csv"), index=False, encoding="utf-8-sig")
print("  长尾价值评估:")
print(value_df.to_string(index=False))

# ── 长尾商品类目分布（覆盖哪些细分叶子类目）──
total_leaf = item_df["category"].nunique()
head_leaf = head_items["category"].nunique()
tail_leaf = tail_items["category"].nunique()
print(f"  全量叶子类目 {total_leaf} | 头部覆盖 {head_leaf} | 长尾覆盖 {tail_leaf}")

tail_cat = tail_items.groupby("parent_cat").agg(
    长尾商品数=("item_id", "count"),
    长尾销量=("alipay_cnt", "sum"),
    覆盖叶子类目数=("category", "nunique"),
).reset_index().sort_values("长尾商品数", ascending=False)
tail_cat["长尾商品占比%"] = (tail_cat["长尾商品数"] / len(tail_items) * 100).round(2)
tail_cat = tail_cat.rename(columns={"parent_cat": "父类目"})
tail_cat.to_csv(os.path.join(REPORTS_DIR, "longtail_category.csv"), index=False, encoding="utf-8-sig")
print(f"  长尾类目分布已保存（Top {len(tail_cat)} 父类目）")

# ── 无效长尾特征 ──
invalid_profile = {
    "无效长尾(零成交)商品数": len(invalid_tail),
    "占全量商品比%": round(len(invalid_tail) / n * 100, 2),
    "占长尾商品比%": round(len(invalid_tail) / len(tail_items) * 100, 2),
    "有点击但零成交商品数": int((invalid_tail["click_cnt"] > 0).sum()),
    "完全零交互商品数": int((invalid_tail["click_cnt"] == 0).sum()),
    "无效长尾覆盖叶子类目数": invalid_tail["category"].nunique(),
    "无效长尾覆盖父类目数": invalid_tail["parent_cat"].nunique(),
}
# 无效长尾 vs 有效长尾的点击量差异（有交互但没转化的商品多少）
invalid_profile["无效长尾中有曝光未成交商品占比%"] = round(
    (invalid_tail["click_cnt"] > 0).sum() / len(invalid_tail) * 100, 2
)
invalid_df = pd.DataFrame([invalid_profile])
invalid_df.to_csv(os.path.join(REPORTS_DIR, "invalid_longtail_profile.csv"), index=False, encoding="utf-8-sig")
print("  无效长尾特征:")
for k, v in invalid_profile.items():
    print(f"    {k}: {v}")

# ═══════════════════════════════════════════════════════════════
# 可视化
# ═══════════════════════════════════════════════════════════════
print("\n" + "=" * 60)
print("生成图表")
print("=" * 60)

fig, axes = plt.subplots(2, 2, figsize=(20, 16))

# ── 图1: 洛伦兹曲线（流量 vs 销量）──
ax = axes[0, 0]
for col, label, color in [("click_cnt", "流量(点击)", "#4C72B0"), ("alipay_cnt", "销量(成交)", "#DD8452")]:
    v = np.sort(item_df[col].values)[::-1]
    cum = np.cumsum(v) / v.sum()
    ax.plot(np.linspace(0, 100, len(cum)), cum * 100, color=color, lw=2,
            label=f"{label} (Gini={results['流量(点击)' if '流量' in label else '销量(成交)']['gini']:.3f})")
ax.plot([0, 100], [0, 100], "--", color="gray", lw=1, label="绝对均匀")
ax.fill_between(np.linspace(0, 100, 100), np.linspace(0, 100, 100), 100, color="gray", alpha=0.05)
ax.set_xlabel("商品累计占比 (%)", fontsize=11)
ax.set_ylabel("累计贡献占比 (%)", fontsize=11)
ax.set_title("商品热度洛伦兹曲线（流量 vs 销量）", fontsize=14, fontweight="bold")
ax.legend(fontsize=10)

# ── 图2: 频次分布（log-log）──
ax = axes[0, 1]
for col, label, color in [("click_cnt", "流量", "#4C72B0"), ("alipay_cnt", "销量", "#DD8452")]:
    v = np.sort(item_df[col].values[item_df[col].values > 0])[::-1]
    ranks = np.arange(1, len(v) + 1)
    # 采样画 log-log 生存函数
    idx = np.unique(np.logspace(0, np.log10(len(v)), 200).astype(int))
    idx = idx[idx < len(v)]
    ax.loglog(v[idx], ranks[idx] / len(v), ".", markersize=4, color=color, alpha=0.7, label=label)
ax.set_xlabel("热度值 (log)", fontsize=11)
ax.set_ylabel("生存概率 P(X > x) (log)", fontsize=11)
ax.set_title("幂律分布拟合（log-log 生存函数）", fontsize=14, fontweight="bold")
ax.legend(fontsize=10)

# ── 图3: 头部/长尾贡献对比 ──
ax = axes[1, 0]
head_labels = ["头部1%", "头部5%", "头部10%", "头部20%", "尾部80%"]
x = np.arange(len(head_labels))
w = 0.35
ax.bar(x - w/2, head_df["流量贡献%"], w, label="流量贡献", color="#4C72B0", alpha=0.9)
ax.bar(x + w/2, head_df["销量贡献%"], w, label="销量贡献", color="#DD8452", alpha=0.9)
ax.set_xticks(x)
ax.set_xticklabels(head_labels, fontsize=11)
ax.set_ylabel("贡献占比 (%)", fontsize=11)
ax.set_title("头部/长尾商品价值贡献分层", fontsize=14, fontweight="bold")
ax.legend(fontsize=10)
for i, (f, s) in enumerate(zip(head_df["流量贡献%"], head_df["销量贡献%"])):
    ax.text(i - w/2, f + 1, f"{f:.1f}", ha="center", fontsize=8)
    ax.text(i + w/2, s + 1, f"{s:.1f}", ha="center", fontsize=8)

# ── 图4: 长尾商品类目分布 Top15 ──
ax = axes[1, 1]
top_tail_cat = tail_cat.head(15).sort_values("长尾商品数")
ax.barh(range(len(top_tail_cat)), top_tail_cat["长尾商品数"], color="#55A868", alpha=0.85)
ax.set_yticks(range(len(top_tail_cat)))
ax.set_yticklabels([f"类目{int(c)}" for c in top_tail_cat["父类目"]], fontsize=9)
ax.set_xlabel("长尾商品数", fontsize=11)
ax.set_title("长尾商品 Top15 父类目分布", fontsize=14, fontweight="bold")
ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"{v/1e6:.1f}M"))

plt.tight_layout()
plt.savefig(os.path.join(CHARTS_DIR, "longtail_overview.png"), dpi=150, bbox_inches="tight")
plt.close()
print("  ✓ 图表已保存: longtail_charts/longtail_overview.png")

print("\n" + "=" * 60)
print("模块 c 完成!")
print("=" * 60)

spark.stop()
