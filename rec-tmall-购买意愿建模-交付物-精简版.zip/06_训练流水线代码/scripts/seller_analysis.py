"""
卖家绩效评估与头部卖家特征分析 (模块 b)
========================================
b1. 卖家全维度绩效统计与梯队划分（绩效明细 + GMV 相对估算 + 三梯队 + CR10/50）
b2. 头部卖家运营特征深度分析（品类布局 + 商品结构 + 转化/流量效率对比）

GMV 口径说明:
  数据集无价格字段，按「订单量 × 类目成交价值权重」做相对估算。
  类目成交价值权重 = 叶子类目动销强度（销量 / 商品数；点击量不足 1000 的叶子类目回退到父类目动销强度）。
  该值仅用于卖家横向梯队对比，非真实成交金额。

数据源: data/cleaned/item_ops
输出:
  - reports/seller_metrics.csv            卖家全维度绩效明细（全量）
  - reports/seller_gmv_rank.csv           卖家 GMV 排名 Top100
  - reports/seller_concentration.csv      卖家集中度 CR10/50
  - reports/seller_tiers.csv              卖家梯队汇总
  - reports/seller_tier_compare.csv       头部 vs 腰部卖家运营特征对比
  - reports/seller_charts/                图表
"""
import os, sys, warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

plt.rcParams["font.sans-serif"] = ["Arial Unicode MS", "SimHei", "Heiti SC"]
plt.rcParams["axes.unicode_minus"] = False

from pyspark.sql import functions as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import create_spark, REPORTS_DIR, ITEM_OPS_PATH

CHARTS_DIR = os.path.join(REPORTS_DIR, "seller_charts")
os.makedirs(CHARTS_DIR, exist_ok=True)

# GMV 权重回退门槛
MIN_LEAF_CLICK = 1000

spark = create_spark("Seller-Analysis")
item_ops = spark.read.parquet(ITEM_OPS_PATH)

# ═══════════════════════════════════════════════════════════════
# B0. 类目成交价值权重（GMV 估算用）
# ═══════════════════════════════════════════════════════════════
print("=" * 60)
print("B0: 计算类目成交价值权重")
print("=" * 60)

cat_conv = item_ops.groupBy("category", "parent_cat").agg(
    F.count("*").alias("cat_items"),
    F.sum("click_cnt").alias("cat_click"),
    F.sum("alipay_cnt").alias("cat_sales"),
).withColumn("leaf_weight", F.when(F.col("cat_items") > 0, F.col("cat_sales") / F.col("cat_items")))

parent_conv = item_ops.groupBy("parent_cat").agg(
    F.count("*").alias("p_items"),
    F.sum("alipay_cnt").alias("p_sales"),
).withColumn("parent_weight", F.when(F.col("p_items") > 0, F.col("p_sales") / F.col("p_items")))

# 叶子类目权重（点击不足门槛回退父类目）
cat_conv = cat_conv.join(parent_conv.select("parent_cat", "parent_weight"), "parent_cat", "left")
cat_conv = cat_conv.withColumn(
    "cat_weight",
    F.when(F.col("cat_click") >= MIN_LEAF_CLICK, F.col("leaf_weight")).otherwise(F.col("parent_weight"))
)
print(f"  类目权重已计算（叶子类目 {cat_conv.count():,} 个）")

# ═══════════════════════════════════════════════════════════════
# B1. 卖家全维度绩效
# ═══════════════════════════════════════════════════════════════
print("\n" + "=" * 60)
print("B1: 卖家全维度绩效统计")
print("=" * 60)

item_with_weight = item_ops.join(cat_conv.select("category", "cat_weight"), "category", "left")
item_with_weight = item_with_weight.withColumn(
    "gmv_contrib", F.col("alipay_cnt") * F.coalesce(F.col("cat_weight"), F.lit(0.0))
)

seller_metrics = item_with_weight.groupBy("seller_id").agg(
    F.count("*").alias("item_count"),
    F.sum(F.col("is_sold").cast("long")).alias("sold_item_count"),
    F.sum("click_cnt").alias("click_cnt"),
    F.sum("collect_cnt").alias("collect_cnt"),
    F.sum("cart_cnt").alias("cart_cnt"),
    F.sum("alipay_cnt").alias("sales_cnt"),
    F.sum("gmv_contrib").alias("gmv_proxy"),
    F.countDistinct("parent_cat").alias("parent_cat_count"),
).toPandas()

seller_metrics["click_to_alipay_rate"] = (seller_metrics["sales_cnt"] / seller_metrics["click_cnt"] * 100).round(3)
seller_metrics["click_to_cart_rate"] = (seller_metrics["cart_cnt"] / seller_metrics["click_cnt"] * 100).round(3)
seller_metrics["sold_rate"] = (seller_metrics["sold_item_count"] / seller_metrics["item_count"] * 100).round(2)
seller_metrics = seller_metrics.sort_values("sales_cnt", ascending=False).reset_index(drop=True)
seller_metrics.to_csv(os.path.join(REPORTS_DIR, "seller_metrics.csv"), index=False, encoding="utf-8-sig")
print(f"  卖家绩效明细: {len(seller_metrics):,} 个，已保存 seller_metrics.csv")

# ── GMV 排名 Top100 ──
gmv_rank = seller_metrics.nlargest(100, "gmv_proxy")[
    ["seller_id", "gmv_proxy", "sales_cnt", "click_cnt", "item_count", "sold_item_count", "click_to_alipay_rate", "sold_rate"]
].rename(columns={"seller_id": "卖家ID", "gmv_proxy": "相对GMV", "sales_cnt": "销量", "click_cnt": "点击量",
                  "item_count": "上架商品数", "sold_item_count": "动销商品数", "click_to_alipay_rate": "点击购买转化率%",
                  "sold_rate": "动销率%"})
gmv_rank.to_csv(os.path.join(REPORTS_DIR, "seller_gmv_rank.csv"), index=False, encoding="utf-8-sig")
print(f"  卖家 GMV 排名 Top100 已保存")

# ── 卖家集中度 CR10/CR50 ──
total_sellers = len(seller_metrics)

def cr(series, n):
    # 按该指标自身降序取头部 n 个，避免「用销量排序算流量/GMV 集中度」的口径错误
    return round(series.sort_values(ascending=False).head(n).sum() / series.sum() * 100, 2)

conc = {
    "指标": ["流量(点击)集中度", "销量(成交)集中度", "相对GMV集中度"],
    "CR10%": [
        cr(seller_metrics["click_cnt"], 10),
        cr(seller_metrics["sales_cnt"], 10),
        cr(seller_metrics["gmv_proxy"], 10),
    ],
    "CR50%": [
        cr(seller_metrics["click_cnt"], 50),
        cr(seller_metrics["sales_cnt"], 50),
        cr(seller_metrics["gmv_proxy"], 50),
    ],
}
conc_df = pd.DataFrame(conc)
conc_df["卖家总数"] = total_sellers
conc_df.to_csv(os.path.join(REPORTS_DIR, "seller_concentration.csv"), index=False, encoding="utf-8-sig")
print(f"  卖家集中度: CR10销量 {conc_df['CR10%'][1]}% / CR50销量 {conc_df['CR50%'][1]}%")

# ── 综合绩效得分 + 三梯队 ──
def mm(s):
    return (s - s.min()) / (s.max() - s.min()) if s.max() > s.min() else s * 0

seller_metrics = seller_metrics.copy()
seller_metrics["conv"] = seller_metrics["sales_cnt"] / seller_metrics["click_cnt"].replace(0, np.nan)
seller_metrics["score"] = (
    0.30 * mm(np.log1p(seller_metrics["click_cnt"])) +
    0.30 * mm(np.log1p(seller_metrics["sales_cnt"])) +
    0.20 * mm(np.log1p(seller_metrics["gmv_proxy"])) +
    0.20 * mm(seller_metrics["conv"].fillna(0))
)
seller_metrics["score_rank_pct"] = seller_metrics["score"].rank(ascending=False, pct=True)
seller_metrics["tier"] = np.where(
    seller_metrics["score_rank_pct"] <= 0.05, "头部",
    np.where(seller_metrics["score_rank_pct"] <= 0.25, "腰部", "尾部")
)

tier_summary = seller_metrics.groupby("tier").agg(
    卖家数量=("seller_id", "count"),
    商品数量=("item_count", "sum"),
    动销商品数=("sold_item_count", "sum"),
    点击量=("click_cnt", "sum"),
    销量=("sales_cnt", "sum"),
    相对GMV=("gmv_proxy", "sum"),
).reindex(["头部", "腰部", "尾部"]).reset_index()

tier_summary["卖家占比%"] = (tier_summary["卖家数量"] / total_sellers * 100).round(2)
tier_summary["商品占比%"] = (tier_summary["商品数量"] / tier_summary["商品数量"].sum() * 100).round(2)
tier_summary["流量贡献%"] = (tier_summary["点击量"] / tier_summary["点击量"].sum() * 100).round(2)
tier_summary["销量贡献%"] = (tier_summary["销量"] / tier_summary["销量"].sum() * 100).round(2)
tier_summary["GMV贡献%"] = (tier_summary["相对GMV"] / tier_summary["相对GMV"].sum() * 100).round(2)
tier_summary["梯队动销率%"] = (tier_summary["动销商品数"] / tier_summary["商品数量"] * 100).round(2)
tier_summary.to_csv(os.path.join(REPORTS_DIR, "seller_tiers.csv"), index=False, encoding="utf-8-sig")
print(f"  卖家梯队: 头部 {tier_summary.loc[0,'卖家数量']:,} / 腰部 {tier_summary.loc[1,'卖家数量']:,} / 尾部 {tier_summary.loc[2,'卖家数量']:,}")

# ═══════════════════════════════════════════════════════════════
# B2. 头部卖家运营特征深度分析
# ═══════════════════════════════════════════════════════════════
print("\n" + "=" * 60)
print("B2: 头部卖家运营特征深度分析")
print("=" * 60)

head_sellers = seller_metrics[seller_metrics["tier"] == "头部"]["seller_id"].tolist()
waist_sellers = seller_metrics[seller_metrics["tier"] == "腰部"]["seller_id"].tolist()

# ── 平台优势品类（销量 Top10 父类目）──
top_parent_cats = item_ops.groupBy("parent_cat").agg(F.sum("alipay_cnt").alias("p_sales")).orderBy(F.desc("p_sales")).toPandas()
platform_top_cats = set(top_parent_cats.head(10)["parent_cat"].tolist())
print(f"  平台优势品类（销量Top10父类目）: {sorted(platform_top_cats)}")

# ── 头部卖家品类布局 ──
seller_cat = item_ops.filter(F.col("seller_id").isin(head_sellers)).groupBy("seller_id", "parent_cat").agg(
    F.sum("alipay_cnt").alias("cat_sales"),
    F.sum("click_cnt").alias("cat_click"),
).toPandas()

seller_cat = seller_cat.merge(
    seller_metrics[seller_metrics["tier"] == "头部"][["seller_id", "sales_cnt", "item_count", "click_cnt"]],
    on="seller_id", how="left"
)
seller_cat["cat_sales_share"] = seller_cat["cat_sales"] / seller_cat["sales_cnt"]

layout = seller_cat.groupby("seller_id").agg(
    覆盖父类目数=("parent_cat", "nunique"),
    最大类目销量占比=("cat_sales_share", "max"),
    总销量=("sales_cnt", "first"),
    上架商品数=("item_count", "first"),
).reset_index()

def main_cat(g):
    row = seller_cat[seller_cat["seller_id"] == g].sort_values("cat_sales", ascending=False).iloc[0]
    return row["parent_cat"]
layout["主营类目"] = layout["seller_id"].apply(main_cat)
layout["主营匹配平台优势"] = layout["主营类目"].isin(platform_top_cats)
layout["布局类型"] = np.where(layout["最大类目销量占比"] >= 0.8, "单一品类垂直", "多品类综合")
layout = layout.sort_values("总销量", ascending=False).reset_index(drop=True)

layout_dist = layout["布局类型"].value_counts()
match_rate = layout["主营匹配平台优势"].mean() * 100
print(f"  头部卖家布局: 单一垂直 {layout_dist.get('单一品类垂直',0)} / 多品类综合 {layout_dist.get('多品类综合',0)}")
print(f"  头部卖家主营类目与平台优势品类匹配率: {match_rate:.1f}%")

# ── 头部卖家品类布局 落地（供报告引用）──
head_layout_summary = pd.DataFrame([{
    "头部卖家数": len(layout),
    "单一品类垂直卖家数": int(layout_dist.get("单一品类垂直", 0)),
    "多品类综合卖家数": int(layout_dist.get("多品类综合", 0)),
    "主营类目匹配平台优势品类率%": round(match_rate, 2),
}])
head_layout_summary.to_csv(os.path.join(REPORTS_DIR, "seller_head_layout.csv"), index=False, encoding="utf-8-sig")
layout.to_csv(os.path.join(REPORTS_DIR, "seller_head_layout_detail.csv"), index=False, encoding="utf-8-sig")
print("  头部卖家品类布局已保存 seller_head_layout.csv / seller_head_layout_detail.csv")

# ── 头部 vs 腰部卖家商品结构与效率对比 ──
def seller_tier_profile(seller_ids, label):
    sub = item_ops.filter(F.col("seller_id").isin(seller_ids))
    # 平台销量 P99 阈值（爆款线）
    p99_sales = item_ops.approxQuantile("alipay_cnt", [0.99], 0.001)[0]
    profile = sub.agg(
        F.count("*").alias("商品数"),
        F.sum(F.col("is_sold").cast("long")).alias("动销商品数"),
        F.sum(F.col("alipay_cnt").cast("long")).alias("销量"),
        F.sum(F.col("click_cnt").cast("long")).alias("点击量"),
        F.sum(F.when(F.col("alipay_cnt") >= p99_sales, 1).otherwise(0)).alias("爆款商品数"),
        F.sum(F.when(F.col("alipay_cnt") == 0, 1).otherwise(0)).alias("零成交商品数"),
    ).collect()[0]
    n_item = profile["商品数"]
    n_sold = profile["动销商品数"]
    return {
        "卖家层级": label,
        "商品总数": n_item,
        "动销率%": round(n_sold / n_item * 100, 2),
        "爆款占比%": round(profile["爆款商品数"] / n_item * 100, 2),
        "零成交(无效长尾)占比%": round(profile["零成交商品数"] / n_item * 100, 2),
        "品均点击(流量效率)": round(profile["点击量"] / n_item, 1),
        "品均销量(转化产出)": round(profile["销量"] / n_item, 2),
        "点击购买转化率%": round(profile["销量"] / profile["点击量"] * 100, 3),
    }

profiles = pd.DataFrame([
    seller_tier_profile(head_sellers, "头部卖家"),
    seller_tier_profile(waist_sellers, "腰部卖家"),
])
profiles.to_csv(os.path.join(REPORTS_DIR, "seller_tier_compare.csv"), index=False, encoding="utf-8-sig")
print("  头部 vs 腰部卖家特征对比:")
print(profiles.to_string(index=False))

# ═══════════════════════════════════════════════════════════════
# 可视化
# ═══════════════════════════════════════════════════════════════
print("\n" + "=" * 60)
print("生成图表")
print("=" * 60)

fig, axes = plt.subplots(2, 2, figsize=(20, 16))

# ── 图1: 卖家梯队市场贡献 ──
ax = axes[0, 0]
tiers = ["头部", "腰部", "尾部"]
x = np.arange(3)
w = 0.22
ax.bar(x - w, tier_summary["卖家占比%"], w, label="卖家数占比", color="#4C72B0")
ax.bar(x, tier_summary["商品占比%"], w, label="商品数占比", color="#55A868")
ax.bar(x + w, tier_summary["销量贡献%"], w, label="销量贡献占比", color="#DD8452")
ax.set_xticks(x)
ax.set_xticklabels(tiers, fontsize=12)
ax.set_ylabel("占比 (%)", fontsize=11)
ax.set_title("卖家三梯队市场贡献结构", fontsize=14, fontweight="bold")
ax.legend(fontsize=10)

# ── 图2: 卖家 Lorenz 曲线 ──
ax = axes[0, 1]
for col, label, color in [("click_cnt", "流量", "#4C72B0"), ("sales_cnt", "销量", "#DD8452"), ("gmv_proxy", "相对GMV", "#55A868")]:
    vals = seller_metrics.sort_values(col, ascending=False)[col].cumsum()
    vals = vals / vals.iloc[-1]
    ax.plot(np.linspace(0, 100, len(vals)), vals * 100, color=color, lw=2, label=label)
ax.plot([0, 100], [0, 100], "--", color="gray", lw=1, label="绝对均匀")
ax.set_xlabel("卖家累计占比 (%)", fontsize=11)
ax.set_ylabel("累计贡献占比 (%)", fontsize=11)
ax.set_title("卖家集中度 Lorenz 曲线", fontsize=14, fontweight="bold")
ax.legend(fontsize=10)

# ── 图3: 头部卖家布局类型分布 ──
ax = axes[1, 0]
layout["覆盖父类目数"].value_counts().sort_index().plot(kind="bar", ax=ax, color="#4C72B0", alpha=0.85)
ax.set_xlabel("覆盖父类目数", fontsize=12)
ax.set_ylabel("卖家数量", fontsize=12)
ax.set_title("头部卖家覆盖父类目数分布", fontsize=14, fontweight="bold")

# ── 图4: 头部 vs 腰部卖家效率对比 ──
ax = axes[1, 1]
metrics = ["动销率%", "点击购买转化率%"]
x = np.arange(len(metrics))
w = 0.35
for i, (tier, color) in enumerate([("头部卖家", "#DD8452"), ("腰部卖家", "#4C72B0")]):
    row = profiles[profiles["卖家层级"] == tier].iloc[0]
    vals = [row["动销率%"], row["点击购买转化率%"]]
    ax.bar(x + (i - 0.5) * w, vals, w, label=tier, color=color, alpha=0.9)
ax.set_xticks(x)
ax.set_xticklabels(["动销率(%)", "点击购买转化率(%)"], fontsize=11)
ax.set_ylabel("数值", fontsize=11)
ax.set_title("头部 vs 腰部卖家运营效率对比", fontsize=14, fontweight="bold")
ax.legend(fontsize=11)
for i in range(2):
    for j, tier in enumerate(["头部卖家", "腰部卖家"]):
        row = profiles[profiles["卖家层级"] == tier].iloc[0]
        val = [row["动销率%"], row["点击购买转化率%"]][i]
        ax.text(i + (j - 0.5) * w, val + 0.5, f"{val:.2f}", ha="center", fontsize=9)

plt.tight_layout()
plt.savefig(os.path.join(CHARTS_DIR, "seller_overview.png"), dpi=150, bbox_inches="tight")
plt.close()
print("  ✓ 图表已保存: seller_charts/seller_overview.png")

print("\n" + "=" * 60)
print("模块 b 完成!")
print("=" * 60)

spark.stop()
