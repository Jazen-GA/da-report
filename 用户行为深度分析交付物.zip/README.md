# 用户行为深度分析交付物

Rec-Tmall 数据集用户行为与转化效率分析。观测周期 2013-04-01 ~ 2013-10-01（184 天），
用户规模 9,652,328 人，行为总量 12.59 亿条。

## 怎么查看报告

双击打开 `user_behavior_deep_analysis_report.html`（浏览器）。报告里的图片通过相对路径引用，
**依赖同目录下的 `funnel_charts/`、`temporal_charts/`、`lifecycle_charts/` 三个子目录**，请勿移动或拆散。

## 文件说明

| 文件/目录 | 内容 |
|---|---|
| `user_behavior_deep_analysis_report.html` | 综合分析报告（成品入口） |
| `funnel_charts/`、`temporal_charts/`、`lifecycle_charts/` | 报告引用的图表 |
| `funnel_*.csv` | 漏斗分析数据（漏斗指标、路径、分群） |
| `temporal_*.csv` | 时序分析数据（小时/周/访问习惯/频率转化） |
| `lifecycle_stats.csv`、`lifecycle_transitions.csv` | 生命周期分层统计、流转矩阵 |
| `user_labels_sample.csv` | 用户分层标签表【采样版】 |
| `scripts/` | 分析源码（含 `config.py`） |

## 关于 user_labels_sample.csv

⚠️ 这是**采样版**：从全量 9,652,328 用户中随机采样 100,000 行（seed=42），仅作样例展示。
全量标签表 826MB，未包含在本交付物中。报告内所有统计数字均基于全量数据。

## 复现说明

`scripts/` 下的脚本依赖：

1. 项目数据 `data/cleaned/`（Parquet，约 21GB，含 product / log / review）——**未包含在本交付物中**；
2. Python 环境：PySpark 4.0.4 + pandas + matplotlib + seaborn。

完整运行顺序见项目根目录 `run_analysis.sh`（漏斗 → 时序 → 生命周期 → 报告）。
拿到源码但无数据时，脚本只能作为代码参考，无法直接复现结果。
