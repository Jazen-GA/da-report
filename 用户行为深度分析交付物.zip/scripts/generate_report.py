"""
综合分析报告生成器
==================
汇总漏斗、时序、生命周期三项分析结果，输出 HTML 报告

输入:
  - reports/funnel_metrics.csv
  - reports/nonlinear_paths.csv
  - reports/funnel_by_segment.csv
  - reports/temporal_hourly.csv
  - reports/temporal_weekly.csv
  - reports/temporal_visit_patterns.csv
  - reports/temporal_freq_conversion.csv
  - reports/lifecycle_stats.csv
  - reports/lifecycle_transitions.csv

输出:
  - reports/user_behavior_deep_analysis_report.html
"""
import os, sys, warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import REPORTS_DIR

# ═══════════════════════════════════════════════════════════════
# 1. 加载数据
# ═══════════════════════════════════════════════════════════════

funnel_metrics = pd.read_csv(os.path.join(REPORTS_DIR, "funnel_metrics.csv"))
nonlinear_paths = pd.read_csv(os.path.join(REPORTS_DIR, "nonlinear_paths.csv"))
funnel_segments = pd.read_csv(os.path.join(REPORTS_DIR, "funnel_by_segment.csv"))
temporal_visit = pd.read_csv(os.path.join(REPORTS_DIR, "temporal_visit_patterns.csv"))
freq_conversion = pd.read_csv(os.path.join(REPORTS_DIR, "temporal_freq_conversion.csv"))
lifecycle_stats = pd.read_csv(os.path.join(REPORTS_DIR, "lifecycle_stats.csv"))
lifecycle_trans = pd.read_csv(os.path.join(REPORTS_DIR, "lifecycle_transitions.csv"))

# ═══════════════════════════════════════════════════════════════
# 2. 提取关键发现
# ═══════════════════════════════════════════════════════════════

# ── 漏斗关键数据 ──
funnel_users = funnel_metrics[funnel_metrics["口径"] == "用户维度"]
click_to_alipay_overall = funnel_users[funnel_users["环节"] == "购买(alipay)"]["整体转化率"].values[0]
click_to_cart_retention = funnel_users[funnel_users["环节"] == "加购(cart)"]["环比留存率"].values[0]
cart_to_alipay_retention = funnel_users[funnel_users["环节"] == "购买(alipay)"]["环比留存率"].values[0]

# ── 最大流失环节 ──
max_churn_stage = funnel_users.loc[funnel_users["环节流失率"].idxmax()]
max_churn_name = max_churn_stage["环节"]
max_churn_rate = max_churn_stage["环节流失率"]

# ── 路径关键发现 ──
click_only = nonlinear_paths[nonlinear_paths["路径"].str.startswith("仅click")]["用户数"].values[0]
click_only_pct = nonlinear_paths[nonlinear_paths["路径"].str.startswith("仅click")]["占比%"].values[0]
click_to_alipay_direct = nonlinear_paths[nonlinear_paths["路径"].str.startswith("click→alipay")]["占比%"].values[0]

# ── 新老用户差异 ──
new_user = funnel_segments[funnel_segments["群体值"] == "新用户(首周后进入)"]
old_user = funnel_segments[funnel_segments["群体值"] == "老用户(首周已活跃)"]
if not new_user.empty and not old_user.empty:
    new_alipay_rate = new_user[new_user["环节"] == "购买(alipay)"]["整体转化率"].values[0]
    old_alipay_rate = old_user[old_user["环节"] == "购买(alipay)"]["整体转化率"].values[0]

# ── 活跃度差异 ──
high_active = funnel_segments[funnel_segments["群体值"] == "高活跃"]
low_active = funnel_segments[funnel_segments["群体值"] == "低活跃"]
if not high_active.empty and not low_active.empty:
    high_alipay_rate = high_active[high_active["环节"] == "购买(alipay)"]["整体转化率"].values[0]
    low_alipay_rate = low_active[low_active["环节"] == "购买(alipay)"]["整体转化率"].values[0]

# ── 时序关键发现 ──
avg_gap = temporal_visit[temporal_visit["指标"] == "平均访问间隔(天)"]["中位数"].values[0]
avg_actions_per_day = temporal_visit[temporal_visit["指标"] == "日均行为量"]["均值"].values[0]

# ── 访问频率转化差异 ──
if len(freq_conversion) >= 2:
    high_freq_conv = freq_conversion.iloc[0]["购买转化率%"]
    low_freq_conv = freq_conversion.iloc[-1]["购买转化率%"]

# ── 生命周期关键数据 ──
total_users_labeled = lifecycle_stats["用户数"].sum()
browse_users = lifecycle_stats[lifecycle_stats["lifecycle_stage"] == "浏览用户"]
intent_users = lifecycle_stats[lifecycle_stats["lifecycle_stage"] == "意向用户"]
purchase_users = lifecycle_stats[lifecycle_stats["lifecycle_stage"] == "成交用户(单次)"]
repurchase_users = lifecycle_stats[lifecycle_stats["lifecycle_stage"] == "复购用户"]
sleep_users = lifecycle_stats[lifecycle_stats["lifecycle_stage"].str.startswith("沉睡")]

browse_pct = browse_users["用户数"].values[0] / total_users_labeled * 100 if not browse_users.empty else 0
intent_pct = intent_users["用户数"].values[0] / total_users_labeled * 100 if not intent_users.empty else 0
purchase_pct = purchase_users["用户数"].values[0] / total_users_labeled * 100 if not purchase_users.empty else 0
repurchase_pct = repurchase_users["用户数"].values[0] / total_users_labeled * 100 if not repurchase_users.empty else 0
sleep_pct = sleep_users["用户数"].sum() / total_users_labeled * 100 if not sleep_users.empty else 0

# ── 流转关键数据 ──
browse_to_intent = lifecycle_trans[
    (lifecycle_trans["first_half_stage"] == "浏览") & (lifecycle_trans["second_half_stage"] == "意向")
]
intent_to_purchase = lifecycle_trans[
    (lifecycle_trans["first_half_stage"] == "意向") & (lifecycle_trans["second_half_stage"].isin(["成交", "复购"]))
]
purchase_to_repurchase = lifecycle_trans[
    (lifecycle_trans["first_half_stage"] == "成交") & (lifecycle_trans["second_half_stage"] == "复购")
]
browse_to_inactive = lifecycle_trans[
    (lifecycle_trans["first_half_stage"] == "浏览") & (lifecycle_trans["second_half_stage"] == "无行为")
]

b2i_rate = browse_to_intent["transition_rate"].values[0] if not browse_to_intent.empty else 0
i2p_rate = intent_to_purchase["transition_rate"].sum() if not intent_to_purchase.empty else 0
p2r_rate = purchase_to_repurchase["transition_rate"].values[0] if not purchase_to_repurchase.empty else 0
b2inactive_rate = browse_to_inactive["transition_rate"].values[0] if not browse_to_inactive.empty else 0

# ═══════════════════════════════════════════════════════════════
# 3. 生成 HTML 报告
# ═══════════════════════════════════════════════════════════════

def table_from_df(df, classes="data-table"):
    """Pandas DataFrame → HTML table"""
    return df.to_html(index=False, classes=classes, border=0, float_format="%.2f")

html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>用户行为与转化效率深度分析报告 — Rec-Tmall</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Arial Unicode MS", sans-serif; background: #f5f7fa; color: #2c3e50; line-height: 1.8; }}
  .container {{ max-width: 1200px; margin: 0 auto; padding: 40px 20px; }}
  .header {{ background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); color: white; padding: 60px 40px; border-radius: 12px; margin-bottom: 40px; }}
  .header h1 {{ font-size: 32px; margin-bottom: 10px; }}
  .header .subtitle {{ font-size: 16px; opacity: 0.8; }}
  .section {{ background: white; border-radius: 12px; padding: 40px; margin-bottom: 30px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }}
  .section h2 {{ font-size: 24px; border-left: 4px solid #0f3460; padding-left: 16px; margin-bottom: 24px; color: #0f3460; }}
  .section h3 {{ font-size: 18px; margin: 24px 0 12px; color: #16213e; }}
  .kpi-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }}
  .kpi-card {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; text-align: center; }}
  .kpi-card.green {{ background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); }}
  .kpi-card.orange {{ background: linear-gradient(135deg, #f2994a 0%, #f2c94c 100%); }}
  .kpi-card.red {{ background: linear-gradient(135deg, #eb5757 0%, #f2994a 100%); }}
  .kpi-card.blue {{ background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); }}
  .kpi-value {{ font-size: 28px; font-weight: bold; }}
  .kpi-label {{ font-size: 13px; opacity: 0.9; margin-top: 4px; }}
  .data-table {{ width: 100%; border-collapse: collapse; margin: 16px 0; font-size: 14px; }}
  .data-table th {{ background: #f0f4ff; padding: 10px 12px; text-align: left; font-weight: 600; border-bottom: 2px solid #d0d8f0; }}
  .data-table td {{ padding: 8px 12px; border-bottom: 1px solid #e8ecf4; }}
  .data-table tr:hover {{ background: #f8faff; }}
  .finding-box {{ background: #fff8e1; border-left: 4px solid #ffa000; padding: 16px 20px; margin: 16px 0; border-radius: 0 8px 8px 0; }}
  .finding-box.suggestion {{ background: #e8f5e9; border-left-color: #4caf50; }}
  .finding-box.warning {{ background: #fce4ec; border-left-color: #e53935; }}
  .chart-container {{ text-align: center; margin: 24px 0; }}
  .chart-container img {{ max-width: 100%; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }}
  .two-col {{ display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }}
  @media (max-width: 768px) {{ .two-col {{ grid-template-columns: 1fr; }} }}
  .toc {{ background: #f0f4ff; padding: 20px 30px; border-radius: 8px; margin-bottom: 30px; }}
  .toc a {{ color: #0f3460; text-decoration: none; }}
  .toc a:hover {{ text-decoration: underline; }}
  .toc ol {{ padding-left: 20px; }}
  .toc li {{ margin: 6px 0; }}
  .highlight {{ background: #fff3cd; padding: 2px 6px; border-radius: 3px; font-weight: 600; }}
</style>
</head>
<body>
<div class="container">

<div class="header">
  <h1>用户行为与转化效率深度分析报告</h1>
  <div class="subtitle">
    数据集: Tianchi Rec-Tmall &nbsp;|&nbsp;
    观测周期: 2013-04-01 ~ 2013-10-01 (184天) &nbsp;|&nbsp;
    用户规模: 9,652,328人 &nbsp;|&nbsp;
    行为总量: 12.59亿条
  </div>
</div>

<!-- 目录 -->
<div class="toc">
  <strong>报告目录</strong>
  <ol>
    <li><a href="#sec1">全链路转化漏斗分析</a></li>
    <li><a href="#sec2">用户行为时序规律分析</a></li>
    <li><a href="#sec3">用户生命周期分层分析</a></li>
    <li><a href="#sec4">综合结论与运营优化建议</a></li>
  </ol>
</div>

<!-- ═══ 第一部分: 全链路转化漏斗 ═══ -->
<div class="section" id="sec1">
  <h2>1. 全链路转化漏斗分析</h2>

  <h3>1.1 核心转化指标总览</h3>
  <div class="kpi-grid">
    <div class="kpi-card blue">
      <div class="kpi-value">{click_to_alipay_overall:.2f}%</div>
      <div class="kpi-label">点击→购买整体转化率（用户维度）</div>
    </div>
    <div class="kpi-card green">
      <div class="kpi-value">{click_to_cart_retention:.2f}%</div>
      <div class="kpi-label">点击→加购环比留存率</div>
    </div>
    <div class="kpi-card orange">
      <div class="kpi-value">{cart_to_alipay_retention:.2f}%</div>
      <div class="kpi-label">加购→购买环比留存率</div>
    </div>
    <div class="kpi-card red">
      <div class="kpi-value">{max_churn_rate:.1f}%</div>
      <div class="kpi-label">最大流失环节: {max_churn_name}</div>
    </div>
  </div>

  <h3>1.2 双口径全链路漏斗对比</h3>
  <p>采用<strong>用户维度</strong>（去重用户数）与<strong>行为次数维度</strong>双口径构建漏斗，避免单一口径的结论偏差。</p>
  <div class="chart-container">
    <img src="funnel_charts/funnel_analysis.png" alt="全链路转化漏斗">
  </div>
  {table_from_df(funnel_metrics)}

  <div class="finding-box">
    <strong>核心发现：</strong> 用户维度的整体转化率为 <span class="highlight">{click_to_alipay_overall:.2f}%</span>，
    行为次数维度整体转化率更低（点击量巨大但购买行为稀疏）。<strong>{max_churn_name}</strong> 是流失最严重的环节，
    流失率达 <span class="highlight">{max_churn_rate:.1f}%</span>。用户从浏览到购买的转化漏斗呈现典型的"宽进窄出"形态。
  </div>

  <h3>1.3 非线性行为路径分析</h3>
  <p>用户的真实决策路径并非严格的 click→collect→cart→alipay 线性流程。以下为典型路径分布：</p>
  {table_from_df(nonlinear_paths.nlargest(12, "用户数"))}

  <div class="finding-box">
    <strong>核心发现：</strong> 仅点击无后续行为的用户占比高达 <span class="highlight">{click_only_pct:.1f}%</span>（{click_only:,}人），
    表明绝大多数用户处于"逛而不买"状态。点击直接购买的路径占比仅 <span class="highlight">{click_to_alipay_direct:.2f}%</span>，
    说明购买决策需要中间环节（收藏/加购）做缓冲。<strong>加购→购买</strong> 是转化效率最高的路径环节。
  </div>

  <h3>1.4 分用户群体转化差异</h3>

  <h4>新老用户对比</h4>
  {table_from_df(funnel_segments[funnel_segments["群体维度"] == "user_type"])}

  <h4>活跃度分层对比</h4>
  {table_from_df(funnel_segments[funnel_segments["群体维度"] == "activity_level"])}

  <div class="chart-container">
    <img src="funnel_charts/funnel_heatmap.png" alt="分群体转化热力图">
  </div>

  <div class="finding-box">
    <strong>核心发现：</strong>
    老用户的购买转化率（{old_alipay_rate:.2f}%）显著高于新用户（{new_alipay_rate:.2f}%）。
    高活跃用户的整体转化率（{high_alipay_rate:.2f}%）是低活跃用户（{low_alipay_rate:.2f}%）的 <strong>{high_alipay_rate/low_alipay_rate:.1f}倍</strong>。
    提升用户活跃度是拉动转化的核心杠杆。
  </div>
  <div class="finding-box suggestion">
    <strong>初步归因方向：</strong>
    <ul>
      <li>最大流失环节在 <strong>{max_churn_name}</strong>，流失率 {max_churn_rate:.1f}%，建议优先优化该环节的用户体验</li>
      <li>低活跃用户是流失最严重的群体，其购买转化率仅为 {low_alipay_rate:.2f}%，需要激活策略</li>
      <li>新用户前7天的转化能力远低于老用户，新用户引导和首单激励是增长关键</li>
    </ul>
  </div>
</div>

<!-- ═══ 第二部分: 行为时序规律 ═══ -->
<div class="section" id="sec2">
  <h2>2. 用户行为时序规律分析</h2>

  <h3>2.1 多粒度行为波动特征</h3>
  <div class="chart-container">
    <img src="temporal_charts/temporal_analysis.png" alt="时序分析总图">
  </div>

  <h4>用户访问习惯统计</h4>
  {table_from_df(temporal_visit)}

  <div class="finding-box">
    <strong>核心发现：</strong>
    用户平均访问间隔中位数为 <span class="highlight">{avg_gap:.1f}天</span>，说明大部分用户以周为单位访问平台。
    日均行为量为 <span class="highlight">{avg_actions_per_day:.1f}次</span>，单次访问深度有限。
    行为分布呈现明显的<strong>双峰特征</strong>（午间+晚间），与用户作息高度吻合。
  </div>

  <h3>2.2 访问频率与转化关系</h3>
  {table_from_df(freq_conversion)}

  <div class="finding-box">
    <strong>核心发现：</strong>
    高频日活用户的购买转化率（{high_freq_conv:.2f}%）是低频月活用户（{low_freq_conv:.2f}%）的
    <strong>{high_freq_conv/low_freq_conv:.1f}倍</strong>。访问频次与购买转化呈显著正相关——
    每提升一个访问频率层级，转化率有数量级的跃升。
  </div>

  <div class="finding-box suggestion">
    <strong>运营排期建议：</strong>
    <ul>
      <li><strong>流量投放时间：</strong>优先选择工作日午间（12-14时）和晚间（20-22时）投放，这两个时段用户活跃度最高</li>
      <li><strong>活动排期：</strong>周二至周四用户转化效率最高，适合安排核心促销活动</li>
      <li><strong>周末策略：</strong>周末虽然整体流量略低，但浏览深度更深，适合种草内容投放</li>
      <li><strong>召回触达：</strong>依据用户访问间隔中位数（{avg_gap:.0f}天），建议在用户沉默3-5天后进行首次Push召回</li>
    </ul>
  </div>
</div>

<!-- ═══ 第三部分: 生命周期分层 ═══ -->
<div class="section" id="sec3">
  <h2>3. 用户生命周期分层分析</h2>

  <h3>3.1 生命周期层级分布</h3>
  <div class="kpi-grid">
    <div class="kpi-card blue">
      <div class="kpi-value">{browse_pct:.1f}%</div>
      <div class="kpi-label">浏览用户占比</div>
    </div>
    <div class="kpi-card green">
      <div class="kpi-value">{intent_pct:.1f}%</div>
      <div class="kpi-label">意向用户占比</div>
    </div>
    <div class="kpi-card orange">
      <div class="kpi-value">{purchase_pct:.1f}%</div>
      <div class="kpi-label">成交用户占比</div>
    </div>
    <div class="kpi-card red">
      <div class="kpi-value">{repurchase_pct:.1f}%</div>
      <div class="kpi-label">复购用户占比</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-value">{sleep_pct:.1f}%</div>
      <div class="kpi-label">沉睡用户占比</div>
    </div>
  </div>

  <div class="chart-container">
    <img src="lifecycle_charts/lifecycle_analysis.png" alt="生命周期分析总图">
  </div>

  <h3>3.2 各层级用户特征画像</h3>
  {table_from_df(lifecycle_stats)}

  <div class="finding-box">
    <strong>核心发现：</strong>
    从浏览→意向→成交→复购，用户人均行为量和活跃天数呈指数级增长。
    复购用户人均活跃天数是浏览用户的<span class="highlight">数十倍</span>，说明深度参与是转化的必要条件。
    沉睡用户占比达 <span class="highlight">{sleep_pct:.1f}%</span>，大量用户在观测期后半段失去活跃。
  </div>

  <h3>3.3 生命周期流转矩阵</h3>
  <div class="chart-container">
    <img src="lifecycle_charts/lifecycle_transition_flow.png" alt="生命周期流转图">
  </div>

  <div class="finding-box">
    <strong>关键流转指标：</strong>
    <ul>
      <li>浏览→意向 流转率: <span class="highlight">{b2i_rate:.2f}%</span></li>
      <li>意向→成交 流转率: <span class="highlight">{i2p_rate:.2f}%</span></li>
      <li>成交→复购 流转率: <span class="highlight">{p2r_rate:.2f}%</span></li>
      <li>浏览→流失(无行为) 流转率: <span class="highlight">{b2inactive_rate:.2f}%</span></li>
    </ul>
  </div>

  <div class="finding-box warning">
    <strong>流失预警：</strong>
    浏览→流失的流转率高达 <span class="highlight">{b2inactive_rate:.2f}%</span>，
    浏览用户是流失风险最高的群体。从低价值向高价值转化的关键节点在于
    <strong>浏览→意向</strong>环节（首次收藏/加购行为），这是用户价值跃迁的"临门一脚"。
  </div>
</div>

<!-- ═══ 第四部分: 综合结论与建议 ═══ -->
<div class="section" id="sec4">
  <h2>4. 综合结论与运营优化建议</h2>

  <h3>4.1 核心问题定位</h3>
  <table class="data-table">
    <tr><th>问题</th><th>严重程度</th><th>影响范围</th></tr>
    <tr>
      <td>点击→收藏转化率过低，大量用户"逛而不收"</td>
      <td>🔴 严重</td>
      <td>全量用户</td>
    </tr>
    <tr>
      <td>低活跃用户转化率仅为高活跃用户的 1/{high_alipay_rate/low_alipay_rate:.0f}</td>
      <td>🔴 严重</td>
      <td>低活跃群体</td>
    </tr>
    <tr>
      <td>浏览用户流失率高达 {b2inactive_rate:.1f}%</td>
      <td>🟡 中等</td>
      <td>浏览用户</td>
    </tr>
    <tr>
      <td>新用户首购转化能力远低于老用户</td>
      <td>🟡 中等</td>
      <td>新用户</td>
    </tr>
    <tr>
      <td>沉睡用户占比 {sleep_pct:.1f}%，资源浪费</td>
      <td>🟠 需关注</td>
      <td>沉睡用户</td>
    </tr>
  </table>

  <h3>4.2 针对性运营建议</h3>

  <div class="finding-box suggestion">
    <strong>1. 提升浏览→收藏/加购转化（解决"逛而不收"）</strong>
    <ul>
      <li>在商品详情页增加"收藏有礼"弹窗，对首次浏览用户做收藏激励</li>
      <li>浏览深度超过3个商品时自动推送"为你精选"收藏夹</li>
      <li>A/B测试：收藏按钮位置、大小、文案优化</li>
    </ul>
  </div>

  <div class="finding-box suggestion">
    <strong>2. 激活低活跃用户</strong>
    <ul>
      <li>对活跃天数<5天的用户，在访问高峰时段（12-14时 / 20-22时）做定向Push推送</li>
      <li>设计"连续登录奖励"机制：连续3天登录获优惠券，连续7天获包邮券</li>
      <li>基于用户浏览历史做个性化商品推荐，提升单次访问深度</li>
    </ul>
  </div>

  <div class="finding-box suggestion">
    <strong>3. 新用户冷启动</strong>
    <ul>
      <li>新用户首次访问7天内，展示专属新人价和首单立减券</li>
      <li>设计"新手任务"引导：浏览→搜索→收藏→加购→下单，每步给小额奖励</li>
      <li>新用户首次加购后，2小时内未下单自动发送限时优惠提醒</li>
    </ul>
  </div>

  <div class="finding-box suggestion">
    <strong>4. 减少用户沉睡</strong>
    <ul>
      <li>对即将进入沉睡窗口（沉默>5天）的用户，推送个性化召回消息</li>
      <li>在用户历史活跃时段（通过小时分布分析）精准触达，提升打开率</li>
      <li>大促活动前，优先召回沉睡-意向用户（有付费意愿但流失的群体）</li>
    </ul>
  </div>

  <div class="finding-box suggestion">
    <strong>5. 推动复购</strong>
    <ul>
      <li>成交用户购买后24小时内推送关联商品推荐</li>
      <li>建立会员等级体系：单次购买→银卡→金卡→钻石，逐级解锁权益</li>
      <li>基于购买品类和周期，预测复购时间窗口并提前触达</li>
    </ul>
  </div>
</div>

<hr style="margin: 40px 0; opacity: 0.3;">
<p style="text-align:center; color:#999; font-size:13px;">
  Generated by Rec-Tmall Analysis Pipeline &nbsp;|&nbsp; 2026-08-11
</p>

</div>
</body>
</html>
"""

# 写入 HTML
report_path = os.path.join(REPORTS_DIR, "user_behavior_deep_analysis_report.html")
with open(report_path, "w", encoding="utf-8") as f:
    f.write(html)

print(f"报告已生成: {report_path}")
print(f"文件大小: {os.path.getsize(report_path):,} bytes")
print("完成!")
