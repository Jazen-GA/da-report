"""
用户行为时序规律分析
====================
b1. 多粒度行为波动特征分析（小时 + 周级）
b2. 用户访问习惯量化分析

输出:
  - reports/temporal_hourly.csv           # 小时级行为分布
  - reports/temporal_weekly.csv           # 周级行为分布
  - reports/temporal_visit_patterns.csv   # 访问习惯统计
  - reports/temporal_charts/              # 图表
"""
import os, sys, warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns

plt.rcParams["font.sans-serif"] = ["Arial Unicode MS", "SimHei", "Heiti SC"]
plt.rcParams["axes.unicode_minus"] = False
sns.set_style("whitegrid")

from pyspark.sql import functions as F
from pyspark.sql.types import IntegerType

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import create_spark, DATA_CLEANED, REPORTS_DIR

CHARTS_DIR = os.path.join(REPORTS_DIR, "temporal_charts")
os.makedirs(CHARTS_DIR, exist_ok=True)

spark = create_spark("Temporal-Analysis")

log = spark.read.parquet(os.path.join(DATA_CLEANED, "log"))

# 提取时间字段
log_with_time = log.withColumn("hour", F.hour("vtime").cast(IntegerType())) \
                   .withColumn("dow", F.dayofweek("vtime").cast(IntegerType())) \
                   .withColumn("is_weekend", F.when(F.dayofweek("vtime").isin([1, 7]), "周末").otherwise("工作日"))

# 日期范围
dates = log.agg(F.min("action_date"), F.max("action_date")).collect()[0]
print(f"日期范围: {dates[0]} ~ {dates[1]}")
total_days = log.select("action_date").distinct().count()
print(f"总天数: {total_days}")

# ═══════════════════════════════════════════════════════════════
# 1. 小时级行为分布（工作日 vs 周末）
# ═══════════════════════════════════════════════════════════════

print("\n" + "=" * 60)
print("Step 1: 小时级行为波动分析")
print("=" * 60)

hourly = log_with_time.groupBy("hour", "is_weekend", "action_type").count().toPandas()
hourly["hour"] = hourly["hour"].astype(int)

# 每个时段的总行为量（用于归一化）
hourly_total = hourly.groupby(["hour", "is_weekend"])["count"].sum().reset_index()
hourly_total.rename(columns={"count": "total"}, inplace=True)

hourly = hourly.merge(hourly_total, on=["hour", "is_weekend"])
hourly["pct"] = (hourly["count"] / hourly["total"] * 100).round(2)

hourly.to_csv(os.path.join(REPORTS_DIR, "temporal_hourly.csv"), index=False, encoding="utf-8-sig")

# 高峰识别
for atype in ["click", "collect", "cart", "alipay"]:
    subset = hourly[hourly["action_type"] == atype]
    peak_hour = subset.loc[subset["count"].idxmax()]
    print(f"  {atype} 全天峰值: {int(peak_hour['hour'])}时, {int(peak_hour['count']):,}次")

# 工作日/周末对比
workday = hourly[hourly["is_weekend"] == "工作日"].groupby("action_type")["count"].sum()
weekend = hourly[hourly["is_weekend"] == "周末"].groupby("action_type")["count"].sum()
weekend_ratio = (weekend / workday * 100).round(1)
print("\n  周末行为量占工作日比例:")
for atype in ["click", "collect", "cart", "alipay"]:
    print(f"  {atype}: {weekend_ratio.get(atype, 0):.1f}%")

print("\n  ✓ 小时分布已保存: reports/temporal_hourly.csv")

# ═══════════════════════════════════════════════════════════════
# 2. 周级行为分布
# ═══════════════════════════════════════════════════════════════

print("\n" + "=" * 60)
print("Step 2: 周级行为波动分析")
print("=" * 60)

# Spark dayofweek: 1=Sunday, 2=Monday, ..., 7=Saturday
dow_names = {1: "周日", 2: "周一", 3: "周二", 4: "周三", 5: "周四", 6: "周五", 7: "周六"}

weekly = log_with_time.groupBy("dow", "action_type").count().toPandas()
weekly["dow"] = weekly["dow"].astype(int)
weekly["dow_name"] = weekly["dow"].map(dow_names)

# 每天的行为总量
weekly_total = weekly.groupby("dow")["count"].sum().reset_index()
weekly_total.rename(columns={"count": "total"}, inplace=True)
weekly = weekly.merge(weekly_total, on="dow")
weekly["pct"] = (weekly["count"] / weekly["total"] * 100).round(2)

weekly.to_csv(os.path.join(REPORTS_DIR, "temporal_weekly.csv"), index=False, encoding="utf-8-sig")

# 周日与工作日对比
dow_type = weekly.copy()
dow_type["周类型"] = dow_type["dow"].apply(lambda d: "工作日" if d in [2,3,4,5,6] else "周末")
weekday_vs_weekend = dow_type.groupby(["周类型", "action_type"])["count"].sum().unstack(fill_value=0)

print("\n  工作日 vs 周末行为量对比:")
for atype in ["click", "collect", "cart", "alipay"]:
    wd = weekday_vs_weekend.loc["工作日", atype] if "工作日" in weekday_vs_weekend.index else 0
    we = weekday_vs_weekend.loc["周末", atype] if "周末" in weekday_vs_weekend.index else 0
    ratio = we / wd * 100 if wd > 0 else 0
    print(f"  {atype:10s} | 工作日: {wd:>15,} | 周末: {we:>15,} | 周末/工作日: {ratio:.1f}%")

print("\n  ✓ 周分布已保存: reports/temporal_weekly.csv")

# ═══════════════════════════════════════════════════════════════
# 3. 用户访问习惯量化
# ═══════════════════════════════════════════════════════════════

print("\n" + "=" * 60)
print("Step 3: 用户访问习惯分析")
print("=" * 60)

# 先用 Spark 做用户级聚合，再转 pandas 做统计分析
user_temporal = log_with_time.groupBy("user_id").agg(
    F.min("action_date").alias("first_date"),
    F.max("action_date").alias("last_date"),
    F.countDistinct("action_date").alias("active_days"),
    F.count("action_type").alias("total_actions"),
    F.countDistinct("hour").alias("active_hours_distinct"),
).withColumn("lifespan_days",
    F.datediff(F.col("last_date"), F.col("first_date")) + 1
).withColumn("avg_actions_per_day",
    F.round(F.col("total_actions") / F.col("active_days"), 2)
)

user_temporal.cache()
M = user_temporal.count()
print(f"  分析用户数: {M:,}")

# ── 3a. 访问间隔分析 ──
# 相邻行为的平均间隔 = lifespan_days / (total_actions_visits - 1)
# 这里用 active_days / total_actions 做近似
# 更精确的做法：计算相邻 session 间隔

# 对每个用户计算相邻两天行为的时间间隔
# 简化：avg_gap = lifespan_days / active_days（两次活跃天之间的平均间隔）
user_temporal = user_temporal.withColumn(
    "avg_gap_days",
    F.round(F.col("lifespan_days") / F.when(F.col("active_days") > 1, F.col("active_days") - 1).otherwise(1), 2)
)

# ── 3b. 访问频率分层 ──
# 高频日活: avg_gap_days <= 2（平均每1-2天就访问）
# 中频周活: 2 < avg_gap_days <= 7（平均每周访问一次）
# 低频月活: avg_gap_days > 7（平均超过一周才访问一次）
user_temporal = user_temporal.withColumn(
    "visit_frequency",
    F.when(F.col("avg_gap_days") <= 2, "高频日活(≤2天)")
     .when(F.col("avg_gap_days") <= 7, "中频周活(2-7天)")
     .otherwise("低频月活(>7天)")
)

# 聚合到 pandas
temporal_pd = user_temporal.select(
    "active_days", "total_actions", "avg_actions_per_day",
    "avg_gap_days", "lifespan_days", "visit_frequency"
).toPandas()

# 访问频率分布
freq_dist = temporal_pd["visit_frequency"].value_counts()
print("\n  【访问频率分层】")
for freq, cnt in freq_dist.items():
    print(f"  {freq}: {cnt:,} ({cnt/len(temporal_pd)*100:.1f}%)")

# 统计指标
print(f"\n  【访问习惯统计】")
print(f"  人均活跃天数: {temporal_pd['active_days'].mean():.1f} (中位数: {temporal_pd['active_days'].median():.0f})")
print(f"  人均行为量: {temporal_pd['total_actions'].mean():.1f} (中位数: {temporal_pd['total_actions'].median():.0f})")
print(f"  日均行为量: {temporal_pd['avg_actions_per_day'].mean():.1f}")
print(f"  平均访问间隔(天): {temporal_pd['avg_gap_days'].mean():.2f} (中位数: {temporal_pd['avg_gap_days'].median():.2f})")
print(f"  平均生命周期(天): {temporal_pd['lifespan_days'].mean():.1f}")

# 保存访问习惯统计
visit_patterns = pd.DataFrame({
    "指标": ["人均活跃天数", "人均行为量", "日均行为量", "平均访问间隔(天)", "平均生命周期(天)"],
    "均值": [
        round(temporal_pd["active_days"].mean(), 2),
        round(temporal_pd["total_actions"].mean(), 2),
        round(temporal_pd["avg_actions_per_day"].mean(), 2),
        round(temporal_pd["avg_gap_days"].mean(), 2),
        round(temporal_pd["lifespan_days"].mean(), 2),
    ],
    "中位数": [
        round(temporal_pd["active_days"].median(), 2),
        round(temporal_pd["total_actions"].median(), 2),
        round(temporal_pd["avg_actions_per_day"].median(), 2),
        round(temporal_pd["avg_gap_days"].median(), 2),
        round(temporal_pd["lifespan_days"].median(), 2),
    ]
})
visit_patterns.to_csv(os.path.join(REPORTS_DIR, "temporal_visit_patterns.csv"), index=False, encoding="utf-8-sig")
print("\n  ✓ 访问习惯已保存: reports/temporal_visit_patterns.csv")

# ═══════════════════════════════════════════════════════════════
# 4. 不同访问频率用户的转化效率
# ═══════════════════════════════════════════════════════════════

print("\n" + "=" * 60)
print("Step 4: 访问频率 vs 转化效率")
print("=" * 60)

# 关联用户行为标签
user_behavior = spark.read.parquet(os.path.join(DATA_CLEANED, "log")) \
    .groupBy("user_id").agg(
        F.max(F.when(F.col("action_type") == "alipay", 1).otherwise(0)).alias("has_alipay"),
        F.max(F.when(F.col("action_type") == "cart", 1).otherwise(0)).alias("has_cart"),
        F.max(F.when(F.col("action_type") == "collect", 1).otherwise(0)).alias("has_collect"),
    )

user_with_conv = user_temporal.join(user_behavior, "user_id", "left")
conv_by_freq = user_with_conv.groupBy("visit_frequency").agg(
    F.count("user_id").alias("用户数"),
    F.round(F.sum("has_alipay") / F.count("user_id") * 100, 2).alias("购买转化率%"),
    F.round(F.sum("has_cart") / F.count("user_id") * 100, 2).alias("加购率%"),
    F.round(F.sum("has_collect") / F.count("user_id") * 100, 2).alias("收藏率%"),
    F.round(F.avg("avg_actions_per_day"), 2).alias("日均行为量"),
    F.round(F.avg("active_days"), 1).alias("人均活跃天数"),
).orderBy("visit_frequency").toPandas()

print("\n  【不同访问频率用户的转化效率】")
print(conv_by_freq.to_string(index=False))
conv_by_freq.to_csv(os.path.join(REPORTS_DIR, "temporal_freq_conversion.csv"), index=False, encoding="utf-8-sig")

# ═══════════════════════════════════════════════════════════════
# 5. 可视化
# ═══════════════════════════════════════════════════════════════

print("\n" + "=" * 60)
print("Step 5: 时序可视化")
print("=" * 60)

fig, axes = plt.subplots(2, 3, figsize=(22, 14))

# ── 图1: 小时级行为分布（工作日）──
ax = axes[0, 0]
workday_hourly = hourly[hourly["is_weekend"] == "工作日"]
action_colors = {"click": "#4C72B0", "collect": "#55A868", "cart": "#DD8452", "alipay": "#C44E52"}
for atype in ["click", "collect", "cart", "alipay"]:
    subset = workday_hourly[workday_hourly["action_type"] == atype]
    ax.plot(subset["hour"], subset["count"], "o-", color=action_colors[atype],
            label=atype, linewidth=1.8, markersize=4, alpha=0.85)
ax.set_xlabel("小时", fontsize=11)
ax.set_ylabel("行为次数", fontsize=11)
ax.set_title("工作日 24小时行为分布", fontsize=13, fontweight="bold")
ax.legend(fontsize=9)
ax.set_xticks(range(0, 24, 2))
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x/1e6:.1f}M"))
ax.grid(True, alpha=0.3)

# ── 图2: 小时级行为分布（周末）──
ax = axes[0, 1]
weekend_hourly = hourly[hourly["is_weekend"] == "周末"]
for atype in ["click", "collect", "cart", "alipay"]:
    subset = weekend_hourly[weekend_hourly["action_type"] == atype]
    ax.plot(subset["hour"], subset["count"], "o-", color=action_colors[atype],
            label=atype, linewidth=1.8, markersize=4, alpha=0.85)
ax.set_xlabel("小时", fontsize=11)
ax.set_ylabel("行为次数", fontsize=11)
ax.set_title("周末 24小时行为分布", fontsize=13, fontweight="bold")
ax.legend(fontsize=9)
ax.set_xticks(range(0, 24, 2))
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x/1e6:.1f}M"))
ax.grid(True, alpha=0.3)

# ── 图3: 小时级双峰对比（click 工作日 vs 周末）──
ax = axes[0, 2]
for label, df_subset, ls in [("工作日", workday_hourly, "-"), ("周末", weekend_hourly, "--")]:
    for atype in ["click"]:
        subset = df_subset[df_subset["action_type"] == atype]
        ax.plot(subset["hour"], subset["count"], ls, color=action_colors[atype],
                linewidth=2, alpha=0.85, label=f"{atype}-{label}")
ax.set_xlabel("小时", fontsize=11)
ax.set_ylabel("行为次数", fontsize=11)
ax.set_title("点击行为 工作日 vs 周末 小时分布", fontsize=13, fontweight="bold")
ax.legend(fontsize=9)
ax.set_xticks(range(0, 24, 2))
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x/1e6:.1f}M"))
ax.grid(True, alpha=0.3)

# ── 图4: 周级行为分布 ──
ax = axes[1, 0]
dow_order = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
weekly["dow_name"] = pd.Categorical(weekly["dow_name"], categories=dow_order, ordered=True)
weekly_sorted = weekly.sort_values("dow_name")

for atype in ["click", "collect", "cart", "alipay"]:
    subset = weekly_sorted[weekly_sorted["action_type"] == atype]
    ax.plot(subset["dow_name"], subset["count"], "o-", color=action_colors[atype],
            label=atype, linewidth=2, markersize=6, alpha=0.85)
ax.set_xlabel("")
ax.set_ylabel("行为次数", fontsize=11)
ax.set_title("一周各天行为分布", fontsize=13, fontweight="bold")
ax.legend(fontsize=9)
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x/1e6:.1f}M"))
ax.grid(True, alpha=0.3, axis="y")
ax.tick_params(axis="x", rotation=30)

# ── 图5: 访问间隔分布 ──
ax = axes[1, 1]
gap_data = temporal_pd[temporal_pd["avg_gap_days"] <= 30]["avg_gap_days"]
ax.hist(gap_data, bins=60, color="#4C72B0", edgecolor="white", alpha=0.85)
ax.axvline(gap_data.median(), color="#C44E52", linestyle="--", linewidth=2,
           label=f"中位数: {gap_data.median():.1f}天")
ax.axvline(gap_data.mean(), color="#55A868", linestyle="--", linewidth=2,
           label=f"均值: {gap_data.mean():.1f}天")
ax.set_xlabel("平均访问间隔(天)", fontsize=11)
ax.set_ylabel("用户数", fontsize=11)
ax.set_title("用户平均访问间隔分布(≤30天)", fontsize=13, fontweight="bold")
ax.legend(fontsize=10)
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x/1e6:.1f}M"))

# ── 图6: 访问频率 vs 转化率 ──
ax = axes[1, 2]
freq_order = ["高频日活(≤2天)", "中频周活(2-7天)", "低频月活(>7天)"]
conv_by_freq["visit_frequency"] = pd.Categorical(conv_by_freq["visit_frequency"], categories=freq_order, ordered=True)
conv_plot = conv_by_freq.sort_values("visit_frequency")

x = np.arange(len(conv_plot))
width = 0.25
ax.bar(x - width, conv_plot["收藏率%"], width, label="收藏率%", color="#55A868", alpha=0.85)
ax.bar(x, conv_plot["加购率%"], width, label="加购率%", color="#DD8452", alpha=0.85)
ax.bar(x + width, conv_plot["购买转化率%"], width, label="购买率%", color="#C44E52", alpha=0.85)

for i, row in conv_plot.iterrows():
    ax.text(x[i] - width, row["收藏率%"] + 0.3, f"{row['收藏率%']}%", ha="center", fontsize=8)
    ax.text(x[i], row["加购率%"] + 0.3, f"{row['加购率%']}%", ha="center", fontsize=8)
    ax.text(x[i] + width, row["购买转化率%"] + 0.3, f"{row['购买转化率%']}%", ha="center", fontsize=8)

ax.set_xticks(x)
ax.set_xticklabels(conv_plot["visit_frequency"], fontsize=9)
ax.set_ylabel("转化率 (%)", fontsize=11)
ax.set_title("不同访问频率用户的转化率", fontsize=13, fontweight="bold")
ax.legend(fontsize=9)

plt.tight_layout()
plt.savefig(os.path.join(CHARTS_DIR, "temporal_analysis.png"), dpi=150, bbox_inches="tight")
plt.close()
print(f"  ✓ 图表已保存: reports/temporal_charts/temporal_analysis.png")

print("\n" + "=" * 60)
print("时序分析完成!")
print("=" * 60)

spark.stop()
