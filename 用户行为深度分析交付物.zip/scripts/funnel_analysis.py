"""
全链路转化漏斗分析
===================
a1. 全局全链路漏斗构建（用户维度 + 行为次数维度）
a1. 非线性行为路径统计
a2. 分用户群体转化差异拆解（新老用户 + 活跃层级）

输出:
  - reports/funnel_metrics.csv           # 核心漏斗指标
  - reports/nonlinear_paths.csv          # 非线性路径占比
  - reports/funnel_by_segment.csv        # 分群体漏斗对比
  - reports/funnel_charts/               # 图表
"""
import os, sys, warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns

# 中文字体
plt.rcParams["font.sans-serif"] = ["Arial Unicode MS", "SimHei", "Heiti SC"]
plt.rcParams["axes.unicode_minus"] = False
sns.set_style("whitegrid")

from pyspark.sql import functions as F
from pyspark.sql import Window

# ── 项目路径 ──
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import create_spark, DATA_CLEANED, REPORTS_DIR

CHARTS_DIR = os.path.join(REPORTS_DIR, "funnel_charts")
os.makedirs(CHARTS_DIR, exist_ok=True)

spark = create_spark("Funnel-Analysis")

# ═══════════════════════════════════════════════════════════════
# 1. 用户级行为聚合
# ═══════════════════════════════════════════════════════════════

print("=" * 60)
print("Step 1: 用户级行为聚合")
print("=" * 60)

log = spark.read.parquet(os.path.join(DATA_CLEANED, "log"))

# 每个用户的行为汇总
user_actions = log.groupBy("user_id").agg(
    F.count(F.when(F.col("action_type") == "click", 1)).alias("click_cnt"),
    F.count(F.when(F.col("action_type") == "collect", 1)).alias("collect_cnt"),
    F.count(F.when(F.col("action_type") == "cart", 1)).alias("cart_cnt"),
    F.count(F.when(F.col("action_type") == "alipay", 1)).alias("alipay_cnt"),
    F.min("action_date").alias("first_date"),
    F.max("action_date").alias("last_date"),
    F.count("action_type").alias("total_actions"),
    F.countDistinct("action_date").alias("active_days"),
).withColumn("has_click", F.col("click_cnt") > 0) \
 .withColumn("has_collect", F.col("collect_cnt") > 0) \
 .withColumn("has_cart", F.col("cart_cnt") > 0) \
 .withColumn("has_alipay", F.col("alipay_cnt") > 0)

user_actions.cache()
N = user_actions.count()
print(f"  总用户数: {N:,}")

# ═══════════════════════════════════════════════════════════════
# 2. 全链路漏斗（双口径）
# ═══════════════════════════════════════════════════════════════

print("\n" + "=" * 60)
print("Step 2: 全局全链路转化漏斗")
print("=" * 60)

# ── 口径A: 用户维度（去重用户数）──
funnel_users = pd.DataFrame({
    "环节": ["点击(click)", "收藏(collect)", "加购(cart)", "购买(alipay)"],
    "用户数": [
        user_actions.filter(F.col("has_click")).count(),
        user_actions.filter(F.col("has_collect")).count(),
        user_actions.filter(F.col("has_cart")).count(),
        user_actions.filter(F.col("has_alipay")).count(),
    ]
})
funnel_users["占总量比"] = (funnel_users["用户数"] / N * 100).round(2)
funnel_users["环比留存率"] = (
    funnel_users["用户数"] / funnel_users["用户数"].shift(1) * 100
).round(2)
funnel_users.loc[0, "环比留存率"] = 100.0
funnel_users["环节流失率"] = (100 - funnel_users["环比留存率"]).round(2)
funnel_users["整体转化率"] = (
    funnel_users["用户数"] / funnel_users.loc[0, "用户数"] * 100
).round(2)
funnel_users["口径"] = "用户维度"

# ── 口径B: 行为次数维度 ──
action_totals = log.groupBy("action_type").count().toPandas()
action_map = {"click": 0, "collect": 1, "cart": 2, "alipay": 3}
action_totals["order"] = action_totals["action_type"].map(action_map)
action_totals = action_totals.sort_values("order")

funnel_actions = pd.DataFrame({
    "环节": ["点击(click)", "收藏(collect)", "加购(cart)", "购买(alipay)"],
    "行为次数": [
        int(action_totals[action_totals["action_type"] == "click"]["count"].iloc[0]),
        int(action_totals[action_totals["action_type"] == "collect"]["count"].iloc[0]),
        int(action_totals[action_totals["action_type"] == "cart"]["count"].iloc[0]),
        int(action_totals[action_totals["action_type"] == "alipay"]["count"].iloc[0]),
    ]
})
funnel_actions["环比留存率"] = (
    funnel_actions["行为次数"] / funnel_actions["行为次数"].shift(1) * 100
).round(2)
funnel_actions.loc[0, "环比留存率"] = 100.0
funnel_actions["环节流失率"] = (100 - funnel_actions["环比留存率"]).round(2)
funnel_actions["整体转化率"] = (
    funnel_actions["行为次数"] / funnel_actions.loc[0, "行为次数"] * 100
).round(2)
funnel_actions["口径"] = "行为次数维度"

print("\n  【用户维度漏斗】")
for _, r in funnel_users.iterrows():
    print(f"  {r['环节']:20s} | 用户数: {r['用户数']:>12,} | 环比留存: {r['环比留存率']:>6.2f}% | 整体转化: {r['整体转化率']:>6.2f}%")

print("\n  【行为次数维度漏斗】")
for _, r in funnel_actions.iterrows():
    print(f"  {r['环节']:20s} | 行为次数: {r['行为次数']:>12,} | 环比留存: {r['环比留存率']:>6.2f}% | 整体转化: {r['整体转化率']:>6.2f}%")

# ── 保存漏斗指标 ──
funnel_combined = pd.concat([funnel_users, funnel_actions], ignore_index=True)
funnel_combined.to_csv(os.path.join(REPORTS_DIR, "funnel_metrics.csv"), index=False, encoding="utf-8-sig")
print("\n  ✓ 漏斗指标已保存: reports/funnel_metrics.csv")

# ═══════════════════════════════════════════════════════════════
# 3. 非线性行为路径统计
# ═══════════════════════════════════════════════════════════════

print("\n" + "=" * 60)
print("Step 3: 非线性行为路径分析")
print("=" * 60)

# 定义路径组合（用 PySpark Column 表达式，has_* 是 boolean 类型）
paths_def = [
    ("click→cart (点击直接加购)", F.col("has_click") & F.col("has_cart") & ~F.col("has_collect")),
    ("click→alipay (点击直接购买)", F.col("has_click") & F.col("has_alipay") & ~F.col("has_collect") & ~F.col("has_cart")),
    ("collect→cart (收藏后加购)", F.col("has_collect") & F.col("has_cart")),
    ("collect→alipay (收藏后购买)", F.col("has_collect") & F.col("has_alipay")),
    ("cart→alipay (加购后购买)", F.col("has_cart") & F.col("has_alipay")),
    ("click→collect→cart→alipay (完整路径)", F.col("has_click") & F.col("has_collect") & F.col("has_cart") & F.col("has_alipay")),
    ("仅click无后续", F.col("has_click") & ~F.col("has_collect") & ~F.col("has_cart") & ~F.col("has_alipay")),
    ("仅collect无购买", F.col("has_collect") & ~F.col("has_alipay")),
    ("仅cart无购买", F.col("has_cart") & ~F.col("has_alipay")),
]

path_results = []
for path_name, condition in paths_def:
    cnt = user_actions.filter(condition).count()
    pct = cnt / N * 100
    path_results.append({"路径": path_name, "用户数": cnt, "占比%": round(pct, 2)})

path_df = pd.DataFrame(path_results)
path_df.to_csv(os.path.join(REPORTS_DIR, "nonlinear_paths.csv"), index=False, encoding="utf-8-sig")

print("\n  非线性行为路径分布:")
for _, r in path_df.iterrows():
    print(f"  {r['路径']:45s} | {r['用户数']:>12,} | {r['占比%']:>6.2f}%")
print("\n  ✓ 路径统计已保存: reports/nonlinear_paths.csv")

# ═══════════════════════════════════════════════════════════════
# 4. 分用户群体转化差异
# ═══════════════════════════════════════════════════════════════

print("\n" + "=" * 60)
print("Step 4: 分用户群体转化差异")
print("=" * 60)

# ── 4a. 新老用户定义 ──
# 新用户: 观测周期内首次行为发生在后半段（2013-07-01之后）
# 老用户: 观测周期前半段已有行为的用户
# 更合理的定义: 新用户=first_date在2013-04-01~2013-04-07（第一周首次出现）
#              老用户=其余所有用户

global_start = user_actions.agg(F.min("first_date")).collect()[0][0]
global_end = user_actions.agg(F.max("last_date")).collect()[0][0]
print(f"  全局日期范围: {global_start} ~ {global_end}")

# 第一周出现的用户视为新用户
first_week_end = "2013-04-07"

user_with_type = user_actions.withColumn(
    "user_type",
    F.when(F.col("first_date") <= first_week_end, "老用户(首周已活跃)").otherwise("新用户(首周后进入)")
)

# ── 4b. 活跃度分层 ──
# 高活跃: active_days >= 60（超过1/3天数）
# 中活跃: 15 <= active_days < 60
# 低活跃: active_days < 15
user_with_type = user_with_type.withColumn(
    "activity_level",
    F.when(F.col("active_days") >= 60, "高活跃")
     .when(F.col("active_days") >= 15, "中活跃")
     .otherwise("低活跃")
)

# ── 计算各群体漏斗 ──
def calc_segment_funnel(df, segment_col, segment_val):
    """计算某群体的漏斗指标（用户口径）"""
    seg = df.filter(F.col(segment_col) == segment_val)
    total = seg.count()
    if total == 0:
        return None
    stages = {
        "点击(click)": seg.filter(F.col("has_click")).count(),
        "收藏(collect)": seg.filter(F.col("has_collect")).count(),
        "加购(cart)": seg.filter(F.col("has_cart")).count(),
        "购买(alipay)": seg.filter(F.col("has_alipay")).count(),
    }
    records = []
    prev = None
    for i, (stage, cnt) in enumerate(stages.items()):
        retention = 100.0 if i == 0 else round(cnt / prev * 100, 2) if prev > 0 else 0.0
        churn = round(100 - retention, 2) if i > 0 else 0.0
        overall = round(cnt / stages["点击(click)"] * 100, 2) if stages["点击(click)"] > 0 else 0.0
        records.append({
            "群体维度": segment_col,
            "群体值": segment_val,
            "群体用户数": total,
            "环节": stage,
            "用户数": cnt,
            "环比留存率": retention,
            "环节流失率": churn,
            "整体转化率": overall,
        })
        prev = cnt
    return records

# ── 新老用户漏斗 ──
segments_newold = []
for utype in ["新用户(首周后进入)", "老用户(首周已活跃)"]:
    records = calc_segment_funnel(user_with_type, "user_type", utype)
    if records:
        segments_newold.extend(records)

# ── 活跃度分层漏斗 ──
segments_activity = []
for alevel in ["高活跃", "中活跃", "低活跃"]:
    records = calc_segment_funnel(user_with_type, "activity_level", alevel)
    if records:
        segments_activity.extend(records)

# ── 合并保存 ──
segments_all = pd.DataFrame(segments_newold + segments_activity)
segments_all.to_csv(os.path.join(REPORTS_DIR, "funnel_by_segment.csv"), index=False, encoding="utf-8-sig")

# ── 打印对比表 ──
print("\n  【新老用户漏斗对比】")
seg_newold_df = pd.DataFrame(segments_newold)
for utype in seg_newold_df["群体值"].unique():
    subset = seg_newold_df[seg_newold_df["群体值"] == utype]
    print(f"\n  {utype} (N={subset.iloc[0]['群体用户数']:,}):")
    for _, r in subset.iterrows():
        print(f"    {r['环节']:18s} | {r['用户数']:>12,} | 环比留存: {r['环比留存率']:>6.2f}% | 整体转化: {r['整体转化率']:>6.2f}%")

print("\n  【活跃度分层漏斗对比】")
seg_act_df = pd.DataFrame(segments_activity)
for alevel in seg_act_df["群体值"].unique():
    subset = seg_act_df[seg_act_df["群体值"] == alevel]
    print(f"\n  {alevel} (N={subset.iloc[0]['群体用户数']:,}):")
    for _, r in subset.iterrows():
        print(f"    {r['环节']:18s} | {r['用户数']:>12,} | 环比留存: {r['环比留存率']:>6.2f}% | 整体转化: {r['整体转化率']:>6.2f}%")

print("\n  ✓ 分群体漏斗已保存: reports/funnel_by_segment.csv")

# ═══════════════════════════════════════════════════════════════
# 5. 可视化
# ═══════════════════════════════════════════════════════════════

print("\n" + "=" * 60)
print("Step 5: 漏斗可视化")
print("=" * 60)

fig, axes = plt.subplots(2, 2, figsize=(18, 14))

# ── 图1: 双口径漏斗对比 ──
ax = axes[0, 0]
stages = funnel_users["环节"].tolist()
x = np.arange(len(stages))
width = 0.35

# 归一化以便对比
users_norm = funnel_users["用户数"].values / funnel_users["用户数"].values[0] * 100
actions_norm = funnel_actions["行为次数"].values / funnel_actions["行为次数"].values[0] * 100

bars1 = ax.bar(x - width/2, users_norm, width, label="用户维度(去重用户数)", color="#4C72B0", alpha=0.9)
bars2 = ax.bar(x + width/2, actions_norm, width, label="行为次数维度", color="#55A868", alpha=0.9)

for bar, val, raw in zip(bars1, users_norm, funnel_users["用户数"]):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1, f"{val:.1f}%\n({raw:,.0f})",
            ha="center", va="bottom", fontsize=8)
for bar, val, raw in zip(bars2, actions_norm, funnel_actions["行为次数"]):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1, f"{val:.1f}%\n({raw:,.0f})",
            ha="center", va="bottom", fontsize=8)

ax.set_xticks(x)
ax.set_xticklabels([s.replace("(click)","").replace("(collect)","").replace("(cart)","").replace("(alipay)","").strip() for s in stages], fontsize=11)
ax.set_ylabel("相对占比 (%)", fontsize=11)
ax.set_title("全链路转化漏斗（双口径对比）", fontsize=14, fontweight="bold")
ax.legend(fontsize=9)
ax.set_ylim(0, 115)

# ── 图2: 非线性路径占比 ──
ax = axes[0, 1]
top_paths = path_df.nlargest(8, "用户数")
colors_path = plt.cm.viridis(np.linspace(0.2, 0.9, len(top_paths)))
bars = ax.barh(range(len(top_paths)), top_paths["用户数"].values, color=colors_path)
ax.set_yticks(range(len(top_paths)))
ax.set_yticklabels([p.replace(" (", "\n(") for p in top_paths["路径"].values], fontsize=8)
ax.set_xlabel("用户数", fontsize=11)
ax.set_title("非线性行为路径分布", fontsize=14, fontweight="bold")
for i, (bar, cnt, pct) in enumerate(zip(bars, top_paths["用户数"], top_paths["占比%"])):
    ax.text(bar.get_width() + bar.get_width()*0.01, bar.get_y() + bar.get_height()/2,
            f"{cnt:,} ({pct}%)", va="center", fontsize=8)
ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x/1e6:.1f}M"))

# ── 图3: 新老用户漏斗对比 ──
ax = axes[1, 0]
for utype in seg_newold_df["群体值"].unique():
    subset = seg_newold_df[seg_newold_df["群体值"] == utype]
    overall = subset["整体转化率"].values
    ax.plot(range(len(overall)), overall, "o-", linewidth=2.5, markersize=8, label=utype)
ax.set_xticks(range(len(stages)))
ax.set_xticklabels([s.split("(")[0].strip() for s in stages], fontsize=11)
ax.set_ylabel("整体转化率 (%)", fontsize=11)
ax.set_title("新老用户转化漏斗对比", fontsize=14, fontweight="bold")
ax.legend(fontsize=10)
ax.grid(True, alpha=0.3)

# ── 图4: 活跃度分层漏斗对比 ──
ax = axes[1, 1]
for alevel in seg_act_df["群体值"].unique():
    subset = seg_act_df[seg_act_df["群体值"] == alevel]
    overall = subset["整体转化率"].values
    ax.plot(range(len(overall)), overall, "o-", linewidth=2.5, markersize=8, label=f"{alevel} (N={subset.iloc[0]['群体用户数']:,})")
ax.set_xticks(range(len(stages)))
ax.set_xticklabels([s.split("(")[0].strip() for s in stages], fontsize=11)
ax.set_ylabel("整体转化率 (%)", fontsize=11)
ax.set_title("活跃度分层转化漏斗对比", fontsize=14, fontweight="bold")
ax.legend(fontsize=10)
ax.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig(os.path.join(CHARTS_DIR, "funnel_analysis.png"), dpi=150, bbox_inches="tight")
plt.close()
print(f"  ✓ 图表已保存: reports/funnel_charts/funnel_analysis.png")

# ── 额外图: 各环节流失率热力图 ──
fig, ax = plt.subplots(figsize=(12, 4))
pivot_data = segments_all.pivot_table(
    index="群体值", columns="环节", values="整体转化率"
)
# 按环节顺序排列
stage_order = ["点击(click)", "收藏(collect)", "加购(cart)", "购买(alipay)"]
pivot_data = pivot_data[stage_order]
sns.heatmap(pivot_data, annot=True, fmt=".1f", cmap="RdYlGn", ax=ax,
            cbar_kws={"label": "整体转化率 (%)"}, linewidths=0.5)
ax.set_title("分群体各环节整体转化率热力图 (%)", fontsize=14, fontweight="bold")
ax.set_xlabel("")
plt.tight_layout()
plt.savefig(os.path.join(CHARTS_DIR, "funnel_heatmap.png"), dpi=150, bbox_inches="tight")
plt.close()
print(f"  ✓ 热力图已保存: reports/funnel_charts/funnel_heatmap.png")

print("\n" + "=" * 60)
print("漏斗分析完成!")
print("=" * 60)

spark.stop()
