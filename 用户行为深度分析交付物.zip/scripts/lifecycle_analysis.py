"""
用户生命周期分层分析
====================
c1. 5层生命周期标签映射
c2. 各层级用户特征统计
c3. 生命周期流转路径分析

输出:
  - reports/lifecycle_labels.csv         # 全量用户标签
  - reports/lifecycle_stats.csv          # 各层级统计
  - reports/lifecycle_transitions.csv    # 流转矩阵
  - reports/lifecycle_charts/            # 图表
"""
import os, sys, warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns

plt.rcParams["font.sans-serif"] = ["Arial Unicode MS", "SimHei", "Heiti SC"]
plt.rcParams["axes.unicode_minus"] = False
sns.set_style("whitegrid")

from pyspark.sql import functions as F
from pyspark.sql import Window
from pyspark.sql.types import StringType

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import create_spark, DATA_CLEANED, DATA_SAMPLES, REPORTS_DIR, LOG_FIELDS

CHARTS_DIR = os.path.join(REPORTS_DIR, "lifecycle_charts")
os.makedirs(CHARTS_DIR, exist_ok=True)

spark = create_spark("Lifecycle-Analysis")

# ═══════════════════════════════════════════════════════════════
# 1. 数据加载 + 时间窗口划分
# ═══════════════════════════════════════════════════════════════

print("=" * 60)
print("Step 1: 加载数据并划分时间窗口")
print("=" * 60)

log = spark.read.parquet(os.path.join(DATA_CLEANED, "log"))

# 用户级聚合
user_profile = log.groupBy("user_id").agg(
    F.count(F.when(F.col("action_type") == "click", 1)).alias("click_cnt"),
    F.count(F.when(F.col("action_type") == "collect", 1)).alias("collect_cnt"),
    F.count(F.when(F.col("action_type") == "cart", 1)).alias("cart_cnt"),
    F.count(F.when(F.col("action_type") == "alipay", 1)).alias("alipay_cnt"),
    F.count("action_type").alias("total_actions"),
    F.countDistinct("action_date").alias("active_days"),
    F.countDistinct("item_id").alias("distinct_items"),
    F.min("action_date").alias("first_date"),
    F.max("action_date").alias("last_date"),
    F.min("vtime").alias("first_vtime"),
    F.max("vtime").alias("last_vtime"),
)

# 日期范围
global_start = user_profile.agg(F.min("first_date")).collect()[0][0]
global_end = user_profile.agg(F.max("last_date")).collect()[0][0]
print(f"  数据范围: {global_start} ~ {global_end}")

# 观测周期的1/3分界点（用于判定沉睡用户）
# 总天数约184天，最后1/3 ≈ 最后61天，即2013-08-01之后
one_third_date = "2013-08-01"

# ═══════════════════════════════════════════════════════════════
# 2. 5层生命周期标签
# ═══════════════════════════════════════════════════════════════

print("\n" + "=" * 60)
print("Step 2: 用户生命周期标签映射")
print("=" * 60)

user_profile = user_profile.withColumn(
    "lifecycle_stage",
    F.when((F.col("alipay_cnt") >= 2), "复购用户")
     .when((F.col("alipay_cnt") == 1), "成交用户(单次)")
     .when((F.col("alipay_cnt") == 0) & ((F.col("collect_cnt") > 0) | (F.col("cart_cnt") > 0)), "意向用户")
     .when((F.col("alipay_cnt") == 0) & (F.col("collect_cnt") == 0) & (F.col("cart_cnt") == 0), "浏览用户")
     .otherwise("未分类")
)

# 识别沉睡用户: 在最后1/3窗口无任何行为、但前面有活跃行为的用户
# 确认用户是否在后半段有行为
user_profile = user_profile.withColumn(
    "active_last_third",
    F.when(F.col("last_date") >= one_third_date, 1).otherwise(0)
)

# 修正: 将"最后1/3窗口无行为"的浏览/意向/成交用户标记为对应的沉睡状态
# 注意: 复购用户即使后段无行为也不标为沉睡
user_profile = user_profile.withColumn(
    "lifecycle_stage",
    F.when(
        (F.col("active_last_third") == 0) & (~F.col("lifecycle_stage").isin(["复购用户", "浏览用户"])),
        F.concat(F.lit("沉睡-"), F.col("lifecycle_stage"))
    ).otherwise(F.col("lifecycle_stage"))
)

# 浏览用户也需要细分出沉睡
user_profile = user_profile.withColumn(
    "lifecycle_stage",
    F.when(
        (F.col("active_last_third") == 0) & (F.col("lifecycle_stage") == "浏览用户"),
        "沉睡-浏览用户"
    ).otherwise(F.col("lifecycle_stage"))
)

user_profile.cache()
N = user_profile.count()

stage_counts = user_profile.groupBy("lifecycle_stage").count().orderBy(F.desc("count")).toPandas()
print("\n  【各生命周期层级分布】")
for _, r in stage_counts.iterrows():
    print(f"  {r['lifecycle_stage']:25s} | {r['count']:>12,} | {r['count']/N*100:>6.2f}%")
print(f"  {'总计':25s} | {N:>12,} | 100.00%")

# ═══════════════════════════════════════════════════════════════
# 3. 各层级用户特征画像
# ═══════════════════════════════════════════════════════════════

print("\n" + "=" * 60)
print("Step 3: 各层级用户特征画像")
print("=" * 60)

stage_profile = user_profile.groupBy("lifecycle_stage").agg(
    F.count("user_id").alias("用户数"),
    F.round(F.avg("total_actions"), 1).alias("人均行为量"),
    F.round(F.avg("active_days"), 1).alias("人均活跃天数"),
    F.round(F.avg("distinct_items"), 1).alias("人均品类数"),
    F.round(F.avg("click_cnt"), 1).alias("人均点击"),
    F.round(F.avg("collect_cnt"), 2).alias("人均收藏"),
    F.round(F.avg("cart_cnt"), 2).alias("人均加购"),
    F.round(F.avg("alipay_cnt"), 2).alias("人均购买"),
).orderBy(F.desc("用户数")).toPandas()

print("\n  【各层级用户特征画像】")
print(stage_profile.to_string(index=False))
stage_profile.to_csv(os.path.join(REPORTS_DIR, "lifecycle_stats.csv"), index=False, encoding="utf-8-sig")
print("\n  ✓ 层级特征已保存: reports/lifecycle_stats.csv")

# ═══════════════════════════════════════════════════════════════
# 4. 生命周期流转路径分析
# ═══════════════════════════════════════════════════════════════

print("\n" + "=" * 60)
print("Step 4: 生命周期流转路径分析")
print("=" * 60)

# ── 前半段 vs 后半段的状态对比 ──
# 前半段: 2013-04-01 ~ 2013-07-01
# 后半段: 2013-07-02 ~ 2013-10-01
mid_date = "2013-07-01"

# 计算前半段行为
first_half = log.filter(F.col("action_date") <= mid_date).groupBy("user_id").agg(
    F.max(F.when(F.col("action_type") == "alipay", 1).otherwise(0)).alias("fh_alipay"),
    F.max(F.when(F.col("action_type") == "cart", 1).otherwise(0)).alias("fh_cart"),
    F.max(F.when(F.col("action_type") == "collect", 1).otherwise(0)).alias("fh_collect"),
    F.max(F.when(F.col("action_type") == "click", 1).otherwise(0)).alias("fh_click"),
)

# 计算后半段行为
second_half = log.filter(F.col("action_date") > mid_date).groupBy("user_id").agg(
    F.max(F.when(F.col("action_type") == "alipay", 1).otherwise(0)).alias("sh_alipay"),
    F.max(F.when(F.col("action_type") == "cart", 1).otherwise(0)).alias("sh_cart"),
    F.max(F.when(F.col("action_type") == "collect", 1).otherwise(0)).alias("sh_collect"),
    F.max(F.when(F.col("action_type") == "click", 1).otherwise(0)).alias("sh_click"),
)

# 合并前后半段
transition_data = first_half.join(second_half, "user_id", "full_outer")
transition_data = transition_data.na.fill(0)

# 定义前/后半段状态
def lifecycle_label(alipay, cart, collect, click):
    """根据四行为标记返回生命周期标签"""
    if alipay >= 2:
        return "复购"
    elif alipay == 1:
        return "成交"
    elif cart > 0 or collect > 0:
        return "意向"
    elif click > 0:
        return "浏览"
    else:
        return "无行为"

from pyspark.sql.types import StringType
label_udf = F.udf(lifecycle_label, StringType())

transition_data = transition_data.withColumn("first_half_stage",
    label_udf("fh_alipay", "fh_cart", "fh_collect", "fh_click")) \
    .withColumn("second_half_stage",
    label_udf("sh_alipay", "sh_cart", "sh_collect", "sh_click"))

transition_data.cache()
trans_total = transition_data.count()
print(f"  参与流转分析用户: {trans_total:,}")

# ── 流转矩阵 ──
trans_matrix = transition_data.groupBy("first_half_stage", "second_half_stage").count().toPandas()

# 为每个前段状态计算基数
from_base = trans_matrix.groupby("first_half_stage")["count"].sum().to_dict()

trans_matrix["from_base"] = trans_matrix["first_half_stage"].map(from_base)
trans_matrix["transition_rate"] = (trans_matrix["count"] / trans_matrix["from_base"] * 100).round(2)

# 过滤掉"无行为→无行为"（完全没有行为的人不在分析范围）
trans_matrix = trans_matrix[~((trans_matrix["first_half_stage"] == "无行为") & (trans_matrix["second_half_stage"] == "无行为"))]

# 排序
stage_order = ["无行为", "浏览", "意向", "成交", "复购"]
trans_matrix["first_half_stage"] = pd.Categorical(trans_matrix["first_half_stage"], categories=stage_order, ordered=True)
trans_matrix["second_half_stage"] = pd.Categorical(trans_matrix["second_half_stage"], categories=stage_order, ordered=True)
trans_matrix = trans_matrix.sort_values(["first_half_stage", "second_half_stage"])

# ── 打印流转矩阵 ──
print("\n  【生命周期流转矩阵】")
pivot = trans_matrix.pivot_table(
    index="first_half_stage", columns="second_half_stage",
    values="transition_rate", fill_value=0
)
print(pivot.to_string())

trans_matrix.to_csv(os.path.join(REPORTS_DIR, "lifecycle_transitions.csv"), index=False, encoding="utf-8-sig")
print("\n  ✓ 流转矩阵已保存: reports/lifecycle_transitions.csv")

# ── 关键流转指标 ──
print("\n  【关键流转指标】")
# 浏览→意向
browse_to_intent = trans_matrix[
    (trans_matrix["first_half_stage"] == "浏览") & (trans_matrix["second_half_stage"] == "意向")
]
if not browse_to_intent.empty:
    print(f"  浏览→意向 流转率: {browse_to_intent['transition_rate'].values[0]:.2f}%")

# 意向→成交
intent_to_purchase = trans_matrix[
    (trans_matrix["first_half_stage"] == "意向") & (trans_matrix["second_half_stage"] == "成交")
]
if not intent_to_purchase.empty:
    print(f"  意向→成交 流转率: {intent_to_purchase['transition_rate'].values[0]:.2f}%")

# 成交→复购
purchase_to_repurchase = trans_matrix[
    (trans_matrix["first_half_stage"] == "成交") & (trans_matrix["second_half_stage"] == "复购")
]
if not purchase_to_repurchase.empty:
    print(f"  成交→复购 流转率: {purchase_to_repurchase['transition_rate'].values[0]:.2f}%")

# 浏览→沉睡（后半段无行为）
browse_to_inactive = trans_matrix[
    (trans_matrix["first_half_stage"] == "浏览") & (trans_matrix["second_half_stage"] == "无行为")
]
if not browse_to_inactive.empty:
    print(f"  浏览→流失(无行为) 流转率: {browse_to_inactive['transition_rate'].values[0]:.2f}%")

# ── 合并用户标签表 ──
print("\n" + "=" * 60)
print("Step 5: 生成全量用户标签表")
print("=" * 60)

# 关联活跃度和访问频率标签
user_temporal = spark.read.parquet(os.path.join(DATA_CLEANED, "log")) \
    .groupBy("user_id").agg(
        F.countDistinct("action_date").alias("active_days"),
        F.count("action_type").alias("total_actions"),
        F.min("action_date").alias("first_date"),
        F.max("action_date").alias("last_date"),
    )
user_temporal = user_temporal.withColumn("lifespan_days",
    F.datediff(F.col("last_date"), F.col("first_date")) + 1
).withColumn("avg_gap_days",
    F.round(F.col("lifespan_days") / F.when(F.col("active_days") > 1, F.col("active_days") - 1).otherwise(1), 2)
).withColumn("visit_frequency",
    F.when(F.col("avg_gap_days") <= 2, "高频日活")
     .when(F.col("avg_gap_days") <= 7, "中频周活")
     .otherwise("低频月活")
).withColumn("activity_level",
    F.when(F.col("active_days") >= 60, "高活跃")
     .when(F.col("active_days") >= 15, "中活跃")
     .otherwise("低活跃")
)

# 合并生命周期标签
user_labels = user_profile.select("user_id", "lifecycle_stage", "click_cnt", "collect_cnt",
    "cart_cnt", "alipay_cnt", "active_days", "distinct_items", "first_date", "last_date") \
    .join(user_temporal.select("user_id", "visit_frequency", "activity_level", "avg_gap_days"), "user_id", "left")

# 保存全量标签表
user_labels.write.mode("overwrite").parquet(os.path.join(DATA_SAMPLES, "user_labels"))
# 同时也输出为CSV（用Pandas分批写入避免内存溢出）
label_pd = user_labels.coalesce(10).toPandas()
label_pd.to_csv(os.path.join(REPORTS_DIR, "user_labels.csv"), index=False, encoding="utf-8-sig")
print(f"  ✓ 用户标签表已保存: reports/user_labels.csv ({len(label_pd):,} 行)")
print(f"  ✓ 用户标签表(Parquet): data/samples/user_labels/")

# ═══════════════════════════════════════════════════════════════
# 6. 可视化
# ═══════════════════════════════════════════════════════════════

print("\n" + "=" * 60)
print("Step 6: 生命周期可视化")
print("=" * 60)

fig, axes = plt.subplots(2, 2, figsize=(20, 16))

# ── 图1: 生命周期层级分布（饼图）──
ax = axes[0, 0]
# 归并沉睡到主类
stage_counts["大类"] = stage_counts["lifecycle_stage"].str.replace("沉睡-", "沉睡-")
main_stages = stage_counts.groupby("大类")["count"].sum().sort_values(ascending=False)
colors_lifecycle = {
    "浏览用户": "#4C72B0", "意向用户": "#55A868", "成交用户(单次)": "#DD8452",
    "复购用户": "#C44E52", "沉睡-浏览用户": "#9B9B9B", "沉睡-意向用户": "#B0B0B0",
    "沉睡-成交用户(单次)": "#C5C5C5"
}
stage_colors = [colors_lifecycle.get(s, "#D3D3D3") for s in main_stages.index]

wedges, texts, autotexts = ax.pie(
    main_stages.values, labels=None, autopct="%1.1f%%",
    colors=stage_colors, startangle=90, pctdistance=0.85,
    textprops={"fontsize": 10}
)
ax.legend(wedges, [f"{s}\n({c:,})" for s, c in zip(main_stages.index, main_stages.values)],
          title="生命周期层级", loc="center left", bbox_to_anchor=(1, 0, 0.5, 1), fontsize=9)
ax.set_title(f"用户生命周期层级分布 (N={N:,})", fontsize=14, fontweight="bold")

# ── 图2: 各层级行为特征雷达图前用柱状图 ──
ax = axes[0, 1]
profile_plot = stage_profile[~stage_profile["lifecycle_stage"].str.startswith("沉睡")].copy()
metrics = ["人均行为量", "人均活跃天数", "人均品类数"]
x = np.arange(len(profile_plot))
width = 0.25
# 归一化便于对比
for m in metrics:
    profile_plot[f"{m}_norm"] = profile_plot[m] / profile_plot[m].max()

for i, (m, c) in enumerate(zip(metrics, ["#4C72B0", "#55A868", "#DD8452"])):
    ax.bar(x + i * width, profile_plot[f"{m}_norm"], width, label=m, color=c, alpha=0.85)
ax.set_xticks(x + width)
ax.set_xticklabels(profile_plot["lifecycle_stage"], fontsize=9)
ax.set_ylabel("归一化值", fontsize=11)
ax.set_title("各层级用户行为特征对比（归一化）", fontsize=14, fontweight="bold")
ax.legend(fontsize=9)

# ── 图3: 流转热力图 ──
ax = axes[1, 0]
pivot_for_heatmap = trans_matrix.pivot_table(
    index="first_half_stage", columns="second_half_stage",
    values="transition_rate", fill_value=0
)
# 确保行列都有所有阶段
for s in stage_order:
    if s not in pivot_for_heatmap.index:
        pivot_for_heatmap.loc[s] = 0
    if s not in pivot_for_heatmap.columns:
        pivot_for_heatmap[s] = 0
pivot_for_heatmap = pivot_for_heatmap.reindex(index=stage_order, columns=stage_order, fill_value=0)

sns.heatmap(pivot_for_heatmap, annot=True, fmt=".1f", cmap="YlOrRd",
            ax=ax, linewidths=0.5, cbar_kws={"label": "流转率 (%)"}, vmin=0)
ax.set_xlabel("后半段状态 (2013-07~2013-10)", fontsize=11)
ax.set_ylabel("前半段状态 (2013-04~2013-07)", fontsize=11)
ax.set_title("用户生命周期流转矩阵 (%)", fontsize=14, fontweight="bold")

# ── 图4: 流转漏斗（从浏览到复购的关键路径）──
ax = axes[1, 1]
# 提取关键流转链路
transition_flow = {
    "浏览→意向": trans_matrix[(trans_matrix["first_half_stage"] == "浏览") & (trans_matrix["second_half_stage"] == "意向")]["count"].sum(),
    "意向→成交": trans_matrix[(trans_matrix["first_half_stage"] == "意向") & (trans_matrix["second_half_stage"].isin(["成交", "复购"]))]["count"].sum(),
    "成交→复购": trans_matrix[(trans_matrix["first_half_stage"] == "成交") & (trans_matrix["second_half_stage"] == "复购")]["count"].sum(),
}

flow_stages = ["浏览→意向", "意向→成交", "成交→复购"]
flow_values = [transition_flow[s] for s in flow_stages]
flow_rates = [
    round(flow_values[0] / from_base.get("浏览", 1) * 100, 2),
    round(flow_values[1] / from_base.get("意向", 1) * 100, 2),
    round(flow_values[2] / from_base.get("成交", 1) * 100, 2),
]

ax.bar(range(len(flow_stages)), flow_values, color=["#4C72B0", "#55A868", "#DD8452"], alpha=0.85)
for i, (v, r) in enumerate(zip(flow_values, flow_rates)):
    ax.text(i, v + v * 0.02, f"{v:,}\n({r}%)", ha="center", fontsize=10, fontweight="bold")
ax.set_xticks(range(len(flow_stages)))
ax.set_xticklabels(flow_stages, fontsize=11)
ax.set_ylabel("流转用户数", fontsize=11)
ax.set_title("关键流转路径用户量", fontsize=14, fontweight="bold")
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x/1e6:.2f}M"))
ax.grid(True, alpha=0.3, axis="y")

plt.tight_layout()
plt.savefig(os.path.join(CHARTS_DIR, "lifecycle_analysis.png"), dpi=150, bbox_inches="tight")
plt.close()
print(f"  ✓ 图表已保存: reports/lifecycle_charts/lifecycle_analysis.png")

# ── 额外图: 桑基图风格流转 ──
fig, ax = plt.subplots(figsize=(14, 8))

# 用左右两侧柱状图模拟桑基效果
left_stages = stage_order
right_stages = stage_order

left_totals = trans_matrix.groupby("first_half_stage")["count"].sum().reindex(left_stages, fill_value=0)
right_totals = trans_matrix.groupby("second_half_stage")["count"].sum().reindex(right_stages, fill_value=0)

x_left, y_left_vals = [], []
for i, (s, v) in enumerate(left_totals.items()):
    if v > 0:
        y_pos = left_totals[:i].sum() + v / 2
        x_left.append(0)
        y_left_vals.append((y_pos, s, v))

x_positions = [0, 1]
y_max = max(left_totals.sum(), right_totals.sum())

# 左侧柱状
bottom = 0
for s in left_stages:
    v = left_totals[s]
    if v > 0:
        ax.bar(0, v, bottom=bottom, width=0.15, color=colors_lifecycle.get(s, "#D3D3D3"),
               edgecolor="white", linewidth=0.5, alpha=0.85)
        ax.text(-0.05, bottom + v / 2, f"{s}\n{v:,}", ha="right", va="center", fontsize=8)
        bottom += v

# 右侧柱状
bottom = 0
for s in right_stages:
    v = right_totals[s]
    if v > 0:
        ax.bar(1, v, bottom=bottom, width=0.15, color=colors_lifecycle.get(s, "#D3D3D3"),
               edgecolor="white", linewidth=0.5, alpha=0.85)
        ax.text(1.05, bottom + v / 2, f"{s}\n{v:,}", ha="left", va="center", fontsize=8)
        bottom += v

# 流转连线（仅画流转率>5%的）
max_flow = trans_matrix["count"].max()
for _, row in trans_matrix.iterrows():
    if row["first_half_stage"] == row["second_half_stage"]:
        continue
    if row["transition_rate"] < 5:
        continue
    left_idx = left_stages.index(row["first_half_stage"])
    right_idx = right_stages.index(row["second_half_stage"])
    left_bottom = left_totals[:left_idx].sum()
    right_bottom = right_totals[:right_idx].sum()
    left_mid = left_bottom + left_totals[row["first_half_stage"]] / 2
    right_mid = right_bottom + right_totals[row["second_half_stage"]] / 2

    alpha_val = min(row["count"] / max_flow * 0.8, 0.8)
    ax.plot([0.15, 0.85], [left_mid, right_mid], "-", color="gray", alpha=alpha_val,
            linewidth=row["count"] / max_flow * 4)

ax.set_xlim(-0.5, 1.5)
ax.set_ylim(0, y_max)
ax.set_xticks([0, 1])
ax.set_xticklabels(["前半段\n(2013-04~2013-07)", "后半段\n(2013-07~2013-10)"], fontsize=12)
ax.set_ylabel("用户数", fontsize=11)
ax.set_title("用户生命周期流转图 (仅显示>5%流转)", fontsize=14, fontweight="bold")
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x/1e6:.2f}M"))

plt.tight_layout()
plt.savefig(os.path.join(CHARTS_DIR, "lifecycle_transition_flow.png"), dpi=150, bbox_inches="tight")
plt.close()
print(f"  ✓ 流转图已保存: reports/lifecycle_charts/lifecycle_transition_flow.png")

print("\n" + "=" * 60)
print("生命周期分析完成!")
print("=" * 60)

spark.stop()
