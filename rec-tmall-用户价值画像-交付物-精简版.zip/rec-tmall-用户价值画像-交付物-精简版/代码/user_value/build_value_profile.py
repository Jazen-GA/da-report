# -*- coding: utf-8 -*-
"""
用户价值分层模型 — a.3 各层级用户价值画像
=========================================
分价值层级统计: 规模占比 / 行为特征(行为量、行为类型占比) / 购买时段 /
品类偏好 / 品牌偏好 / 评论口碑特征, 并输出高价值用户核心识别特征总结。

输出:
  reports/user_value/tier_profile.csv        各层核心画像(规模/行为/口碑)
  reports/user_value/tier_top_cats.csv       各层 Top 类目偏好
  reports/user_value/tier_top_brands.csv     各层 Top 品牌偏好
  reports/user_value/tier_period.csv         各层购买时段分布
  reports/user_value/high_value_profile.md   高价值用户核心识别特征总结
  reports/user_value/charts/tier_profile.png 画像对比图
"""
import os
import sys
import warnings

warnings.filterwarnings("ignore")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pyspark.sql import functions as F
from pyspark.sql import Window

plt.rcParams["font.sans-serif"] = ["Arial Unicode MS", "SimHei", "Heiti SC"]
plt.rcParams["axes.unicode_minus"] = False

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import create_spark  # noqa: E402
import user_value.config as cfg  # noqa: E402

os.makedirs(cfg.UV_REPORTS, exist_ok=True)
os.makedirs(cfg.UV_CHARTS, exist_ok=True)

spark = create_spark("UserValue-Profile")

TIER_ORDER = ["高价值", "中价值", "低价值"]

print("=" * 60)
print("a.3 各层级用户价值画像")
print("=" * 60)

scored = spark.read.parquet(cfg.SCORE_PATH)

# ── 1. 关联行为计数 ──
print("\n[1/4] 关联用户行为计数")
ul = spark.read.parquet(cfg.USER_LABELS_PATH).select(
    "user_id", "active_days", "click_cnt", "collect_cnt", "cart_cnt",
)
base = scored.join(ul, "user_id", "left")

# ── 2. 各层核心画像(规模/行为类型占比/复购/活跃) ──
print("\n[2/4] 各层核心画像统计")
total_actions = F.col("click_cnt") + F.col("collect_cnt") + F.col("cart_cnt") + F.col("alipay_cnt")
tier_profile = base.groupBy("value_tier").agg(
    F.count("user_id").alias("用户数"),
    F.round(F.avg(F.when(F.col("alipay_cnt") >= 2, 1).otherwise(0)) * 100, 2).alias("复购率%"),
    F.round(F.avg("alipay_cnt"), 2).alias("人均购买次数"),
    F.round(F.avg("monetary"), 2).alias("人均消费力"),
    F.round(F.avg("active_days"), 1).alias("人均活跃天数"),
    F.round(F.avg(total_actions), 1).alias("人均行为量"),
    F.round(F.avg("click_cnt") / F.avg(total_actions) * 100, 1).alias("点击占比%"),
    F.round(F.avg("collect_cnt") / F.avg(total_actions) * 100, 2).alias("收藏占比%"),
    F.round(F.avg("cart_cnt") / F.avg(total_actions) * 100, 2).alias("加购占比%"),
    F.round(F.avg("alipay_cnt") / F.avg(total_actions) * 100, 2).alias("购买占比%"),
).toPandas()

n_total = tier_profile["用户数"].sum()
tier_profile["占比%"] = (tier_profile["用户数"] / n_total * 100).round(2)
tier_profile["value_tier"] = pd.Categorical(tier_profile["value_tier"], categories=TIER_ORDER, ordered=True)
tier_profile = tier_profile.sort_values("value_tier").reset_index(drop=True)
tier_profile.to_csv(os.path.join(cfg.UV_REPORTS, "tier_profile.csv"), index=False, encoding="utf-8-sig")
print("\n  【各层核心画像】")
print(tier_profile.to_string(index=False))

# ── 3. 品类/品牌偏好 + 购买时段(基于购买明细) ──
print("\n[3/4] 各层品类/品牌偏好与购买时段")

alipay = (
    spark.read.parquet(cfg.CLEANED_LOG_PATH)
    .filter(F.col("action_type") == cfg.BUY_ACTION)
    .select("user_id", "item_id", "vtime")
)
item_map = spark.read.parquet(cfg.ITEM_OPS_PATH).select(
    "item_id",
    F.col("parent_cat").cast("string").alias("parent_cat"),
    "brand_id",
)

buy_detail = (
    alipay.join(F.broadcast(item_map), "item_id", "left")
    .join(scored.select("user_id", "value_tier"), "user_id", "left")
    .filter(F.col("value_tier").isNotNull())
)

# 3.1 Top 类目(按购买次数)
top_cats = (
    buy_detail.groupBy("value_tier", "parent_cat")
    .agg(F.count("item_id").alias("购买次数"))
    .withColumn("rk", F.row_number().over(Window.partitionBy("value_tier").orderBy(F.desc("购买次数"))))
    .filter(F.col("rk") <= 10)
    .orderBy("value_tier", "rk")
    .toPandas()
)
top_cats.to_csv(os.path.join(cfg.UV_REPORTS, "tier_top_cats.csv"), index=False, encoding="utf-8-sig")
print("\n  【各层 Top5 类目】")
for t in TIER_ORDER:
    sub = top_cats[top_cats["value_tier"] == t].head(5)
    cats = " / ".join(f"{r['parent_cat']}({r['购买次数']:,})" for _, r in sub.iterrows())
    print(f"  {t}: {cats}")

# 3.2 Top 品牌(按购买次数, 未标注归并为'未标注')
top_brands = (
    buy_detail.withColumn("brand_label", F.coalesce(F.col("brand_id"), F.lit("未标注")))
    .groupBy("value_tier", "brand_label")
    .agg(F.count("item_id").alias("购买次数"))
    .withColumn("rk", F.row_number().over(Window.partitionBy("value_tier").orderBy(F.desc("购买次数"))))
    .filter(F.col("rk") <= 10)
    .orderBy("value_tier", "rk")
    .toPandas()
)
top_brands.to_csv(os.path.join(cfg.UV_REPORTS, "tier_top_brands.csv"), index=False, encoding="utf-8-sig")
print("\n  【各层 Top5 品牌】")
for t in TIER_ORDER:
    sub = top_brands[top_brands["value_tier"] == t].head(5)
    bs = " / ".join(f"{r['brand_label']}({r['购买次数']:,})" for _, r in sub.iterrows())
    print(f"  {t}: {bs}")

# 3.3 购买时段(日间/夜间 × 工作日/周末)
period = (
    buy_detail.withColumn("hour", F.hour(F.to_timestamp("vtime", "yyyy-MM-dd HH:mm:ss")))
    .withColumn("dow", F.dayofweek(F.to_date(F.to_timestamp("vtime", "yyyy-MM-dd HH:mm:ss"))))
    .withColumn("is_day", F.when((F.col("hour") >= cfg.DAY_START) & (F.col("hour") < cfg.DAY_END), 1).otherwise(0))
    .withColumn("is_weekday", F.when(F.col("dow").between(2, 6), 1).otherwise(0))
    .groupBy("value_tier")
    .agg(
        F.round(F.avg("is_day") * 100, 1).alias("日间购买占比%"),
        F.round((1 - F.avg("is_day")) * 100, 1).alias("夜间购买占比%"),
        F.round(F.avg("is_weekday") * 100, 1).alias("工作日购买占比%"),
        F.round((1 - F.avg("is_weekday")) * 100, 1).alias("周末购买占比%"),
    ).toPandas()
)
period["value_tier"] = pd.Categorical(period["value_tier"], categories=TIER_ORDER, ordered=True)
period = period.sort_values("value_tier").reset_index(drop=True)
period.to_csv(os.path.join(cfg.UV_REPORTS, "tier_period.csv"), index=False, encoding="utf-8-sig")
print("\n  【各层购买时段】")
print(period.to_string(index=False))

# ── 4. 评论口碑特征 + 高价值识别特征总结 ──
print("\n[4/4] 评论口碑特征与画像总结")

review = spark.read.parquet(cfg.REVIEW_PRED_PATH).select("user_id", "label", "prob")
tier_review = (
    review.join(scored.select("user_id", "value_tier"), "user_id", "inner")
    .groupBy("value_tier")
    .agg(
        F.count("label").alias("评论条数"),
        F.countDistinct("user_id").alias("评论用户数"),
        F.round(F.avg("label") * 100, 2).alias("正面评论占比%"),
        F.round(F.avg("prob"), 3).alias("平均正面概率"),
    ).toPandas()
)
tier_review["value_tier"] = pd.Categorical(tier_review["value_tier"], categories=TIER_ORDER, ordered=True)
tier_review = tier_review.sort_values("value_tier").reset_index(drop=True)
tier_review.to_csv(os.path.join(cfg.UV_REPORTS, "tier_review.csv"), index=False, encoding="utf-8-sig")
print("\n  【各层评论口碑】")
print(tier_review.to_string(index=False))

# 高价值用户核心识别特征(对比低价值)
hv = tier_profile[tier_profile["value_tier"] == "高价值"].iloc[0]
lv = tier_profile[tier_profile["value_tier"] == "低价值"].iloc[0]
hv_top_cats = top_cats[top_cats["value_tier"] == "高价值"]["parent_cat"].head(3).tolist()
hv_top_brands = top_brands[top_brands["value_tier"] == "高价值"]["brand_label"].head(3).tolist()

summary_md = f"""# 高价值用户核心识别特征

## 识别特征(高价值 vs 低价值)
| 指标 | 高价值 | 低价值 | 倍数 |
|---|---|---|---|
| 复购率 | {hv['复购率%']}% | {lv['复购率%']}% | {hv['复购率%'] / max(lv['复购率%'], 0.1):.1f}x |
| 人均购买次数 | {hv['人均购买次数']} | {lv['人均购买次数']} | {hv['人均购买次数'] / max(lv['人均购买次数'], 0.1):.1f}x |
| 人均活跃天数 | {hv['人均活跃天数']} | {lv['人均活跃天数']} | {hv['人均活跃天数'] / max(lv['人均活跃天数'], 0.1):.1f}x |
| 人均行为量 | {hv['人均行为量']} | {lv['人均行为量']} | {hv['人均行为量'] / max(lv['人均行为量'], 0.1):.1f}x |

## 行为规律
- 高价值用户 **复购率近 {hv['复购率%']}%**, 是平台的复购主力, 人均购买 {hv['人均购买次数']} 次。
- 高活跃: 人均活跃 {hv['人均活跃天数']} 天, 购买路径中「加购→购买」占比更高, 决策更成熟。
- 偏好类目(购买次数 Top3): {', '.join(map(str, hv_top_cats))}。
- 偏好品牌(购买次数 Top3): {', '.join(map(str, hv_top_brands))}。

## 运营启示
- 高价值用户是核心资产(约 {tier_profile[tier_profile['value_tier']=='高价值']['占比%'].iloc[0]}%), 优先保障其偏好的头部品牌与类目供给。
- 针对「潜力成长型」用户(近期活跃、频次中低)做复购激励, 促使其向核心高价值迁移。
- 针对「流失风险型」用户(约 {tier_profile[tier_profile['value_tier']=='低价值']['占比%'].iloc[0]}% 低价值层中多数)做召回。
"""
with open(os.path.join(cfg.UV_REPORTS, "high_value_profile.md"), "w", encoding="utf-8") as f:
    f.write(summary_md)
print("\n  ✓ 高价值画像总结已保存: reports/user_value/high_value_profile.md")

# ── 画像对比图(各指标独立子图, 避免不同量纲共轴) ──
fig, axes = plt.subplots(2, 3, figsize=(16, 9))
colors = {"高价值": "#C44E52", "中价值": "#DD8452", "低价值": "#4C72B0"}

# 4 个核心指标各画一张(每层对比), 独立 y 轴
for i, m in enumerate(["复购率%", "人均活跃天数", "人均购买次数", "人均消费力"]):
    ax = axes[i // 3][i % 3]
    for t in TIER_ORDER:
        v = tier_profile[tier_profile["value_tier"] == t][m].iloc[0]
        ax.bar(t, v, color=colors[t], alpha=0.85)
    ax.set_title(m, fontsize=13, fontweight="bold")
    ax.set_ylabel("数值", fontsize=10)
    ax.tick_params(labelsize=10)

# 高价值用户行为类型占比
ax = axes[1][1]
share = tier_profile[tier_profile["value_tier"] == "高价值"][["点击占比%", "收藏占比%", "加购占比%", "购买占比%"]].iloc[0].values
labels = ["点击", "收藏", "加购", "购买"]
ax.bar(labels, share, color=["#4C72B0", "#55A868", "#DD8452", "#C44E52"], alpha=0.85)
for i, v in enumerate(share):
    ax.text(i, v + 0.3, f"{v:.2f}%", ha="center", fontsize=10)
ax.set_ylabel("行为占比 %", fontsize=10)
ax.set_title("高价值用户行为类型占比", fontsize=13, fontweight="bold")

axes[1][2].axis("off")  # 末格留空

plt.tight_layout()
plt.savefig(os.path.join(cfg.UV_CHARTS, "tier_profile.png"), dpi=150, bbox_inches="tight")
plt.close()
print("  ✓ 画像对比图已保存: reports/user_value/charts/tier_profile.png")

spark.stop()
print("\n各层级画像完成!")
