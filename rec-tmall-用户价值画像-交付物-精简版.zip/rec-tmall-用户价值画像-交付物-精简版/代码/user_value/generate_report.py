# -*- coding: utf-8 -*-
"""
用户价值画像 — 综合 HTML 报告生成
==================================
读取 reports/user_value/ 下各 CSV, 拼装为综合 HTML 报告。
"""
import os
import sys
import warnings

warnings.filterwarnings("ignore")

import pandas as pd
import re

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import user_value.config as cfg  # noqa: E402

os.makedirs(cfg.UV_REPORTS, exist_ok=True)


def _tbl(df, caption=None):
    """DataFrame → HTML 表格"""
    cap = f"<caption>{caption}</caption>" if caption else ""
    return f"<table>{cap}{df.to_html(index=False, border=0, classes='tbl')}</table>"


def _read(name):
    p = os.path.join(cfg.UV_REPORTS, name)
    return pd.read_csv(p) if os.path.exists(p) else None


def _md_to_html(md):
    """极简 markdown → HTML(仅处理 # / ## / |表格| / - 列表, 适配自产 high_value_profile.md)"""
    html = []
    lines = md.splitlines()
    i = 0
    while i < len(lines):
        s = lines[i].rstrip()
        if s.startswith("|"):
            tbl = []
            while i < len(lines) and lines[i].rstrip().startswith("|"):
                tbl.append(lines[i].rstrip())
                i += 1
            out = ["<table>"]
            header_done = False
            for row in tbl:
                cells = [c.strip() for c in row.strip().strip("|").split("|")]
                if all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                    continue  # 分隔行
                tag = "th" if not header_done else "td"
                header_done = True
                out.append("<tr>" + "".join(f"<{tag}>{c}</{tag}>" for c in cells) + "</tr>")
            out.append("</table>")
            html.append("".join(out))
        elif s.startswith("# "):
            html.append(f"<h3>{s[2:].strip()}</h3>")
            i += 1
        elif s.startswith("## "):
            html.append(f"<h4>{s[3:].strip()}</h4>")
            i += 1
        elif s.startswith("- "):
            items = ["<li>" + s[2:].strip() + "</li>"]
            i += 1
            while i < len(lines) and lines[i].rstrip().startswith("- "):
                items.append("<li>" + lines[i].rstrip()[2:].strip() + "</li>")
                i += 1
            html.append("<ul>" + "".join(items) + "</ul>")
        else:
            i += 1
    return re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", "".join(html))


CSS = """
<style>
body { font-family: -apple-system, 'PingFang SC', 'Microsoft YaHei', sans-serif; margin: 40px; color: #222; }
h1 { border-bottom: 3px solid #C44E52; padding-bottom: 10px; }
h2 { margin-top: 40px; color: #C44E52; border-left: 5px solid #C44E52; padding-left: 10px; }
h3 { color: #555; }
table.tbl { border-collapse: collapse; width: 100%; margin: 10px 0 20px; font-size: 13px; }
table.tbl th, table.tbl td { border: 1px solid #ddd; padding: 6px 10px; text-align: left; }
table.tbl th { background: #f5f5f5; font-weight: 600; }
caption { caption-side: top; font-weight: bold; text-align: left; margin-bottom: 5px; color: #333; }
img { max-width: 100%; border: 1px solid #eee; margin: 10px 0; }
.meta { color: #777; font-size: 13px; }
</style>
"""

sections = []
sections.append("<h1>用户价值画像与流失复购预测 — 分析报告</h1>")
sections.append('<p class="meta">Rec-Tmall 天猫数据集 | 全量 965 万用户 / 419 万成交用户 | 观测窗口 2013-04 ~ 2013-10</p>')

# ── a. 价值分层 ──
sections.append("<h2>a. 用户价值分层模型</h2>")

rfm = _read("rfm_distribution.csv")
if rfm is not None:
    sections.append("<h3>RFM 三指标分布</h3>")
    sections.append(_tbl(rfm, "成交用户 R/F/M 分布校验(recency_days 为近度天数, monetary 为相对消费力)"))

tier = _read("value_tier_stats.csv")
if tier is not None:
    sections.append("<h3>价值主层规模与核心指标</h3>")
    sections.append(_tbl(tier, "高/中/低三层(加权总分 0.2R+0.4F+0.4M 分位数切分)"))

sub = _read("value_subtier_stats.csv")
if sub is not None:
    sections.append("<h3>价值子层细分</h3>")
    sections.append(_tbl(sub, "核心高价值 / 潜力成长型 / 低活维持型 / 流失风险型 / 常规中坚"))

val = _read("tier_validation.csv")
if val is not None:
    sections.append("<h3>分层有效性校验</h3>")
    sections.append(_tbl(val, "各层复购率(卡方)/活跃度/行为量/消费力(ANOVA) 组间差异"))

prof = _read("tier_profile.csv")
if prof is not None:
    sections.append("<h3>各层用户画像</h3>")
    sections.append(_tbl(prof, "规模/行为特征/行为类型占比"))
    sections.append('<img src="charts/tier_profile.png" alt="分层画像对比">')

for name, cap in [("tier_top_cats.csv", "各层 Top 类目偏好(购买次数)"),
                  ("tier_top_brands.csv", "各层 Top 品牌偏好(购买次数) — 注: 品牌标注覆盖率有限, '未标注'占比最高, 品牌类标签可用性受限"),
                  ("tier_period.csv", "各层购买时段分布 — 注: 时段在价值层间差异微弱(日间均约85%), 该标签用于触达时机优化而非价值分层区分"),
                  ("tier_review.csv", "各层评论口碑特征")]:
    df = _read(name)
    if df is not None:
        sections.append(_tbl(df, cap))

hv_md = os.path.join(cfg.UV_REPORTS, "high_value_profile.md")
if os.path.exists(hv_md):
    with open(hv_md, encoding="utf-8") as f:
        sections.append("<h3>高价值用户核心识别特征</h3>" + _md_to_html(f.read()))

# ── b. 标签体系 ──
sections.append("<h2>b. 用户兴趣标签体系</h2>")

cov = _read("tag_coverage.csv")
if cov is not None:
    sections.append("<h3>核心标签覆盖率</h3>")
    sections.append(_tbl(cov, "高价值/高活跃用户核心标签覆盖率校验"))

# 标签字典
rows = "".join(
    f"<tr><td>{t}</td><td>{d}</td><td>{m}</td><td>{c}</td><td>{l}</td><td>{s}</td></tr>"
    for t, d, m, c, l, s in cfg.TAG_DICT
)
sections.append("<h3>标签字典</h3>")
sections.append(
    "<table><caption>四大维度标签体系(字段/含义/口径/分级/场景)</caption>"
    "<tr><th>字段</th><th>维度</th><th>业务含义</th><th>计算口径</th><th>强度分级</th><th>适用场景</th></tr>"
    + rows + "</table>"
)

sections.append(
    '<h3>标签宽表</h3>'
    '<p>以 <code>user_id</code> 为主键的全量用户画像标签宽表已落盘: '
    '<code>data/samples/user_value/tag_wide/</code>, 支持按标签组合筛选与人群圈选。'
    '示例见 <code>reports/user_value/tag_wide_sample.csv</code>。</p>'
)

html = f"<!DOCTYPE html><html><head><meta charset='utf-8'><title>用户价值画像与流失复购预测</title>{CSS}</head><body>" \
       + "\n".join(sections) + "</body></html>"

out = os.path.join(cfg.UV_REPORTS, "user_value_report.html")
with open(out, "w", encoding="utf-8") as f:
    f.write(html)
print(f"✓ 综合报告已生成: {out}")
