# -*- coding: utf-8 -*-
"""
用户兴趣标签体系 — b.3 结构化标签宽表 + 覆盖率校验 + 标签字典
============================================================
以 user_id 为主键, 整合基础行为 / 价值层级 / 兴趣偏好 / 消费习惯 / 口碑行为
全维度标签, 生成全量用户画像标签宽表, 并校验核心标签覆盖率。

输出:
  data/samples/user_value/tag_wide/        全量用户标签宽表(parquet)
  reports/user_value/tag_wide_sample.csv   宽表示例(前 500 行)
  reports/user_value/tag_coverage.csv      核心标签覆盖率
  reports/user_value/tag_dictionary.md     标签体系说明文档
"""
import os
import sys
import warnings

warnings.filterwarnings("ignore")

import pandas as pd
from pyspark.sql import functions as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import create_spark  # noqa: E402
import user_value.config as cfg  # noqa: E402

os.makedirs(cfg.UV_REPORTS, exist_ok=True)
os.makedirs(cfg.WIDE_PATH, exist_ok=True)

spark = create_spark("UserValue-Wide")

print("=" * 60)
print("b.3 结构化标签宽表 + 覆盖率 + 标签字典")
print("=" * 60)

# ── 1. 读取各维标签 ──
print("\n[1/3] 读取各维标签并整合")

# 基础行为(全量用户基座)
base = spark.read.parquet(cfg.USER_LABELS_PATH).select(
    "user_id", "lifecycle_stage", "activity_level", "visit_frequency",
    "active_days", "click_cnt", "collect_cnt", "cart_cnt", "alipay_cnt",
)

# 价值分层(仅成交用户)
value = spark.read.parquet(cfg.SCORE_PATH).select(
    "user_id", "value_tier", "value_subtier",
    "r_score", "f_score", "m_score", "total_score",
    "monetary", "recency_days", "distinct_item_cnt", "distinct_cat_cnt",
)

# 兴趣/习惯/口碑标签
cat_pref = spark.read.parquet(os.path.join(cfg.TAGS_PATH, "cat_pref"))
leaf_pref = spark.read.parquet(os.path.join(cfg.TAGS_PATH, "leaf_pref"))
brand_pref = spark.read.parquet(os.path.join(cfg.TAGS_PATH, "brand_pref"))
period = spark.read.parquet(os.path.join(cfg.TAGS_PATH, "period"))
decision = spark.read.parquet(os.path.join(cfg.TAGS_PATH, "decision"))
tendency = spark.read.parquet(os.path.join(cfg.TAGS_PATH, "tendency"))
review = spark.read.parquet(os.path.join(cfg.TAGS_PATH, "review"))

wide = (
    base
    .join(value, "user_id", "left")
    .join(cat_pref, "user_id", "left")
    .join(leaf_pref, "user_id", "left")
    .join(brand_pref, "user_id", "left")
    .join(period, "user_id", "left")
    .join(decision, "user_id", "left")
    .join(tendency, "user_id", "left")
    .join(review, "user_id", "left")
)

wide.write.mode("overwrite").parquet(cfg.WIDE_PATH)
n = wide.count()
print(f"  ✓ 标签宽表已落盘: {cfg.WIDE_PATH} ({n:,} 用户, {len(wide.columns)} 列)")

# 示例导出(前 500 行)
sample = wide.limit(500).toPandas()
sample.to_csv(os.path.join(cfg.UV_REPORTS, "tag_wide_sample.csv"), index=False, encoding="utf-8-sig")
print(f"  ✓ 宽表示例已保存: tag_wide_sample.csv ({len(sample)} 行)")

# ── 2. 覆盖率校验 ──
print("\n[2/3] 核心标签覆盖率校验")

core_tags = [
    "value_tier", "cat_strength", "brand_loyalty", "day_night",
    "decision_style", "consume_tendency", "review_activity",
]

rows = []
for tag in core_tags:
    total_cov = wide.filter(F.col(tag).isNotNull()).count() / n * 100
    hv_cov = wide.filter((F.col("value_tier") == "高价值") & (F.col(tag).isNotNull())).count() \
        / max(wide.filter(F.col("value_tier") == "高价值").count(), 1) * 100
    act_cov = wide.filter((F.col("activity_level") == "高活跃") & (F.col(tag).isNotNull())).count() \
        / max(wide.filter(F.col("activity_level") == "高活跃").count(), 1) * 100
    rows.append({"标签": tag, "全量覆盖率%": round(total_cov, 2),
                 "高价值覆盖率%": round(hv_cov, 2), "高活跃覆盖率%": round(act_cov, 2)})

cov = pd.DataFrame(rows)
cov.to_csv(os.path.join(cfg.UV_REPORTS, "tag_coverage.csv"), index=False, encoding="utf-8-sig")
print(cov.to_string(index=False))
print("  ✓ 覆盖率校验已保存: tag_coverage.csv")

# ── 3. 标签字典文档 ──
print("\n[3/3] 标签体系说明文档")

lines = ["# 用户兴趣标签体系说明文档", ""]
lines.append(f"- 主键: `user_id`(覆盖全量 {n:,} 用户)")
lines.append("- 宽表位置: `data/samples/user_value/tag_wide/`")
lines.append("- 标签维度: 基础行为属性 / 兴趣偏好 / 消费习惯 / 价值层级 / 口碑行为")
lines.append("")
lines.append("| 标签字段 | 维度 | 业务含义 | 计算口径 | 强度分级 | 适用场景 |")
lines.append("|---|---|---|---|---|---|")
for tag, dim, meaning, calc, levels, scene in cfg.TAG_DICT:
    lines.append(f"| `{tag}` | {dim} | {meaning} | {calc} | {levels} | {scene} |")
lines.append("")
lines.append("## 覆盖率说明")
lines.append("")
lines.append("价值分层、购物决策、消费倾向仅对成交用户有意义(非成交用户无购买记录);")
lines.append("口碑行为仅覆盖有评论的用户。全量覆盖率低于 100% 属口径正常, 重点关注高价值/高活跃用户覆盖率。")
lines.append("品牌类标签(brand_loyalty/consume_tendency)全量覆盖率约 40%: 大量商品 brand_id 未标注, 仅对交互/购买过标注品牌商品的用户有意义。")

with open(os.path.join(cfg.UV_REPORTS, "tag_dictionary.md"), "w", encoding="utf-8") as f:
    f.write("\n".join(lines))
print("  ✓ 标签字典已保存: tag_dictionary.md")

spark.stop()
print("\n标签宽表整合完成!")
