# -*- coding: utf-8 -*-
"""
用户兴趣标签体系 — b.1+b.2 多维标签挖掘
========================================
基于全量行为日志 + 商品属性 + 评论情感, 挖掘六类用户标签:
  1. 类目偏好(一级 + 叶子)   : 四行为加权得分 → Top3 + 强/中/弱
  2. 品牌偏好               : 高频交互品牌 / 核心购买品牌 / 品牌忠诚度
  3. 活跃时段               : 日间/夜间 × 工作日/周末
  4. 购物决策               : 冲动型 / 决策型(先收藏加购后购买)
  5. 消费倾向               : 高端 / 中端 / 大众(购买品牌梯队加权)
  6. 口碑行为               : 评论活跃度 + 宽容型/挑剔型

输出(每个标签一张 user_id 主键 parquet, 供 b.3 整合):
  data/samples/user_value/tags/{cat_pref,leaf_pref,brand_pref,period,decision,tendency,review}
"""
import os
import sys
import warnings

warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from pyspark.sql import functions as F
from pyspark.sql import Window

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import create_spark  # noqa: E402
import user_value.config as cfg  # noqa: E402

os.makedirs(cfg.TAGS_PATH, exist_ok=True)
os.makedirs(cfg.UV_REPORTS, exist_ok=True)

spark = create_spark("UserValue-Tags")

print("=" * 60)
print("b.1+b.2 多维标签挖掘")
print("=" * 60)

# ── 行为权重映射(click/collect/cart/alipay → 1/2/3/4) ──
_w = cfg.ACTION_WEIGHTS
weight_expr = F.when(F.col("action_type") == "alipay", _w["alipay"]) \
    .when(F.col("action_type") == "cart", _w["cart"]) \
    .when(F.col("action_type") == "collect", _w["collect"]) \
    .otherwise(_w["click"])

# 商品维度映射(item → 类目/品牌)
item_map = spark.read.parquet(cfg.ITEM_OPS_PATH).select(
    "item_id",
    F.col("parent_cat").cast("string").alias("parent_cat"),
    F.col("leaf_cat").cast("string").alias("leaf_cat"),
    F.col("brand_id").cast("string").alias("brand_id"),
)

# ── 读取1: 类目/品牌/消费倾向共用(join item_map) ──
# 注意: 全量日志不可 persist(12.6 亿行会 OOM), 每个聚合独立流式读取
print("读取行为日志并关联商品维度(join item_map)...")
log_cb = (
    spark.read.parquet(cfg.CLEANED_LOG_PATH)
    .select("user_id", "item_id", "action_type")
    .join(F.broadcast(item_map), "item_id", "left")
    .withColumn("weight", weight_expr)
)

# ── 读取2: 时段/决策共用(不需 item_map, 需 vtime) ──
log_ts = (
    spark.read.parquet(cfg.CLEANED_LOG_PATH)
    .select("user_id", "item_id", "action_type", "vtime")
    .withColumn("ts", F.to_timestamp("vtime", "yyyy-MM-dd HH:mm:ss"))
    .withColumn("hour", F.hour("ts"))
    .withColumn("dow", F.dayofweek("ts"))
    .select("user_id", "item_id", "action_type", "ts", "hour", "dow")
)

# ═══════════════════════════════════════════════════════════════
# 1. 类目偏好(一级 + 叶子)
# ═══════════════════════════════════════════════════════════════
print("\n[1/6] 类目偏好标签(一级 + 叶子)")


def _cat_pref(col, prefix, out_name):
    """用户×类目加权得分 → Top3 + 强度"""
    score = (
        log_cb.filter(F.col(col).isNotNull())
        .groupBy("user_id", col)
        .agg(F.sum("weight").alias("score"))
    )
    total = score.groupBy("user_id").agg(F.sum("score").alias("total"))
    ranked = score.withColumn(
        "rk", F.row_number().over(Window.partitionBy("user_id").orderBy(F.desc("score")))
    ).filter(F.col("rk") <= 3)
    top1 = ranked.filter(F.col("rk") == 1).join(total, "user_id") \
        .withColumn("share", F.col("score") / F.col("total")) \
        .withColumn(
            f"{prefix}_strength",
            F.when(F.col("share") >= 0.5, "强").when(F.col("share") >= 0.3, "中").otherwise("弱"),
        ).select("user_id", f"{prefix}_strength")
    wide = ranked.groupBy("user_id").pivot("rk", [1, 2, 3]).agg(F.first(col))
    wide = wide.toDF(*["user_id", f"{prefix}_top1", f"{prefix}_top2", f"{prefix}_top3"])
    out = wide.join(top1, "user_id", "left")
    out.write.mode("overwrite").parquet(os.path.join(cfg.TAGS_PATH, out_name))
    print(f"  ✓ {out_name}: {out.count():,} 用户")


_cat_pref("parent_cat", "cat", "cat_pref")
_cat_pref("leaf_cat", "leaf", "leaf_pref")

# ═══════════════════════════════════════════════════════════════
# 2. 品牌偏好
# ═══════════════════════════════════════════════════════════════
print("\n[2/6] 品牌偏好标签")

# 高频交互品牌(全行为加权)
interact = (
    log_cb.filter(F.col("brand_id").isNotNull())
    .groupBy("user_id", "brand_id")
    .agg(F.sum("weight").alias("interact_score"))
)
top_interact = interact.withColumn(
    "rk", F.row_number().over(Window.partitionBy("user_id").orderBy(F.desc("interact_score")))
).filter(F.col("rk") == 1).select("user_id", F.col("brand_id").alias("top_interact_brand"))

# 核心购买品牌(只看 alipay) + 忠诚度
buy = (
    log_cb.filter((F.col("action_type") == "alipay") & (F.col("brand_id").isNotNull()))
    .groupBy("user_id", "brand_id")
    .agg(F.count("item_id").alias("buy_cnt"))
)
buy_total = buy.groupBy("user_id").agg(F.sum("buy_cnt").alias("buy_total"))
core_buy = buy.withColumn(
    "rk", F.row_number().over(Window.partitionBy("user_id").orderBy(F.desc("buy_cnt")))
).filter(F.col("rk") == 1).join(buy_total, "user_id") \
    .withColumn("brand_loyalty", F.round(F.col("buy_cnt") / F.col("buy_total"), 3)) \
    .select("user_id", F.col("brand_id").alias("core_buy_brand"), "brand_loyalty")

brand_pref = top_interact.join(core_buy, "user_id", "left")
brand_pref.write.mode("overwrite").parquet(os.path.join(cfg.TAGS_PATH, "brand_pref"))
print(f"  ✓ brand_pref: {brand_pref.count():,} 用户")

# ═══════════════════════════════════════════════════════════════
# 3. 活跃时段
# ═══════════════════════════════════════════════════════════════
print("\n[3/6] 活跃时段标签")
period = log_ts.groupBy("user_id").agg(
    F.avg(F.when((F.col("hour") >= cfg.DAY_START) & (F.col("hour") < cfg.DAY_END), 1).otherwise(0)).alias("day_share"),
    F.avg(F.when(F.col("dow").between(2, 6), 1).otherwise(0)).alias("weekday_share"),
)
period = period.withColumn(
    "day_night",
    F.when(F.col("day_share") >= cfg.PERIOD_DOMINANCE, "日间活跃")
    .when(F.col("day_share") <= 1 - cfg.PERIOD_DOMINANCE, "夜间活跃")
    .otherwise("全天候"),
).withColumn(
    "week_period",
    F.when(F.col("weekday_share") >= cfg.PERIOD_DOMINANCE, "工作日活跃")
    .when(F.col("weekday_share") <= 1 - cfg.PERIOD_DOMINANCE, "周末活跃")
    .otherwise("均衡"),
).select("user_id", "day_night", "week_period")
period.write.mode("overwrite").parquet(os.path.join(cfg.TAGS_PATH, "period"))
print(f"  ✓ period: {period.count():,} 用户")

# ═══════════════════════════════════════════════════════════════
# 4. 购物决策(冲动型 / 决策型)
# ═══════════════════════════════════════════════════════════════
print("\n[4/6] 购物决策标签")
# 每个 user×item: 最早收藏/加购时间 vs 最早购买时间
cc = log_ts.filter(F.col("action_type").isin("collect", "cart")) \
    .groupBy("user_id", "item_id").agg(F.min("ts").alias("first_cc_ts"))
buy_ts = log_ts.filter(F.col("action_type") == "alipay") \
    .groupBy("user_id", "item_id").agg(F.min("ts").alias("first_buy_ts"))
decision = buy_ts.join(cc, ["user_id", "item_id"], "left") \
    .withColumn("is_decision", F.when(F.col("first_cc_ts") < F.col("first_buy_ts"), 1).otherwise(0))
decision_style = decision.groupBy("user_id").agg(
    F.sum("is_decision").alias("decision_items"),
    F.count("item_id").alias("buy_items"),
).withColumn(
    "decision_style",
    F.when(F.col("decision_items") / F.col("buy_items") >= 0.5, "决策型").otherwise("冲动型"),
).select("user_id", "decision_style")
decision_style.write.mode("overwrite").parquet(os.path.join(cfg.TAGS_PATH, "decision"))
print(f"  ✓ decision: {decision_style.count():,} 用户")

# ═══════════════════════════════════════════════════════════════
# 5. 消费倾向(高端/中端/大众)
# ═══════════════════════════════════════════════════════════════
print("\n[5/6] 消费倾向标签")
bm = pd.read_csv(cfg.BRAND_METRICS_CSV)
bm = bm[bm["brand_label"] != "未标注"].copy()
bm["conv"] = bm["sales_cnt"] / bm["click_cnt"].replace(0, np.nan)


def _mm(s):
    return (s - s.min()) / (s.max() - s.min()) if s.max() > s.min() else s * 0


bm["score"] = (0.35 * _mm(np.log1p(bm["click_cnt"])) + 0.35 * _mm(np.log1p(bm["sales_cnt"]))
               + 0.30 * _mm(bm["conv"].fillna(0)))
bm["rank_pct"] = bm["score"].rank(ascending=False, pct=True)
bm["tier"] = np.where(bm["rank_pct"] <= 0.05, "头部", np.where(bm["rank_pct"] <= 0.25, "腰部", "尾部"))
bm["tier_w"] = bm["tier"].map(cfg.BRAND_TIER_WEIGHTS)
tier_df = spark.createDataFrame(bm[["brand_label", "tier_w"]].astype({"tier_w": "int64"}))

tendency = (
    log_cb.filter((F.col("action_type") == "alipay") & (F.col("brand_id").isNotNull()))
    .join(F.broadcast(tier_df), F.col("brand_id") == F.col("brand_label"), "left")
    .withColumn("tier_w", F.coalesce("tier_w", F.lit(cfg.BRAND_TIER_DEFAULT)))
    .groupBy("user_id")
    .agg(F.avg("tier_w").alias("tier_score"))
    .withColumn(
        "consume_tendency",
        F.when(F.col("tier_score") >= 2.3, "高端")
        .when(F.col("tier_score") >= 1.5, "中端")
        .otherwise("大众"),
    ).select("user_id", "consume_tendency")
)
tendency.write.mode("overwrite").parquet(os.path.join(cfg.TAGS_PATH, "tendency"))
print(f"  ✓ tendency: {tendency.count():,} 用户")

# ═══════════════════════════════════════════════════════════════
# 6. 口碑行为(评论活跃度 + 评论倾向)
# ═══════════════════════════════════════════════════════════════
print("\n[6/6] 口碑行为标签")
review = spark.read.parquet(cfg.REVIEW_PRED_PATH).select("user_id", "label", "prob")
review_tag = review.groupBy("user_id").agg(
    F.count("label").alias("review_cnt"),
    F.round(F.avg("label"), 3).alias("pos_share"),
).withColumn(
    "review_activity",
    F.when(F.col("review_cnt") >= 6, "高").when(F.col("review_cnt") >= 2, "中")
    .when(F.col("review_cnt") == 1, "低").otherwise("无"),
).withColumn(
    "review_tendency",
    F.when(F.col("pos_share") >= 0.7, "宽容型").when(F.col("pos_share") <= 0.4, "挑剔型")
    .otherwise("中性"),
).select("user_id", "review_cnt", "pos_share", "review_activity", "review_tendency")
review_tag.write.mode("overwrite").parquet(os.path.join(cfg.TAGS_PATH, "review"))
print(f"  ✓ review: {review_tag.count():,} 用户")

spark.stop()
print("\n多维标签挖掘完成!")
