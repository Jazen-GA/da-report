# -*- coding: utf-8 -*-
"""
用户价值分层模型 — a.1 RFM 三指标计算
=====================================
对象: 全量成交用户(alipay >= 1)

  Recency   = 观测窗口截止日 - 用户最后购买日(天数, 越小越活跃)
  Frequency = 累计购买次数 / 累计购买商品数 / 覆盖品类数
  Monetary  = 相对消费力评分 = mean(品类价值权重 × 品牌层级 × log1p(商品销量热度))

口径:
  - 品类价值权重 w_cat : 一级类目销量热度分 5 档(1~5)
  - 品牌层级   w_brand: 头部=3 / 腰部=2 / 尾部=1(复现 category_brand_analysis 梯队口径)
  - 商品销量热度       : item_ops.alipay_cnt(该商品被购买次数), log1p 压缩长尾

输出:
  data/samples/user_value/rfm/                成交用户 RFM 明细(parquet)
  reports/user_value/rfm_distribution.csv     R/F/M 分布校验
"""
import os
import sys
import warnings

warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from pyspark.sql import functions as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import create_spark  # noqa: E402
import user_value.config as cfg  # noqa: E402

os.makedirs(cfg.UV_DATA, exist_ok=True)
os.makedirs(cfg.UV_REPORTS, exist_ok=True)

spark = create_spark("UserValue-RFM")

print("=" * 60)
print("a.1 RFM 三指标计算")
print("=" * 60)

# ── 1. 观测窗口截止日 ──
print("\n[1/5] 观测窗口截止日(取 user_labels 全局最后行为日期)")
ul = spark.read.parquet(cfg.USER_LABELS_PATH)
obs_end = ul.agg(F.max("last_date").alias("d")).collect()[0]["d"]
print(f"  观测窗口截止日 obs_end = {obs_end}")

# ── 2. 购买明细(只读 alipay 分区, 靠分区裁剪跳过 click/collect/cart) ──
print("\n[2/5] 读购买明细(action_type=alipay)")
alipay = (
    spark.read.parquet(cfg.CLEANED_LOG_PATH)
    .filter(F.col("action_type") == cfg.BUY_ACTION)
    .select("user_id", "item_id", "action_date")
)

# ── 3. 商品维度表(item_ops → 类目 / 品牌 / 销量热度) ──
print("\n[3/5] 商品维度表(item_ops)")
item_map = (
    spark.read.parquet(cfg.ITEM_OPS_PATH)
    .select(
        "item_id",
        F.col("parent_cat").cast("string").alias("parent_cat"),
        "brand_id",
        F.col("alipay_cnt").alias("item_sales"),
    )
    .filter(F.col("item_sales") > 0)
)
n_items = item_map.count()
print(f"  动销商品数: {n_items:,}")

# ── 4. 品类价值权重 + 品牌层级 ──
print("\n[4/5] 品类价值权重 / 品牌层级映射")

# 4.1 品类价值权重:一级类目销量热度分 5 档
pc = pd.read_csv(cfg.PARENT_CAT_CSV)[["parent_cat", "sales_cnt"]]
qs = pc["sales_cnt"].quantile([0.2, 0.4, 0.6, 0.8]).tolist()


def _w(s):
    for i, q in enumerate(qs):
        if s <= q:
            return i + 1
    return 5


pc["w_cat"] = pc["sales_cnt"].apply(_w)
w_cat_df = spark.createDataFrame(
    pc[["parent_cat", "w_cat"]].astype({"w_cat": "int64"})
).withColumn("parent_cat", F.col("parent_cat").cast("string"))

# 4.2 品牌层级:复现 category_brand_analysis.py 的梯队口径(score 排名分位)
bm = pd.read_csv(cfg.BRAND_METRICS_CSV)
bm = bm[bm["brand_label"] != "未标注"].copy()
bm["conv"] = bm["sales_cnt"] / bm["click_cnt"].replace(0, np.nan)


def _mm(s):
    return (s - s.min()) / (s.max() - s.min()) if s.max() > s.min() else s * 0


bm["score"] = (
    0.35 * _mm(np.log1p(bm["click_cnt"]))
    + 0.35 * _mm(np.log1p(bm["sales_cnt"]))
    + 0.30 * _mm(bm["conv"].fillna(0))
)
bm["rank_pct"] = bm["score"].rank(ascending=False, pct=True)
bm["tier"] = np.where(bm["rank_pct"] <= 0.05, "头部", np.where(bm["rank_pct"] <= 0.25, "腰部", "尾部"))
bm["w_brand"] = bm["tier"].map(cfg.BRAND_TIER_WEIGHTS)
brand_w_df = spark.createDataFrame(bm[["brand_label", "w_brand"]].astype({"w_brand": "int64"}))
print(f"  品类价值权重: {len(pc)} 个一级类目 → 1~5 档")
print(f"  品牌层级: {len(bm)} 个品牌 → 头部/腰部/尾部")

# ── 5. 计算单笔消费力 + 用户级聚合 ──
print("\n[5/5] 计算单笔消费力并聚合用户 RFM")
detail = (
    alipay.join(F.broadcast(item_map), "item_id", "left")
    .join(F.broadcast(w_cat_df), "parent_cat", "left")
    .join(F.broadcast(brand_w_df), F.col("brand_id") == F.col("brand_label"), "left")
    .withColumn("w_cat", F.coalesce("w_cat", F.lit(1)))
    .withColumn("w_brand", F.coalesce("w_brand", F.lit(cfg.BRAND_TIER_DEFAULT)))
    .withColumn("consumption", F.col("w_cat") * F.col("w_brand") * F.log1p("item_sales"))
)

rfm = (
    detail.groupBy("user_id")
    .agg(
        F.count("item_id").alias("alipay_cnt"),
        F.countDistinct("item_id").alias("distinct_item_cnt"),
        F.countDistinct("parent_cat").alias("distinct_cat_cnt"),
        F.min("action_date").alias("first_alipay_date"),
        F.max("action_date").alias("last_alipay_date"),
        F.avg("consumption").alias("monetary"),
    )
    .withColumn("recency_days", F.datediff(F.lit(obs_end), F.col("last_alipay_date")))
    .withColumn("monetary", F.round("monetary", 4))
)

rfm.cache()
n_users = rfm.count()
print(f"  成交用户数: {n_users:,}")

rfm.write.mode("overwrite").parquet(cfg.RFM_PATH)
print(f"  ✓ RFM 明细已落盘: {cfg.RFM_PATH}")

# ── 分布校验 ──
print("\nR/F/M 分布校验")
desc = (
    rfm.select("recency_days", "alipay_cnt", "distinct_item_cnt", "distinct_cat_cnt", "monetary")
    .summary("count", "mean", "stddev", "min", "25%", "50%", "75%", "max")
    .toPandas()
)
desc.to_csv(os.path.join(cfg.UV_REPORTS, "rfm_distribution.csv"), index=False, encoding="utf-8-sig")
print(desc.to_string(index=False))
print("  ✓ 分布校验已保存: reports/user_value/rfm_distribution.csv")

spark.stop()
print("\nRFM 计算完成!")
