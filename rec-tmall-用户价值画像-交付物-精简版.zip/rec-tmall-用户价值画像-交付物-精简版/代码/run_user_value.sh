#!/bin/bash
# ================================================================
# Rec-Tmall 用户价值画像与流失复购预测 — 一键运行脚本
# 顺序执行: RFM → 价值分层 → 画像 → 标签挖掘 → 宽表 → 报告
# ================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
cd "$PROJECT_DIR"

echo "=============================================="
echo "  Rec-Tmall 用户价值画像与流失复购预测"
echo "  数据规模: ~12.6亿行 | 965万用户 | 419万成交用户"
echo "=============================================="
echo ""

# 激活虚拟环境
source venv/bin/activate

# ── Step 1: RFM 三指标 ──
echo ">>> [1/6] RFM 三指标计算..."
python scripts/user_value/build_rfm.py
echo ""

# ── Step 2: 价值评分与分层 ──
echo ">>> [2/6] 价值评分与层级划分..."
python scripts/user_value/build_value_score.py
echo ""

# ── Step 3: 各层级画像 ──
echo ">>> [3/6] 各层级价值画像..."
python scripts/user_value/build_value_profile.py
echo ""

# ── Step 4: 多维标签挖掘 ──
echo ">>> [4/6] 多维标签挖掘..."
python scripts/user_value/build_tags.py
echo ""

# ── Step 5: 标签宽表整合 ──
echo ">>> [5/6] 标签宽表 + 覆盖率 + 字典..."
python scripts/user_value/build_tag_wide.py
echo ""

# ── Step 6: 综合报告 ──
echo ">>> [6/6] 综合报告生成..."
python scripts/user_value/generate_report.py
echo ""

echo "=============================================="
echo "  分析完成!"
echo ""
echo "  交付物:"
echo "    reports/user_value/user_value_report.html  — 综合分析报告"
echo "    data/samples/user_value/rfm/               — 成交用户 RFM 明细"
echo "    data/samples/user_value/value_score/       — 评分 + 分层"
echo "    data/samples/user_value/tag_wide/          — 全量用户标签宽表"
echo "    reports/user_value/tag_dictionary.md       — 标签体系说明文档"
echo "    reports/user_value/tier_profile.csv        — 各层画像"
echo "    reports/user_value/tag_coverage.csv        — 标签覆盖率"
echo "=============================================="
