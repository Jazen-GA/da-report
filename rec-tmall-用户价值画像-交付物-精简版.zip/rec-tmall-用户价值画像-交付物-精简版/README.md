# 用户价值画像与流失复购预测模块

Rec-Tmall 数据分析的第五个模块(继数据链路 / 用户行为 / 商品运营 / 评论口碑 / 购买意愿建模之后)。

## 内容

- **a. 用户价值分层模型**(RFM 重构):成交用户 R/F/M 三指标 → 5 分制加权评分 → 高/中/低主层 + 子层 → 分层校验 → 各层画像
- **b. 用户兴趣标签体系**:四大维度(基础行为 / 兴趣偏好 / 消费习惯 / 价值层级 + 口碑行为)标签挖掘 → 全量用户标签宽表 + 覆盖率校验 + 标签字典

## 脚本(按执行顺序)

| 脚本 | 职责 | 输出 |
|---|---|---|
| `config.py` | 权重/阈值/分层规则/标签字典(集中可调) | — |
| `build_rfm.py` | 成交用户 RFM 三指标(Monetary 用消费力估算) | `data/samples/user_value/rfm/` |
| `build_value_score.py` | 5 分制分箱 + 加权总分 + 分层 + 显著性校验 | `data/samples/user_value/value_score/` |
| `build_value_profile.py` | 各层画像 + 高价值识别特征 | `reports/user_value/tier_*.csv` |
| `build_tags.py` | 类目/品牌/时段/决策/倾向/口碑六类标签 | `data/samples/user_value/tags/` |
| `build_tag_wide.py` | 标签宽表 + 覆盖率 + 标签字典 | `data/samples/user_value/tag_wide/` |
| `generate_report.py` | 综合 HTML 报告 | `reports/user_value/user_value_report.html` |

## 运行

```bash
cd /Users/Admin/Desktop/tmall/rec-tmall
source venv/bin/activate
bash run_user_value.sh        # 全链路
# 或单步: python scripts/user_value/build_tags.py
```

## 关键口径

- **消费力估算(Monetary)**:无真实金额字段, 用「品类价值权重(一级类目销量热度分 5 档) × 品牌层级(头部3/腰部2/尾部1, 复现 category_brand_analysis 口径) × log1p(商品销量热度)」取用户每笔均值替代, 避免与 Frequency 共线。
- **RFM 权重**:R=0.2 / F=0.4 / M=0.4(频次与消费力优先)。
- **行为权重**:购买 4 / 加购 3 / 收藏 2 / 点击 1。
- **性能注意**:`build_tags.py` 全量日志(12.6 亿行)不可 `persist`(会 OOM), 每个标签聚合独立流式读取。

## 关键结果(全量)

- 成交用户 4,189,659(占全量 965 万用户的 43.4%)
- 价值分层:高 27.65%(复购率 91.9%) / 中 36.02%(58.8%) / 低 36.32%(23.7%), 组间差异 p<0.001
- 标签宽表:965 万用户 × 38 列, 高价值用户核心标签覆盖率 >99%(口碑除外)
