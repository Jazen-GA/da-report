"""
情感分类特征工程
================
从弱标注样本（reviews_labeled.csv）构建三类特征：

1. 文本语义特征
   - 词袋 BOW（CountVectorizer，unigram，给朴素贝叶斯）
   - TF-IDF（unigram + bigram，sublinear_tf，给逻辑回归 / 作稠密降维源）
2. 情感词典特征（强基线）
   - 正/负情感词匹配数、占比、净得分、强度加权分
   - 基础统计：关键词总数、独有词数、主题词覆盖度
3. 品类适配特征
   - parent_cat one-hot + leaf_cat 高频 one-hot（适配不同品类评价表达差异）

按模型需求组装三套矩阵：
  X_bow     → 朴素贝叶斯（非负计数）
  X_tfidf   → 逻辑回归（TF-IDF + 词典 + 品类，稀疏）
  X_dense   → GBDT（词典 + 品类 + SVD 文本降维，稠密）

输出（data/sentiment/features/）:
  X_bow_{split}.npz / X_tfidf_{split}.npz / X_dense_{split}.npz / y_{split}.npy
  meta_{split}.csv           # item_id / parent_cat / leaf_cat / label，供分品类评估与聚合
  vectorizers.pkl            # 训练好的向量器（供全量推理复用）

用法: python scripts/sentiment/features.py
"""
import os, sys, re, time, json, pickle
import numpy as np
import pandas as pd
import scipy.sparse as sparse
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.preprocessing import OneHotEncoder
from sklearn.decomposition import TruncatedSVD

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.config import *
from scripts.sentiment.lexicon_data import all_lexicon

LABELED_CSV = os.path.join(SENTIMENT_SAMPLES_DIR, "reviews_labeled.csv")
FEAT_DIR = SENTIMENT_FEATURES_DIR

# 主题词表（评论常见关注维度，用于「主题词覆盖度」特征 + 后续主题归类）
TOPIC_WORDS = {
    "质量": ["质量", "品质", "做工", "材质", "面料", "手感", "掉色", "掉毛", "起球", "缩水", "变形", "瑕疵", "破损"],
    "物流": ["物流", "快递", "发货", "速度", "配送", "送达", "包装", "包裹", "快递员"],
    "服务": ["客服", "服务", "态度", "售后", "退货", "退款", "退换"],
    "性价比": ["价格", "价钱", "价位", "性价比", "便宜", "贵", "实惠", "划算", "超值", "不值"],
    "描述相符": ["描述", "相符", "一样", "一致", "色差", "符合", "图片", "照片"],
    "尺码": ["尺码", "大小", "尺寸", "码", "偏大", "偏小", "合身", "修身"],
    "外观": ["颜色", "款式", "版型", "样式", "设计", "外观", "好看", "漂亮"],
    "使用体验": ["效果", "功能", "性能", "使用", "操作", "安装", "味道", "口感", "气味"],
}


def _topic_coverage(tokens):
    """主题词覆盖度：命中的主题维度数 / 总主题维度数"""
    if not tokens:
        return 0.0
    toks = set(tokens)
    hit = sum(1 for words in TOPIC_WORDS.values() if toks & set(words))
    return hit / len(TOPIC_WORDS)


def build_basic_features(df):
    """基础统计特征（不含词典匹配分——那些会泄漏弱监督标签）"""
    feats = pd.DataFrame(index=df.index)
    tok_lists = df["clean_tokens"].apply(lambda s: s.split(" ") if s else [])
    n_tokens = tok_lists.apply(len)
    feats["token_count"] = n_tokens
    feats["unique_count"] = tok_lists.apply(lambda ts: len(set(ts)))
    feats["topic_coverage"] = tok_lists.apply(_topic_coverage)
    return feats


def build_category_features(train_df, val_df, test_df, top_leaf=100):
    """品类编码：parent_cat 全 one-hot + leaf_cat 高频 top-N one-hot"""
    # leaf_cat 高频取值（在 train 上统计）
    leaf_counts = train_df["leaf_cat"].value_counts()
    top_leafs = set(leaf_counts.head(top_leaf).index)
    def encode(df):
        pc = df["parent_cat"].astype(str).values.reshape(-1, 1)
        lc = df["leaf_cat"].apply(lambda x: str(x) if x in top_leafs else "other").values.reshape(-1, 1)
        return np.hstack([pc, lc])
    enc = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    enc.fit(encode(train_df))
    return (enc.transform(encode(train_df)), enc.transform(encode(val_df)),
            enc.transform(encode(test_df)), enc, top_leafs)


def main():
    os.makedirs(FEAT_DIR, exist_ok=True)
    t0 = time.time()
    print("=" * 60)
    print("情感分类特征工程")
    print("=" * 60)

    df = pd.read_csv(LABELED_CSV, dtype={"parent_cat": int, "leaf_cat": int})
    df["clean_tokens"] = df["clean_tokens"].fillna("")
    splits = {}
    for sp in ["train", "val", "test"]:
        splits[sp] = df[df["split"] == sp].reset_index(drop=True)
        print(f"  {sp}: {len(splits[sp]):,} 条，正样本 {splits[sp]['label'].mean()*100:.1f}%")

    # ── 1. 文本语义 ──
    print("\n  构建文本特征（BOW + TF-IDF 1-2gram）...")
    bow = CountVectorizer(min_df=3, max_features=300000, token_pattern=r"\S+")
    tfidf = TfidfVectorizer(ngram_range=(1, 2), min_df=3, max_features=300000,
                            sublinear_tf=True, token_pattern=r"\S+")
    X_bow_train = bow.fit_transform(splits["train"]["clean_tokens"])
    X_tf_train = tfidf.fit_transform(splits["train"]["clean_tokens"])
    X_bow_val = bow.transform(splits["val"]["clean_tokens"])
    X_tf_val = tfidf.transform(splits["val"]["clean_tokens"])
    X_bow_test = bow.transform(splits["test"]["clean_tokens"])
    X_tf_test = tfidf.transform(splits["test"]["clean_tokens"])
    print(f"    BOW 词表 {len(bow.vocabulary_):,}，TF-IDF 特征 {X_tf_train.shape[1]:,}")

    # ── 2. 基础统计特征 ──
    print("  构建基础统计特征...")
    basic_train = build_basic_features(splits["train"])
    basic_val = build_basic_features(splits["val"])
    basic_test = build_basic_features(splits["test"])

    # ── 3. 品类特征 ──
    print("  构建品类编码特征...")
    cat_train, cat_val, cat_test, cat_enc, top_leafs = build_category_features(
        splits["train"], splits["val"], splits["test"])

    # ── 组装 ──
    print("  组装特征矩阵...")
    def _dense_to_sparse(m):
        return sparse.csr_matrix(m)

    # X_bow: BOW（给 NB）
    X_bow = {"train": X_bow_train, "val": X_bow_val, "test": X_bow_test}

    # X_tfidf: TF-IDF + 基础统计 + 品类（给 LR）
    X_tf = {}
    for sp in ["train", "val", "test"]:
        basic_sp = _dense_to_sparse(eval(f"basic_{sp}").values.astype(float))
        cat_sp = sparse.csr_matrix(eval(f"cat_{sp}"))
        X_tf[sp] = sparse.hstack([eval(f"X_tf_{sp}"), basic_sp, cat_sp]).tocsr()

    # X_dense: 基础统计 + 品类 + SVD 文本（给 GBDT）
    svd = TruncatedSVD(n_components=200, random_state=42)
    svd.fit(X_tf_train)
    X_dense = {}
    for sp in ["train", "val", "test"]:
        text_svd = svd.transform(eval(f"X_tf_{sp}"))
        dense = np.hstack([eval(f"basic_{sp}").values.astype(float),
                           eval(f"cat_{sp}"), text_svd])
        X_dense[sp] = dense

    # ── 落盘 ──
    print("  落盘特征矩阵...")
    for sp in ["train", "val", "test"]:
        sparse.save_npz(os.path.join(FEAT_DIR, f"X_bow_{sp}.npz"), X_bow[sp])
        sparse.save_npz(os.path.join(FEAT_DIR, f"X_tfidf_{sp}.npz"), X_tf[sp])
        np.save(os.path.join(FEAT_DIR, f"X_dense_{sp}.npy"), X_dense[sp])
        np.save(os.path.join(FEAT_DIR, f"y_{sp}.npy"), splits[sp]["label"].values)
        splits[sp][["item_id", "parent_cat", "leaf_cat", "label", "pos_score", "neg_score"]] \
            .to_csv(os.path.join(FEAT_DIR, f"meta_{sp}.csv"), index=False)

    vectorizers = {
        "bow": bow, "tfidf": tfidf, "svd": svd, "cat_encoder": cat_enc,
        "top_leafs": top_leafs,
        "lex_cols": list(basic_train.columns),
        "cat_n_cols": cat_train.shape[1],
        "tfidf_n_cols": X_tf_train.shape[1],
    }
    with open(os.path.join(FEAT_DIR, "vectorizers.pkl"), "wb") as f:
        pickle.dump(vectorizers, f)

    print(f"\n  特征工程完成，耗时 {time.time() - t0:.1f}s")
    print(f"    X_bow   维度: {X_bow_train.shape}")
    print(f"    X_tfidf 维度: {X_tf['train'].shape}")
    print(f"    X_dense 维度: {X_dense['train'].shape}")


if __name__ == "__main__":
    main()
