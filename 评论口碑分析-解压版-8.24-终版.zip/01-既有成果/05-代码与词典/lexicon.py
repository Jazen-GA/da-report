"""
全量词频基线 + 情感词典落地
==========================
1. 扫描全量评论 feedback（天池已分词），统计：
   - 单条评论关键词数量分布（清洗前 / 后）
   - 全局词频基线（token 出现次数），作为基础评论词库
2. 把自建词典（lexicon_data.py）落成文本资产，供弱监督标注 / 特征工程复用

噪声清洗规则: token 需含至少一个 Unicode 字母（Java 正则 \\p{L}），据此剔除纯标点、纯数字。
实现上统一用 Column.rlike 直接传正则，避免 F.expr 里 SQL 字符串字面量吞反斜杠。

输出:
  data/sentiment/vocab/word_freq.csv        # 全局词频基线（word, count, pct）
  data/sentiment/vocab/vocab_stats.json     # 词库统计 + 单条评论关键词数分布
  data/sentiment/lexicon/*.txt              # 正/负/否定/程度 词典文件

用法: python scripts/sentiment/lexicon.py
"""
import os, sys, time, json
from pyspark.sql import functions as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.config import *
from scripts.sentiment.lexicon_data import all_lexicon

# 含至少一个 Unicode 字母（CJK 也匹配），纯标点「，。」、纯数字「50」被剔除
_HAS_LETTER = r"[\p{L}]"


def _token_len_stats(df, col, name):
    """对某个 token 数量列统计 min/max/avg/std + 分位数"""
    s = df.agg(
        F.min(col).alias("min"), F.max(col).alias("max"),
        F.avg(col).alias("avg"), F.stddev(col).alias("std"),
    ).collect()[0]
    q = df.approxQuantile(col, [0.25, 0.5, 0.75, 0.9, 0.95, 0.99], 0.01)
    return {
        "min": int(s["min"]), "max": int(s["max"]),
        "avg": round(s["avg"], 3), "std": round(s["std"] or 0, 3),
        "quantiles": {"p25": q[0], "p50": q[1], "p75": q[2],
                      "p90": q[3], "p95": q[4], "p99": q[5]},
    }


def compute_word_freq(spark):
    """全量词频基线 + 单条评论关键词数分布"""
    print("=" * 60)
    print("全量评论词频基线")
    print("=" * 60)
    t0 = time.time()

    df = spark.read.parquet(CLEANED_FILES["review"])
    total_reviews = df.count()
    print(f"  评论总数: {total_reviews:,}")

    split_col = F.split(F.col("feedback"), " ")

    # ── 1. 单条评论「原始」关键词数分布（含标点/数字 token）──
    print("  计算单条评论关键词数分布...")
    df_raw = df.withColumn("raw_len", F.size(split_col))
    raw_stats = _token_len_stats(df_raw, "raw_len", "raw")
    print(f"    原始关键词数: 均值 {raw_stats['avg']}，中位数 {raw_stats['quantiles']['p50']}，p99 {raw_stats['quantiles']['p99']}")

    # ── 2. explode → 清洗 → 同时算词频 + 单条评论「有效」关键词数 ──
    print("  计算全局词频 + 有效关键词数（explode + 过滤 + groupBy）...")
    df_id = df.withColumn("_rid", F.monotonically_increasing_id())
    words = df_id.select("_rid", F.explode(split_col).alias("word"))
    words_clean = words.withColumn("word", F.trim(F.col("word"))).filter(
        F.col("word").isNotNull() &
        (F.col("word") != "") &
        F.col("word").rlike(_HAS_LETTER)
    )

    # 词频基线
    freq = words_clean.groupBy("word").count()
    total_tokens = freq.agg(F.sum("count").alias("t")).collect()[0]["t"]
    vocab_size = freq.count()
    freq_pd = freq.withColumn("pct", F.col("count") / total_tokens) \
        .orderBy(F.desc("count")).toPandas()

    # 有效关键词数分布（按评论行号聚合）
    clean_counts = words_clean.groupBy("_rid").count()
    clean_stats = _token_len_stats(clean_counts, "count", "clean")
    print(f"    有效关键词数: 均值 {clean_stats['avg']}，中位数 {clean_stats['quantiles']['p50']}，p99 {clean_stats['quantiles']['p99']}")

    # ── 3. 落盘 ──
    os.makedirs(SENTIMENT_VOCAB_DIR, exist_ok=True)
    freq_csv = os.path.join(SENTIMENT_VOCAB_DIR, "word_freq.csv")
    freq_pd.to_csv(freq_csv, index=False, encoding="utf-8")

    stats = {
        "total_reviews": total_reviews,
        "total_tokens": int(total_tokens),
        "vocab_size": int(vocab_size),
        "raw_token_count": raw_stats,
        "clean_token_count": clean_stats,
        "top_words": freq_pd.head(50)[["word", "count", "pct"]].to_dict("records"),
    }
    stats_json = os.path.join(SENTIMENT_VOCAB_DIR, "vocab_stats.json")
    with open(stats_json, "w", encoding="utf-8") as f:
        json.dump(stats, f, ensure_ascii=False, indent=2)

    print(f"  词频基线完成: 总 token {total_tokens:,}，去重词 {vocab_size:,}")
    print(f"  输出: {freq_csv}")
    print(f"  输出: {stats_json}")
    print(f"  耗时 {time.time() - t0:.1f}s")

    # Top 50 高频词预览
    print("\n  Top 50 高频词:")
    for i, r in enumerate(freq_pd.head(50).itertuples(index=False)):
        print(f"    {i+1:>2}. {r.word:<12} {r.count:>10,}  ({r.pct*100:.2f}%)")
    return stats


def save_lexicon_files():
    """把自建词典落成文本资产"""
    os.makedirs(SENTIMENT_LEXICON_DIR, exist_ok=True)
    d = all_lexicon()
    for name, words in d.items():
        path = os.path.join(SENTIMENT_LEXICON_DIR, f"{name}.txt")
        with open(path, "w", encoding="utf-8") as f:
            for w in sorted(words):
                f.write(w + "\n")
        print(f"  词典已落盘: {path} ({len(words)} 词)")


def main():
    spark = create_spark("Sentiment-Lexicon")
    compute_word_freq(spark)
    print()
    save_lexicon_files()
    spark.stop()
    print("\n" + "=" * 60)
    print("词频基线 + 词典落地完成")
    print("=" * 60)


if __name__ == "__main__":
    main()
