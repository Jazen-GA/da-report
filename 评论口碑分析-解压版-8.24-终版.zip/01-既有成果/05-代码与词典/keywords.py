"""
核心评价关键词与主题体系提炼
============================
1. 全域核心词：基于最优模型（LR）系数 / NB 特征对数概率，映射回 TF-IDF/BOW 词表，
   分别输出全域 Top 正 / 负核心词（含二元词组）
2. 分品类核心词：在弱标注样本上，按 parent_cat 统计每个词在正/负评论中的分布，
   输出各品类 Top 正 / 负关键词，识别核心关注维度与痛点
3. 主题归类：把核心词按业务主题（质量/物流/服务/性价比/描述相符/尺码/外观/使用体验）归类，
   统计各主题正负占比

输出（data/sentiment/output/）:
  global_pos_words.csv / global_neg_words.csv   # 全域核心词
  per_category_keywords.csv                      # 分品类核心词
  theme_keyword_stats.csv                        # 主题归类统计

用法: python scripts/sentiment/keywords.py
"""
import os, sys, pickle
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.config import *
from scripts.sentiment.features import TOPIC_WORDS

MODEL_DIR = SENTIMENT_MODEL_DIR
FEAT_DIR = SENTIMENT_FEATURES_DIR
OUT_DIR = SENTIMENT_OUTPUT_DIR
LABELED_CSV = os.path.join(SENTIMENT_SAMPLES_DIR, "reviews_labeled.csv")


def _load_model_coefs():
    with open(os.path.join(FEAT_DIR, "vectorizers.pkl"), "rb") as f:
        vec = pickle.load(f)
    coef_lr = None
    if os.path.exists(os.path.join(MODEL_DIR, "coef_lr.pkl")):
        with open(os.path.join(MODEL_DIR, "coef_lr.pkl"), "rb") as f:
            coef_lr = pickle.load(f)
    coef_nb = None
    if os.path.exists(os.path.join(MODEL_DIR, "coef_nb.pkl")):
        with open(os.path.join(MODEL_DIR, "coef_nb.pkl"), "rb") as f:
            coef_nb = pickle.load(f)
    return vec, coef_lr, coef_nb


def global_keywords(vec, coef_lr, coef_nb, top_k=50):
    """全域核心词：LR 系数映射 TF-IDF 词表（含 bigram），NB 对数概率差映射 BOW"""
    rows = []
    tfidf_n = vec["tfidf_n_cols"]

    # LR 系数（TF-IDF 部分）
    if coef_lr is not None:
        w = np.asarray(coef_lr[0][:tfidf_n]).ravel()
        for tok, idx in vec["tfidf"].vocabulary_.items():
            rows.append({"word": tok, "weight_lr": float(w[idx]),
                         "is_bigram": " " in tok})

    # NB 对数概率差（BOW 部分，非负计数）
    if coef_nb is not None:
        lp = np.asarray(coef_nb)          # (2, vocab)
        diff = lp[1] - lp[0]              # log P(w|正) - log P(w|负)
        for tok, idx in vec["bow"].vocabulary_.items():
            rows.append({"word": tok, "weight_nb": float(diff[idx]),
                         "is_bigram": False})

    df = pd.DataFrame(rows)
    # 综合：优先 LR 权重，缺失用 NB
    if "weight_lr" in df.columns:
        df["weight"] = df["weight_lr"]
    else:
        df["weight"] = df["weight_nb"]

    df_pos = df.sort_values("weight", ascending=False).drop_duplicates("word")
    df_neg = df.sort_values("weight", ascending=True).drop_duplicates("word")

    pos = df_pos.head(top_k)[["word", "weight", "is_bigram"]]
    neg = df_neg.head(top_k)[["word", "weight", "is_bigram"]]
    return pos, neg


def per_category_keywords(labeled_df, top_k=20, min_count=10, min_cat=500):
    """分品类核心词：正负评论中词的分布差"""
    df = labeled_df[labeled_df["label"] != -1].copy()
    # 只保留样本量足够的品类
    cat_counts = df["parent_cat"].value_counts()
    keep_cats = set(cat_counts[cat_counts >= min_cat].index)

    rows = []
    for cat, g in df[df["parent_cat"].isin(keep_cats)].groupby("parent_cat"):
        pos_docs = g[g["label"] == 1]
        neg_docs = g[g["label"] == 0]
        # 词频统计
        from collections import Counter
        pos_counter, neg_counter = Counter(), Counter()
        for ts in pos_docs["clean_tokens"].fillna(""):
            pos_counter.update(ts.split(" "))
        for ts in neg_docs["clean_tokens"].fillna(""):
            neg_counter.update(ts.split(" "))

        vocab = set(pos_counter) | set(neg_counter)
        for w in vocab:
            pc, nc = pos_counter[w], neg_counter[w]
            if pc + nc < min_count:
                continue
            score = (pc - nc) / (pc + nc)   # [-1, 1]
            rows.append({"parent_cat": cat, "word": w, "score": round(score, 4),
                         "pos_cnt": pc, "neg_cnt": nc, "total": pc + nc})

    res = pd.DataFrame(rows)
    # 每品类取 Top 正/负
    out = []
    for cat, g in res.groupby("parent_cat"):
        top_pos = g.sort_values(["score", "total"], ascending=[False, False]).head(top_k)
        top_pos = top_pos.copy(); top_pos["polarity"] = "positive"
        top_neg = g.sort_values(["score", "total"], ascending=[True, False]).head(top_k)
        top_neg = top_neg.copy(); top_neg["polarity"] = "negative"
        out.append(pd.concat([top_pos, top_neg]))
    return pd.concat(out) if out else pd.DataFrame()


def theme_classification(global_pos, global_neg):
    """核心词主题归类 + 各主题正负占比"""
    def match_theme(word):
        for theme, words in TOPIC_WORDS.items():
            if any(w in word for w in words):   # 词或其组合含主题词
                return theme
        return "其他"

    rows = []
    for polarity, dfa in [("positive", global_pos), ("negative", global_neg)]:
        for _, r in dfa.iterrows():
            rows.append({"polarity": polarity, "word": r["word"],
                         "theme": match_theme(r["word"]), "weight": r["weight"]})
    df = pd.DataFrame(rows)
    stat = df.groupby(["theme", "polarity"]).size().unstack(fill_value=0)
    stat["pos_ratio"] = stat["positive"] / (stat["positive"] + stat["negative"] + 1e-6)
    stat = stat.reset_index().sort_values("positive", ascending=False)
    return df, stat


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    print("=" * 60)
    print("核心关键词与主题体系提炼")
    print("=" * 60)

    vec, coef_lr, coef_nb = _load_model_coefs()
    pos, neg = global_keywords(vec, coef_lr, coef_nb)
    pos.to_csv(os.path.join(OUT_DIR, "global_pos_words.csv"), index=False, encoding="utf-8")
    neg.to_csv(os.path.join(OUT_DIR, "global_neg_words.csv"), index=False, encoding="utf-8")

    print("\n  全域正向核心词 Top 20:")
    for _, r in pos.head(20).iterrows():
        print(f"    {r['word']:<14} {r['weight']:.3f}" + ("  [bigram]" if r['is_bigram'] else ""))
    print("\n  全域负向核心词 Top 20:")
    for _, r in neg.head(20).iterrows():
        print(f"    {r['word']:<14} {r['weight']:.3f}" + ("  [bigram]" if r['is_bigram'] else ""))

    # 分品类
    labeled = pd.read_csv(LABELED_CSV, dtype={"parent_cat": int})
    per_cat = per_category_keywords(labeled)
    per_cat.to_csv(os.path.join(OUT_DIR, "per_category_keywords.csv"), index=False, encoding="utf-8")
    print(f"\n  分品类核心词: {len(per_cat):,} 条 → per_category_keywords.csv")

    # 主题归类
    theme_df, theme_stat = theme_classification(pos, neg)
    theme_df.to_csv(os.path.join(OUT_DIR, "theme_keyword_detail.csv"), index=False, encoding="utf-8")
    theme_stat.to_csv(os.path.join(OUT_DIR, "theme_keyword_stats.csv"), index=False, encoding="utf-8")
    print("\n  主题归类统计:")
    print(theme_stat.to_string(index=False))

    print("\n  关键词提炼完成")


if __name__ == "__main__":
    main()
