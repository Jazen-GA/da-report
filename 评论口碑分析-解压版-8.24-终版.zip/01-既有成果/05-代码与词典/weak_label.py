"""
弱监督标注流水线
================
1. 抽样：全量 review 均匀抽样 N 条 → join product（拿 parent_cat / leaf_cat 品类）
2. 预处理：按空格分词（天池已分）→ 剔除纯标点/纯数字 → 剔除停用词
3. 弱监督标注：情感词典 + 否定词翻转 + 程度词加权 → 正(1) / 负(0) / 中性(-1)
4. 人工校验：分层抽样千级导出 CSV 供人工复核，统计标注基线分布
5. 划分：按 label 分层切 train / val / test（7:1.5:1.5）

输出:
  data/sentiment/samples/reviews_sample.parquet   # 抽样原始样本（含品类）
  data/sentiment/samples/reviews_labeled.csv      # 弱标注结果（含 split 列）
  data/sentiment/samples/human_check.csv          # 人工校验抽样
  data/sentiment/samples/label_distribution.json  # 正负/品类分布

用法: python scripts/sentiment/weak_label.py [--n 300000] [--seed 42]
"""
import os, sys, re, time, json, argparse
import pandas as pd
from pyspark.sql import functions as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.config import *
from scripts.sentiment.lexicon_data import all_lexicon, STOPWORDS

# 含至少一个 Unicode 字母（剔除纯标点/纯数字）
_HAS_LETTER = re.compile(r"[^\W\d_]")

# 抽样 / 输出文件
SAMPLE_PARQUET = os.path.join(SENTIMENT_SAMPLES_DIR, "reviews_sample.parquet")
LABELED_CSV = os.path.join(SENTIMENT_SAMPLES_DIR, "reviews_labeled.csv")
HUMAN_CHECK_CSV = os.path.join(SENTIMENT_SAMPLES_DIR, "human_check.csv")
LABEL_DIST_JSON = os.path.join(SENTIMENT_SAMPLES_DIR, "label_distribution.json")


# ── 1. 预处理 ──
def preprocess_tokens(feedback, stopwords):
    """空格分词 → 剔除纯标点/纯数字/停用词 → 返回干净 token 列表"""
    out = []
    for t in feedback.split(" "):
        t = t.strip()
        if not t or not _HAS_LETTER.search(t):
            continue
        if t in stopwords:
            continue
        out.append(t)
    return out


# ── 2. 弱监督标注 ──
def weak_label_tokens(tokens, lex):
    """
    情感词典规则打分：正向词 +1，负向词 -1（加权后累加）
    - 否定词（不/没/没有…）开启 2 词窗口，翻转窗口内情感词极性
    - 程度词（很/非常/太…）给下一个情感词 ×1.5 强度
    返回 (pos_score, neg_score)
    """
    pos, neg = 0.0, 0.0
    neg_window = 0
    degree = 1.0
    pos_set, neg_set = lex["positive"], lex["negative"]

    for t in tokens:
        if t in lex["transition"]:
            neg_window = 0          # 转折词重置否定窗口，防「还没用，不过不错」误翻
            degree = 1.0
            continue
        if t in lex["negation"]:
            neg_window = 2
            continue
        if t in lex["degree"]:
            degree = 1.5
            continue
        is_pos, is_neg = t in pos_set, t in neg_set
        if is_pos or is_neg:
            w = degree
            if neg_window > 0:                      # 否定翻转
                if is_pos:
                    neg += w
                else:
                    pos += w
            else:
                if is_pos:
                    pos += w
                else:
                    neg += w
            neg_window = 0
            degree = 1.0
            continue
        if neg_window > 0:                          # 非词典词消耗否定窗口
            neg_window -= 1
    return pos, neg


def to_label(pos, neg):
    """打分 → 标签：正=1，负=0，中性=-1"""
    if pos > neg:
        return 1
    if neg > pos:
        return 0
    return -1


def label_frame(df, lex, stopwords):
    """对 DataFrame 逐行预处理 + 弱标注，返回带标签/分数/置信度的 df"""
    t0 = time.time()
    tokens = df["feedback"].apply(lambda x: preprocess_tokens(x, stopwords))
    scores = tokens.apply(lambda ts: weak_label_tokens(ts, lex))
    df = df.copy()
    df["clean_tokens"] = tokens.apply(lambda ts: " ".join(ts))
    df["pos_score"] = scores.apply(lambda s: s[0])
    df["neg_score"] = scores.apply(lambda s: s[1])
    df["label"] = df.apply(lambda r: to_label(r["pos_score"], r["neg_score"]), axis=1)
    df["confidence"] = (df["pos_score"] - df["neg_score"]).abs() / (
        df["pos_score"] + df["neg_score"] + 1e-6)
    print(f"  标注耗时 {time.time() - t0:.1f}s，共 {len(df):,} 条")
    return df


# ── 3. 抽样 + 关联品类 ──
def sample_reviews(spark, n_target, seed):
    """均匀抽样 → join product 拿品类 → 落 parquet + 转 pandas"""
    print("  读取全量 review 并均匀抽样...")
    review = spark.read.parquet(CLEANED_FILES["review"])
    total = review.count()
    frac = min(1.0, n_target / total)
    sample = review.sample(fraction=frac, seed=seed)

    print("  关联商品品类（parent_cat / leaf_cat）...")
    product = spark.read.parquet(CLEANED_FILES["product"]).select(
        "item_id", "category",
        F.split(F.col("category"), "-").getItem(0).cast("int").alias("parent_cat"),
        F.split(F.col("category"), "-").getItem(1).cast("int").alias("leaf_cat"),
    )
    joined = sample.join(product, "item_id", "left")
    matched = joined.filter(F.col("parent_cat").isNotNull()).count()
    joined = joined.fillna(-1, subset=["parent_cat", "leaf_cat"]) \
                 .fillna("", subset=["category"])
    n = joined.count()

    print(f"  抽样 {n:,} 条（全量 {total:,}，占比 {n/total*100:.2f}%）")
    print(f"  品类匹配 {matched:,} 条（{matched/n*100:.2f}%），未匹配 {n - matched:,} 条")

    joined.write.mode("overwrite").option("compression", "snappy").parquet(SAMPLE_PARQUET)
    pdf = joined.select("item_id", "user_id", "feedback", "category",
                        "parent_cat", "leaf_cat").toPandas()
    return pdf, total, n


# ── 4. 划分 ──
def split_train_val_test(df, seed):
    """按 label 分层切 train/val/test = 7:1.5:1.5（仅非中性样本）"""
    from sklearn.model_selection import train_test_split
    non_neutral = df[df["label"] != -1].copy()
    train, rest = train_test_split(
        non_neutral, test_size=0.3, stratify=non_neutral["label"], random_state=seed)
    val, test = train_test_split(
        rest, test_size=0.5, stratify=rest["label"], random_state=seed)
    for d in (train, val, test):
        d["split"] = "train" if d is train else ("val" if d is val else "test")
    df["split"] = "excluded"          # 中性样本不参与训练
    df.loc[train.index, "split"] = "train"
    df.loc[val.index, "split"] = "val"
    df.loc[test.index, "split"] = "test"
    return df, {"train": len(train), "val": len(val), "test": len(test),
                "neutral": int((df["label"] == -1).sum())}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=300000, help="抽样条数")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    spark = create_spark("Sentiment-WeakLabel")
    os.makedirs(SENTIMENT_SAMPLES_DIR, exist_ok=True)
    lex = all_lexicon()

    pdf, total, n = sample_reviews(spark, args.n, args.seed)
    pdf = label_frame(pdf, lex, STOPWORDS)

    # ── 标注分布 ──
    dist = pdf["label"].value_counts(dropna=False).to_dict()
    print(f"  标注分布: {dist}")
    print(f"  正样本占比: {(pdf['label'] == 1).mean()*100:.1f}%")

    # ── 人工校验抽样（正负各 ~1500，跨品类）──
    non_neutral = pdf[pdf["label"] != -1]
    check = pd.concat([
        non_neutral[non_neutral["label"] == 1].sample(min(1500, (non_neutral["label"] == 1).sum()), random_state=args.seed),
        non_neutral[non_neutral["label"] == 0].sample(min(1500, (non_neutral["label"] == 0).sum()), random_state=args.seed),
    ])
    check[["item_id", "feedback", "parent_cat", "label", "pos_score", "neg_score"]] \
        .to_csv(HUMAN_CHECK_CSV, index=False, encoding="utf-8")
    print(f"  人工校验抽样: {len(check)} 条 → {HUMAN_CHECK_CSV}")

    # ── 划分 ──
    pdf, split_cnt = split_train_val_test(pdf, args.seed)
    print(f"  划分: train {split_cnt['train']:,} / val {split_cnt['val']:,} / "
          f"test {split_cnt['test']:,} / 中性 {split_cnt['neutral']:,}")

    # ── 落盘 ──
    pdf.to_csv(LABELED_CSV, index=False, encoding="utf-8")
    print(f"  标注结果: {LABELED_CSV}")

    # 品类分布（各 split 内 parent_cat 分布，用于「控制品类分布」报告）
    cat_dist = {}
    for sp in ["train", "val", "test"]:
        sub = pdf[pdf["split"] == sp]
        cat_dist[sp] = sub["parent_cat"].value_counts().head(20).to_dict()
    with open(LABEL_DIST_JSON, "w", encoding="utf-8") as f:
        json.dump({
            "total_sampled": int(n), "label_counts": {str(k): int(v) for k, v in dist.items()},
            "split_counts": split_cnt, "parent_cat_dist_by_split": cat_dist,
        }, f, ensure_ascii=False, indent=2)
    print(f"  分布报告: {LABEL_DIST_JSON}")

    spark.stop()
    print("\n弱监督标注完成")


if __name__ == "__main__":
    main()
