#!/bin/bash
# ================================================================
# Rec-Tmall 评论口碑情感分析与建模预测 — 一键运行脚本
# 顺序: 词频基线 → 弱监督标注 → 特征工程 → 模型训练 → 全量推理 → 关键词+报告
# ================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

echo "=============================================="
echo "  Rec-Tmall 评论口碑情感分析与建模预测"
echo "  数据规模: 1122万评论 | 23.8万词 | 300k 弱标注样本"
echo "=============================================="
echo ""

source venv/bin/activate

# ── Step 1: 词频基线 + 情感词典 ──
echo ">>> [1/6] 全量词频基线 + 情感词典构建..."
python scripts/sentiment/lexicon.py
echo ""

# ── Step 2: 弱监督标注 ──
echo ">>> [2/6] 评论预处理 + 弱监督标注..."
python scripts/sentiment/weak_label.py
echo ""

# ── Step 3: 特征工程 ──
echo ">>> [3/6] 特征工程（BOW/TF-IDF/Bigram + 统计 + 品类）..."
python scripts/sentiment/features.py
echo ""

# ── Step 4: 模型训练调优评估 ──
echo ">>> [4/6] 三模型基线训练 + 调优 + 分品类评估..."
python scripts/sentiment/train.py
echo ""

# ── Step 5: 全量推理 + 口碑聚合 ──
echo ">>> [5/6] 全量 1122万 评论推理 + item/品类口碑聚合..."
python scripts/sentiment/infer.py
echo ""

# ── Step 6: 关键词提炼 + 报告 ──
echo ">>> [6/6] 核心关键词提炼 + 报告生成..."
python scripts/sentiment/keywords.py
python scripts/sentiment/report.py
echo ""

echo "=============================================="
echo "  分析完成!"
echo ""
echo "  交付物:"
echo "    reports/sentiment/comment_reputation_analysis_report.html — 综合报告"
echo "    data/sentiment/model/best_model.pkl                — 最优模型"
echo "    data/sentiment/model/model_report.json             — 三模型对比"
echo "    data/sentiment/model/per_category_f1.csv           — 分品类泛化"
echo "    data/sentiment/model/confusion_matrix.png          — 混淆矩阵"
echo "    data/sentiment/output/item_reputation.csv          — 商品级口碑表"
echo "    data/sentiment/output/parent_cat_reputation.csv    — 一级类目口碑排名"
echo "    data/sentiment/output/leaf_cat_reputation.csv      — 叶子类目口碑排名"
echo "    data/sentiment/output/global_pos_words.csv         — 全域正向核心词"
echo "    data/sentiment/output/global_neg_words.csv         — 全域负向核心词"
echo "    data/sentiment/output/per_category_keywords.csv    — 分品类核心词"
echo "=============================================="
