"""
情感分类模型训练 / 调优 / 评估
=============================
三模型基线对比 + 样本不平衡处理 + 验证集调优 + 测试集评估 + 分品类泛化验证

模型与特征对应（见 features.py）：
  朴素贝叶斯  MultinomialNB          ← X_bow   （词袋计数）
  逻辑回归    LogisticRegression     ← X_tfidf （TF-IDF + 词典 + 品类）
  LightGBM    LGBMClassifier         ← X_dense （词典 + 品类 + SVD 文本）

不平衡处理：LR / NB / LightGBM 用 class_weight='balanced'（加权损失）；
             训练前打印正负比并在报告记录。

评估：准确率 / 精确率 / 召回率 / F1（macro + 正负各类），分 parent_cat 泛化 F1。

输出（data/sentiment/model/）:
  best_model.pkl            # 最优模型
  model_report.json         # 三模型对比 + 最优超参 + 分品类表现
  per_category_f1.csv       # 分品类泛化 F1
  coef_nb.pkl / coef_lr.pkl # 特征系数（供关键词分析）

用法: python scripts/sentiment/train.py
"""
import os, sys, time, json, pickle
import numpy as np
import pandas as pd
import scipy.sparse as sparse
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from lightgbm import LGBMClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score, classification_report, confusion_matrix)

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.config import *

FEAT_DIR = SENTIMENT_FEATURES_DIR
MODEL_DIR = SENTIMENT_MODEL_DIR


def load_features():
    """加载 features.py 产出的特征矩阵 + 标签 + meta"""
    data = {}
    for sp in ["train", "val", "test"]:
        data[sp] = {
            "bow": sparse.load_npz(os.path.join(FEAT_DIR, f"X_bow_{sp}.npz")),
            "tfidf": sparse.load_npz(os.path.join(FEAT_DIR, f"X_tfidf_{sp}.npz")),
            "dense": np.load(os.path.join(FEAT_DIR, f"X_dense_{sp}.npy")),
            "y": np.load(os.path.join(FEAT_DIR, f"y_{sp}.npy")),
            "meta": pd.read_csv(os.path.join(FEAT_DIR, f"meta_{sp}.csv")),
        }
    with open(os.path.join(FEAT_DIR, "vectorizers.pkl"), "rb") as f:
        vec = pickle.load(f)
    return data, vec


def _metrics(y_true, y_pred, y_prob=None):
    m = {
        "accuracy": round(accuracy_score(y_true, y_pred), 4),
        "precision": round(precision_score(y_true, y_pred, zero_division=0), 4),
        "recall": round(recall_score(y_true, y_pred, zero_division=0), 4),
        "f1": round(f1_score(y_true, y_pred, zero_division=0), 4),
        "f1_macro": round(f1_score(y_true, y_pred, average="macro", zero_division=0), 4),
    }
    if y_prob is not None:
        m["auc"] = round(roc_auc_score(y_true, y_prob), 4)
    return m


def _grid_search(fit_fn, grid, X_train, y_train, X_val, y_val):
    """小网格搜索，以验证集 macro-F1 择优"""
    best = None
    for params in grid:
        model = fit_fn(**params)
        model.fit(X_train, y_train)
        val_f1 = f1_score(y_val, model.predict(X_val), average="macro", zero_division=0)
        if best is None or val_f1 > best["val_f1"]:
            best = {"model": model, "params": params, "val_f1": val_f1}
    return best


def train_all(data):
    """训练三个基线模型并调优，返回 (best_models, results)"""
    tr, va, te = data["train"], data["val"], data["test"]
    print(f"  训练集正样本占比: {tr['y'].mean()*100:.1f}%，测试集: {te['y'].mean()*100:.1f}%")

    # ── 朴素贝叶斯（词袋）──
    print("  [1/3] 朴素贝叶斯（词袋）...")
    nb = _grid_search(
        lambda alpha: MultinomialNB(alpha=alpha),
        [{"alpha": a} for a in [0.1, 0.5, 1.0, 2.0]],
        tr["bow"], tr["y"], va["bow"], va["y"])

    # ── 逻辑回归（TF-IDF + 词典 + 品类）──
    print("  [2/3] 逻辑回归（TF-IDF）...")
    lr = _grid_search(
        lambda C: LogisticRegression(C=C, solver="liblinear", max_iter=1000,
                                     class_weight="balanced", random_state=42),
        [{"C": c} for c in [0.1, 1.0, 10.0]],
        tr["tfidf"], tr["y"], va["tfidf"], va["y"])

    # ── LightGBM（稠密：词典 + 品类 + SVD）──
    print("  [3/3] LightGBM（稠密：词典 + 品类 + SVD）...")
    lgbm = _grid_search(
        lambda lr, n_est, leaves: LGBMClassifier(
            learning_rate=lr, n_estimators=n_est, num_leaves=leaves,
            class_weight="balanced", n_jobs=-1, random_state=42, verbosity=-1),
        [{"lr": l, "n_est": n, "leaves": lv}
         for l in [0.05, 0.1] for n in [200, 400] for lv in [31, 63]],
        tr["dense"], tr["y"], va["dense"], va["y"])

    return {"nb": nb, "lr": lr, "lgbm": lgbm}


def evaluate_on_test(best_models, data):
    """测试集评估（含 AUC + 混淆矩阵）+ 分品类泛化"""
    te = data["test"]
    results = {}
    per_cat_rows = []
    conf_mats = {}

    for name, feat_key in [("nb", "bow"), ("lr", "tfidf"), ("lgbm", "dense")]:
        model = best_models[name]["model"]
        X_te = te[feat_key]
        y_pred = model.predict(X_te)
        y_prob = model.predict_proba(X_te)[:, 1]
        m = _metrics(te["y"], y_pred, y_prob)
        m["params"] = best_models[name]["params"]
        m["val_f1"] = round(best_models[name]["val_f1"], 4)
        results[name] = m
        conf_mats[name] = confusion_matrix(te["y"], y_pred)

        # 分品类泛化 F1
        meta = te["meta"].copy()
        meta["y_pred"] = y_pred
        for cat, g in meta.groupby("parent_cat"):
            if len(g) >= 50 and g["label"].nunique() == 2:   # 样本够且两类都有
                per_cat_rows.append({
                    "model": name, "parent_cat": cat, "n": len(g),
                    "f1": round(f1_score(g["label"], g["y_pred"], zero_division=0), 4),
                    "pos_rate": round(g["label"].mean(), 3),
                })

    per_cat_df = pd.DataFrame(per_cat_rows)
    return results, per_cat_df, conf_mats


def main():
    os.makedirs(MODEL_DIR, exist_ok=True)
    t0 = time.time()
    print("=" * 60)
    print("情感分类模型训练 / 调优 / 评估")
    print("=" * 60)

    data, vec = load_features()
    best = train_all(data)
    results, per_cat_df, conf_mats = evaluate_on_test(best, data)

    # ── 打印对比 ──
    print("\n  " + "-" * 78)
    print(f"  {'模型':<8} {'acc':>8} {'prec':>8} {'recall':>8} {'f1':>8} {'f1_macro':>9} {'auc':>8}  最优超参")
    print("  " + "-" * 78)
    for name, m in results.items():
        print(f"  {name:<8} {m['accuracy']:>8} {m['precision']:>8} {m['recall']:>8} "
              f"{m['f1']:>8} {m['f1_macro']:>9} {m['auc']:>8}  {m['params']}")
    print("  " + "-" * 78)

    # 最优模型（按测试集 macro-F1）
    best_name = max(results, key=lambda k: results[k]["f1_macro"])
    print(f"  最优模型: {best_name}（测试集 macro-F1 = {results[best_name]['f1_macro']}）")

    # ── 分品类表现 ──
    if len(per_cat_df):
        weak = per_cat_df[per_cat_df["model"] == best_name].sort_values("f1").head(10)
        print(f"\n  最优模型分品类泛化（{best_name}，样本>=50 的品类 {len(per_cat_df[per_cat_df['model']==best_name])} 个）:")
        print(f"    薄弱品类 Top10（F1 最低）:")
        for _, r in weak.iterrows():
            print(f"      parent_cat={r['parent_cat']:<6} n={r['n']:<6} f1={r['f1']}  pos_rate={r['pos_rate']}")

    # ── 混淆矩阵图 ──
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    for _name in ["PingFang SC", "Hiragino Sans GB", "STHeiti", "Arial Unicode MS", "Heiti SC"]:
        if _name in {f.name for f in font_manager.fontManager.ttflist}:
            plt.rcParams["font.sans-serif"] = [_name]
            break
    plt.rcParams["axes.unicode_minus"] = False
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.5))
    for ax, (name, cm) in zip(axes, conf_mats.items()):
        im = ax.imshow(cm, cmap="Blues")
        ax.set_title(f"{name} 混淆矩阵")
        ax.set_xticks([0, 1]); ax.set_yticks([0, 1])
        ax.set_xlabel("预测"); ax.set_ylabel("真实")
        for i in range(2):
            for j in range(2):
                ax.text(j, i, str(cm[i, j]), ha="center", va="center", fontsize=14)
    fig.colorbar(im, ax=axes, fraction=0.02)
    fig.tight_layout()
    cm_path = os.path.join(MODEL_DIR, "confusion_matrix.png")
    fig.savefig(cm_path, dpi=120)
    plt.close(fig)
    print(f"  混淆矩阵: {cm_path}")

    # ── 落盘 ──
    best_model = best[best_name]["model"]
    with open(os.path.join(MODEL_DIR, "best_model.pkl"), "wb") as f:
        pickle.dump({"name": best_name, "model": best_model}, f)

    report = {
        "best_model": best_name,
        "class_distribution": {"train_pos_rate": round(float(data["train"]["y"].mean()), 4),
                               "test_pos_rate": round(float(data["test"]["y"].mean()), 4)},
        "models": results,
    }
    with open(os.path.join(MODEL_DIR, "model_report.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    per_cat_df.to_csv(os.path.join(MODEL_DIR, "per_category_f1.csv"), index=False)

    # 系数落盘（供关键词分析：LR 系数对应 TF-IDF 前 tfidf_n_cols 列）
    if "lr" in best:
        with open(os.path.join(MODEL_DIR, "coef_lr.pkl"), "wb") as f:
            pickle.dump(best["lr"]["model"].coef_, f)
    if "nb" in best:
        with open(os.path.join(MODEL_DIR, "coef_nb.pkl"), "wb") as f:
            pickle.dump(best["nb"]["model"].feature_log_prob_, f)

    print(f"\n  输出: {MODEL_DIR}/best_model.pkl, model_report.json, per_category_f1.csv")
    print(f"  总耗时 {time.time() - t0:.1f}s")


if __name__ == "__main__":
    main()
