"""
全量评论推理 + 商品/品类口碑聚合
==============================
1. 加载最优模型 + 特征向量器（features.py / train.py 产出）
2. 对全量 11M 评论 mapInPandas 批量推理，输出每条评论的情感标签 + 预测置信度
3. 聚合：
   - item 级口碑表：总评论数 / 正负评论数 / 正向率 / 综合情感得分 / 高置信负面占比
   - parent_cat / leaf_cat 品类级口碑指标与排名

输出（data/sentiment/output/）:
  review_pred.parquet        # 每条评论预测（item_id/user_id/label/prob/类目）
  item_reputation.csv        # 商品级口碑特征表
  parent_cat_reputation.csv  # 一级类目口碑排名
  leaf_cat_reputation.csv    # 叶子类目口碑排名

用法: python scripts/sentiment/infer.py
"""
import os, sys, time, json, pickle
import numpy as np
import pandas as pd
import scipy.sparse as sparse
from pyspark.sql import functions as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.config import *
from scripts.sentiment.lexicon_data import all_lexicon, STOPWORDS
from scripts.sentiment.weak_label import preprocess_tokens
from scripts.sentiment.features import TOPIC_WORDS, _topic_coverage

FEAT_DIR = SENTIMENT_FEATURES_DIR
MODEL_DIR = SENTIMENT_MODEL_DIR
OUT_DIR = SENTIMENT_OUTPUT_DIR

REVIEW_PRED_PATH = os.path.join(OUT_DIR, "review_pred.parquet")
HIGH_CONF_NEG_THRESHOLD = 0.2   # P(正向) < 0.2 视为「高置信负面」


def load_bundle():
    with open(os.path.join(MODEL_DIR, "best_model.pkl"), "rb") as f:
        best = pickle.load(f)
    with open(os.path.join(FEAT_DIR, "vectorizers.pkl"), "rb") as f:
        vec = pickle.load(f)
    return {"name": best["name"], "model": best["model"], "vec": vec,
            "lex": all_lexicon(), "stopwords": STOPWORDS}


def _basic_feature_matrix(tok_lists):
    """基础统计特征（3 列，顺序与 features.build_basic_features 一致）"""
    n_tok = tok_lists.apply(len)
    unique = tok_lists.apply(lambda ts: len(set(ts)))
    tcov = tok_lists.apply(_topic_coverage)
    return np.column_stack([n_tok.values, unique.values, tcov.values])


def _category_feature_matrix(pdf, vec):
    """品类 one-hot，与 features.build_category_features 一致"""
    pc = pdf["parent_cat"].astype(str).values.reshape(-1, 1)
    top = vec["top_leafs"]
    lc = pdf["leaf_cat"].apply(lambda x: str(x) if x in top else "other").values.reshape(-1, 1)
    return vec["cat_encoder"].transform(np.hstack([pc, lc]))


def _predict_batch(b, pdf):
    """对一批评论做特征变换 + 预测，返回 (label, prob)"""
    name, model, vec = b["name"], b["model"], b["vec"]
    lex, stopwords = b["lex"], b["stopwords"]

    tok_lists = pdf["feedback"].apply(lambda s: preprocess_tokens(s, stopwords))
    clean = tok_lists.apply(lambda ts: " ".join(ts))
    basic_feats = _basic_feature_matrix(tok_lists)
    cat_feats = _category_feature_matrix(pdf, vec)

    if name == "nb":
        X = vec["bow"].transform(clean)
    elif name == "lr":
        X = sparse.hstack([vec["tfidf"].transform(clean),
                           sparse.csr_matrix(basic_feats),
                           sparse.csr_matrix(cat_feats)]).tocsr()
    elif name in ("gbdt", "lgbm"):
        text_svd = vec["svd"].transform(vec["tfidf"].transform(clean))
        X = np.hstack([basic_feats, cat_feats, text_svd])
    else:
        raise ValueError(f"未知模型: {name}")

    prob = model.predict_proba(X)[:, 1]
    out = pdf[["item_id", "user_id", "parent_cat", "leaf_cat"]].copy()
    out["label"] = (prob > 0.5).astype(int)
    out["prob"] = prob
    return out


def main():
    spark = create_spark("Sentiment-Infer")
    spark.conf.set("spark.sql.execution.arrow.maxRecordsPerBatch", "50000")
    os.makedirs(OUT_DIR, exist_ok=True)
    t0 = time.time()
    print("=" * 60)
    print("全量评论推理 + 口碑聚合")
    print("=" * 60)

    bundle = load_bundle()
    print(f"  最优模型: {bundle['name']}")
    bc = spark.sparkContext.broadcast(bundle)

    # ── 读取全量 review + 品类 ──
    print("  读取全量 review 并关联品类...")
    review = spark.read.parquet(CLEANED_FILES["review"])
    product = spark.read.parquet(CLEANED_FILES["product"]).select(
        "item_id",
        F.split(F.col("category"), "-").getItem(0).cast("int").alias("parent_cat"),
        F.split(F.col("category"), "-").getItem(1).cast("int").alias("leaf_cat"),
    )
    df = review.join(product, "item_id", "left").fillna(-1, subset=["parent_cat", "leaf_cat"])
    n_total = df.count()
    print(f"  评论总数: {n_total:,}")

    # ── mapInPandas 批量推理 ──
    print("  批量推理中（mapInPandas）...")
    out_schema = "item_id int, user_id string, parent_cat int, leaf_cat int, label int, prob double"

    def predict_iter(iterator):
        b = bc.value
        for pdf in iterator:
            yield _predict_batch(b, pdf)

    pred = df.select("item_id", "user_id", "feedback", "parent_cat", "leaf_cat") \
             .mapInPandas(predict_iter, out_schema)
    pred.write.mode("overwrite").option("compression", "snappy").parquet(REVIEW_PRED_PATH)
    pred = spark.read.parquet(REVIEW_PRED_PATH)   # 落盘后重读，避免重复计算
    print(f"  推理完成，耗时 {time.time() - t0:.1f}s")

    # ── 聚合口径 ──
    def reputation(df, key_cols):
        return df.groupBy(key_cols).agg(
            F.count("*").alias("review_cnt"),
            F.sum("label").alias("pos_cnt"),
            (F.count("*") - F.sum("label")).alias("neg_cnt"),
            (F.sum("label") / F.count("*")).alias("pos_rate"),
            F.avg("prob").alias("avg_sentiment"),
            (F.sum(F.when(F.col("prob") < HIGH_CONF_NEG_THRESHOLD, 1).otherwise(0)) / F.count("*")).alias("high_conf_neg_rate"),
        )

    # item 级口碑表
    print("  聚合 item 级口碑表...")
    item_rep = reputation(pred, ["item_id", "parent_cat", "leaf_cat"])
    item_rep.orderBy(F.desc("review_cnt")).toPandas().to_csv(
        os.path.join(OUT_DIR, "item_reputation.csv"), index=False, encoding="utf-8")

    # parent / leaf 品类级
    print("  聚合品类级口碑...")
    parent_rep = reputation(pred, ["parent_cat"])
    parent_rep.orderBy(F.desc("pos_rate")).toPandas().to_csv(
        os.path.join(OUT_DIR, "parent_cat_reputation.csv"), index=False, encoding="utf-8")

    leaf_rep = reputation(pred, ["leaf_cat"])
    leaf_rep.orderBy(F.desc("pos_rate")).toPandas().to_csv(
        os.path.join(OUT_DIR, "leaf_cat_reputation.csv"), index=False, encoding="utf-8")

    # 汇总统计
    agg = pred.agg(
        F.count("*").alias("total"),
        F.avg("label").alias("overall_pos_rate"),
        F.avg("prob").alias("overall_avg_sentiment"),
    ).collect()[0]
    print(f"\n  全量口碑概览:")
    print(f"    评论总数: {agg['total']:,}")
    print(f"    整体正向率: {agg['overall_pos_rate']*100:.1f}%")
    print(f"    整体综合情感得分: {agg['overall_avg_sentiment']:.3f}")

    with open(os.path.join(OUT_DIR, "infer_summary.json"), "w", encoding="utf-8") as f:
        json.dump({"total": int(agg["total"]),
                   "pos_rate": round(float(agg["overall_pos_rate"]), 4),
                   "avg_sentiment": round(float(agg["overall_avg_sentiment"]), 4)}, f)

    spark.stop()
    print(f"\n  推理 + 聚合完成，总耗时 {time.time() - t0:.1f}s")
    print(f"  输出: {OUT_DIR}/")


if __name__ == "__main__":
    main()
