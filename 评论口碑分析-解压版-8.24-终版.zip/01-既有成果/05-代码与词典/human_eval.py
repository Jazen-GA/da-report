"""
人工金标评估脚本
================
对 human_check.csv 的人工标注结果做闭环评估，量化弱监督标注的基线准确率。

这是情感分析地基的验收环节：弱监督标签来自词典规则，模型学的就是这些标签。
只有用独立人工金标验证了「标注基线准确率」，后面的模型指标才有意义。

用法：
1. 打开 data/sentiment/samples/human_check.csv
2. 新增一列 human_label（0 = 负向，1 = 正向），逐条人工判断
   - 只对明确正 / 负的填 0 或 1，拿不准的留空（不参与准确率分母）
3. 运行: python scripts/sentiment/human_eval.py
4. 输出:
   human_eval_report.json   # 准确率 / 混淆 / 分品类
   human_eval_errors.csv    # 弱标注判错样例（供修正词典边界）

输出目录: data/sentiment/samples/
"""
import os, sys, json
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.config import SENTIMENT_SAMPLES_DIR

HUMAN_CHECK_CSV = os.path.join(SENTIMENT_SAMPLES_DIR, "human_check.csv")
REPORT_JSON = os.path.join(SENTIMENT_SAMPLES_DIR, "human_eval_report.json")
ERRORS_CSV = os.path.join(SENTIMENT_SAMPLES_DIR, "human_eval_errors.csv")


def main():
    if not os.path.exists(HUMAN_CHECK_CSV):
        print(f"未找到 {HUMAN_CHECK_CSV}，请先运行 weak_label.py 生成。")
        return

    df = pd.read_csv(HUMAN_CHECK_CSV, dtype={"item_id": int, "parent_cat": int})

    if "human_label" not in df.columns:
        print("=" * 60)
        print("human_check.csv 还没有 human_label 列，请先完成人工标注：")
        print("=" * 60)
        print("1. 用 Excel / Numbers 打开 human_check.csv")
        print("2. 新增一列 human_label：0=负向，1=正向")
        print("3. 逐条判断 feedback 的情感，拿不准留空")
        print("4. 保存后运行本脚本")
        print(f"\n当前样本: {len(df):,} 条（正 {int((df['label'] == 1).sum())} / 负 {int((df['label'] == 0).sum())}）")
        return

    # 只统计已标注（非空）的行
    df = df.copy()
    df["human_label"] = pd.to_numeric(df["human_label"], errors="coerce")
    labeled = df[df["human_label"].notna()].copy()
    labeled["human_label"] = labeled["human_label"].astype(int)

    n_total = len(df)
    n_labeled = len(labeled)
    print("=" * 60)
    print(f"人工金标评估：总样本 {n_total:,}，已标注 {n_labeled:,}（{n_labeled / n_total * 100:.1f}%）")
    print("=" * 60)

    if n_labeled < 50:
        print(f"已标注 {n_labeled} 条 < 50，样本太少，无法得到稳定估计。请至少标注 1000 条。")
        return

    weak = labeled["label"].astype(int).values
    human = labeled["human_label"].values

    # 整体准确率
    acc = (weak == human).mean()

    # 混淆矩阵：行 = 弱标注，列 = 人工
    conf = {
        "弱标正_人工正": int(((weak == 1) & (human == 1)).sum()),
        "弱标正_人工负": int(((weak == 1) & (human == 0)).sum()),
        "弱标负_人工正": int(((weak == 0) & (human == 1)).sum()),
        "弱标负_人工负": int(((weak == 0) & (human == 0)).sum()),
    }
    # 分极性准确率（= 各类别精度）
    pos_prec = conf["弱标正_人工正"] / max(1, conf["弱标正_人工正"] + conf["弱标正_人工负"])
    neg_prec = conf["弱标负_人工负"] / max(1, conf["弱标负_人工正"] + conf["弱标负_人工负"])
    # 分极性召回率
    pos_rec = conf["弱标正_人工正"] / max(1, conf["弱标正_人工正"] + conf["弱标负_人工正"])
    neg_rec = conf["弱标负_人工负"] / max(1, conf["弱标负_人工负"] + conf["弱标正_人工负"])

    report = {
        "n_total": n_total,
        "n_labeled": n_labeled,
        "accuracy": round(float(acc), 4),
        "confusion": conf,
        "positive_precision": round(float(pos_prec), 4),
        "negative_precision": round(float(neg_prec), 4),
        "positive_recall": round(float(pos_rec), 4),
        "negative_recall": round(float(neg_rec), 4),
    }

    # 分品类准确率（样本量 >= 20 的品类）
    per_cat = []
    for cat, g in labeled.groupby("parent_cat"):
        if len(g) >= 20:
            per_cat.append({
                "parent_cat": int(cat),
                "n": len(g),
                "accuracy": round(float((g["label"].astype(int) == g["human_label"]).mean()), 4),
            })
    per_cat = sorted(per_cat, key=lambda x: x["accuracy"])
    report["per_category"] = per_cat

    print(f"  弱监督标注整体准确率: {acc * 100:.2f}%")
    print(f"  正向预测精度: {pos_prec * 100:.2f}%  |  负向预测精度: {neg_prec * 100:.2f}%")
    print(f"  正向召回: {pos_rec * 100:.2f}%  |  负向召回: {neg_rec * 100:.2f}%")
    print(f"  混淆矩阵（行=弱标注, 列=人工）:")
    print(f"    正→正 {conf['弱标正_人工正']:<6}  正→负 {conf['弱标正_人工负']:<6}")
    print(f"    负→正 {conf['弱标负_人工正']:<6}  负→负 {conf['弱标负_人工负']:<6}")

    if per_cat:
        print(f"\n  分品类准确率（最低 5 个，样本>=20）:")
        for r in per_cat[:5]:
            print(f"    parent_cat={r['parent_cat']:<5} n={r['n']:<5} acc={r['accuracy'] * 100:.1f}%")

    # 误判样例导出
    errors = labeled[weak != human][["item_id", "feedback", "parent_cat", "label", "human_label"]]
    errors.to_csv(ERRORS_CSV, index=False, encoding="utf-8")
    print(f"\n  误判样例 {len(errors):,} 条 → {ERRORS_CSV}")
    print(f"  （建议人工过一遍误判样例，据此修正 lexicon_data.py 的词典边界）")

    with open(REPORT_JSON, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print(f"  评估报告 → {REPORT_JSON}")

    # 阈值判断
    if acc >= 0.90:
        print("\n  结论: 标注基线准确率 >= 90%，达到可用标准。")
    elif acc >= 0.80:
        print("\n  结论: 标注基线准确率 80-90%，基本可用，建议修正误判样例中的词典边界后复评。")
    else:
        print("\n  结论: 标注基线准确率 < 80%，需重点修正词典规则再复评。")


if __name__ == "__main__":
    main()
