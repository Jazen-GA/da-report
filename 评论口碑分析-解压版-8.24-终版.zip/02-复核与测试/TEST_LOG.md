# 测试与复核日志（补救后 v2）

## 本轮补救动作

| 动作 | 结果 |
|---|---|
| 安装 libomp（brew） | PASS，lightgbm 4.6.0 可正常 import |
| 训练真实 LightGBM（替换 HistGradientBoosting） | PASS，测试集 macro-F1 0.8742 |
| 修复 config.py 的 PYSPARK_PYTHON（Spark worker 缺 pandas 的根因） | PASS，全量推理端到端重跑成功 |
| 补齐 vectorizers.pkl / review_pred.parquet / config.py / human_check.csv | PASS |
| 产出 train.log / infer.log | PASS |
| 修复混淆矩阵中文字体 | PASS |
| 提供 human_eval.py 金标评估工作流 | PASS，待真人标注后运行 |

## 自动检查

| 检查项 | 状态 | 结果 |
|---|---|---|
| Python 代码语法编译 | PASS | 检查 9 个 .py 文件（含新增 human_eval.py） |
| LightGBM import | PASS | libomp 22.1.8 + lightgbm 4.6.0 |
| 三模型训练 | PASS | NB / LR / LightGBM 均产出，最优 LR |
| 全量推理端到端重跑 | PASS | 11,201,322 条，耗时 56.4s |
| 聚合计数三层对账 | PASS | item / parent / leaf 均为 11,201,322 |
| JSON 可解析性 | PASS | infer_summary.json 与 model_report.json 可解析 |
| 人工金标评估 | PASS | 1000 条真人标注，弱监督基线准确率 83.70% |

## 关键复核数

- 评论总数：11,201,322
- 商品数：5,071,049
- 整体正向率：85.18%
- 综合情感得分：0.841
- 高置信负面占比：10.10%（口径：P(正向) < 0.2）
- 最优模型：逻辑回归，测试集 macro-F1 0.9232
- LightGBM：测试集 macro-F1 0.8742（真实 LGBMClassifier）

## 模型对比（弱监督测试集）

| 模型 | Accuracy | Precision | Recall | F1 | Macro-F1 | AUC |
|---|---|---|---|---|---|---|
| 朴素贝叶斯 | 0.9277 | 0.9715 | 0.9484 | 0.9598 | 0.8007 | 0.9475 |
| 逻辑回归 | 0.9729 | 0.9934 | 0.9767 | 0.9850 | 0.9232 | 0.9919 |
| LightGBM | 0.9555 | 0.9841 | 0.9667 | 0.9753 | 0.8742 | 0.9797 |

## 仍待完成（遗留项）

1. ~~人工金标~~ 已完成：1000 条真人标注，弱监督基线准确率 83.70%（详见 human_eval_report.json）。
2. **情感词典特征消融**：任务 a.2 要求词典特征，但因防泄漏未入模型，需在人工金标上补消融。
3. **品类分层 + item_id 分组切分**：当前仅按 label 分层，存在小品类漂移与同商品跨集合风险。
4. **过采样/欠采样组合**：当前仅用 class_weight，未实现采样组合方案。

这些遗留项如实保留，不以虚构数据或伪日志填充。
