# 评论口碑分析与建模预测 - 复核交付说明（补救后 v2）

本包在原始交付基础上完成了一轮补救：安装 libomp 后训练真实 LightGBM、修复 Spark worker 环境导致的端到端重跑失败、补齐可复现推理所需的向量器与逐条预测、并给出人工金标评估工作流。

## 目录结构

- `01-既有成果/01-报告`：HTML 报告及图表（已含真实 LightGBM 三模型对比）。
- `01-既有成果/02-口碑数据`：商品 / 一级类目 / 叶子类目口碑聚合表 + 全量逐条预测 review_pred.parquet。
- `01-既有成果/03-核心关键词`：全域与分品类核心词、主题归类。
- `01-既有成果/04-模型资产`：最优逻辑回归模型、LightGBM 系数、特征向量器 vectorizers.pkl、模型报告。
- `01-既有成果/05-代码与词典`：清洗、弱监督、特征、训练（NB/LR/LightGBM）、推理、报告、金标评估代码 + 情感词典 + config.py。
- `02-复核与测试`：质量门禁、测试日志、聚合对账、运行日志（train.log / infer.log）。
- `03-金标与样本`：人工校验抽样 human_check.csv（正负各 1500 条）。

## 本轮补救结论

- 三模型（朴素贝叶斯 / 逻辑回归 / **真实 LightGBM**）训练完成，最优为逻辑回归，弱监督测试集 Macro-F1 0.9232。
- LightGBM（LGBMClassifier）测试集 Macro-F1 0.8742，满足任务指定的 LightGBM 基线。
- 修复 `config.py` 的 `PYSPARK_PYTHON` 设置后，全量 11,201,322 条评论端到端推理重跑成功（56.4s）。
- 补齐 `vectorizers.pkl` + `best_model.pkl` + `config.py`，可仅凭 feedback 复现逐条预测。
- item / parent / leaf 三层计数对账一致（11,201,322）。

## 人工金标已完成

弱监督标注基线准确率 **83.70%**（人工标注 1000 条，正 526 / 负 474）。正向 precision 87.42% / 负向 precision 80.19% / 负向 recall 87.13%。模型 macro-F1 0.9232 衡量的是复现词典规则的能力，真实情感判断上限约 84%。误判样例见 `03-金标与样本/human_eval_errors.csv`。

## 遗留 MAJOR（如实保留，未在本次补救内）

- 情感词典特征（防泄漏的主动设计，需在金标上补消融）。
- 品类分层划分（当前仅按 label 分层）。
- 过采样 / 欠采样组合方案（当前仅 class_weight）。

## 运行环境

- 依赖见 `requirements-reference.txt`。
- 复现需接入原工程 `data/cleaned/` 下的 review / product parquet（原始数据未随包）。
- 代码运行结构：`scripts/config.py` + `scripts/sentiment/*.py`，需将 `05-代码与词典` 下的文件按此结构放回项目目录。

## 关于 PDF 报告

`评论口碑分析与建模预测报告.pdf`（2026-08-24 17:45 生成）为初版审计快照，其中关于「LightGBM 缺失」「可复用模型包 BLOCKER 未通过」等结论已在本轮补救后失效。最新结论以本包内 `评论口碑分析明细与模型评估.xlsx`、`02-复核与测试` 下的质量门禁 / 测试日志、以及 `01-既有成果/04-模型资产/model_report.json` 为准。
