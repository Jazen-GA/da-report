# Rec-Tmall 用户价值画像与流失复购预测 · 交付物

Rec-Tmall 天池数据集（商品 813 万 / 日志 ~12.6 亿行 / 评论 1122 万 / 用户 965 万）数据分析的
「用户价值画像 + 生命周期预测」模块交付。对应任务清单 5 项最终交付物。

## 目录结构

| 目录 | 对应任务 | 内容 |
|---|---|---|
| `01_用户画像标签与价值分层/` | 任务 1、2 | 标签宽表样本 + 标签字典 + RFM 分层结果 + 价值分层画像报告 |
| `02_流失预测模型/` | 任务 3 | 流失二分类模型（LR/XGB）+ 评估指标 + 特征重要性 + 高流失风险清单 |
| `03_复购预测模型/` | 任务 4 | 复购概率模型 + 复购周期模型 + 评估指标 + 高复购潜力清单 |
| `04_特征工程文档/` | 任务 3、4 | 特征字典 + 数据泄露检查报告 |
| `05_生命周期运营报告/` | 任务 5 | 综合运营建议 HTML + 全量用户预测结果 |
| `06_流水线代码/` | — | lifecycle + user_value 全部脚本，可复现 |

## 关键指标（limit 档，10% 用户抽样）

### 流失预测（best = XGBoost，test）
| 模型 | AUC | Precision | Recall | F1 |
|---|---|---|---|---|
| LR | 0.7429 | 0.8608 | 0.8231 | 0.8415 |
| **XGB** | **0.7471** | 0.8506 | 0.7254 | 0.7830 |

### 复购概率（best = LR，test）
| 模型 | AUC | Precision | Recall | F1 |
|---|---|---|---|---|
| **LR** | **0.7285** | 0.4510 | 0.4671 | 0.4589 |
| XGB | 0.6501 | 0.3551 | 0.4190 | 0.3844 |

### 复购周期（回归，test）
| 模型 | MAE | RMSE |
|---|---|---|
| **XGB** | **7.45** | 8.62 |
| LGB | 7.50 | 8.68 |

### 数据泄露检查
`04_特征工程文档/leakage_report.json`：流失断面时间隔离 / 复购首购窗口 / 时序切分均 `ok: true`，无泄露。

## 输出清单规模（limit 档）
- 高流失风险清单：67.8 万条（`churn_risk_list.csv`，含 value_tier 分层）
- 高价值高流失风险子清单：`churn_high_value_risk_list.csv`
- 高复购潜力清单：3.1 万条（`repurchase_potential_list.csv`）
- 高价值高复购潜力子清单：`repurchase_high_value_potential_list.csv`
- 全量成交用户预测：35.3 万条（`user_lifecycle_prediction.csv`，流失概率 + 复购概率 + 预计复购天数）
- 分品类复购周期基准：`category_repurchase_cycle.csv` + 分品类效果 `repurchase_by_cat.csv`

## 复现

```bash
cd /Users/Admin/Desktop/tmall/rec-tmall
source venv/bin/activate
bash scripts/lifecycle/run_lifecycle.sh limit --skip-aggregate   # 流失 + 复购全链路
```

依赖：PySpark 4.0.4 + sklearn 1.6 + XGBoost + LightGBM（libomp 已装）。
数据源：日志 `tianchi_2014002`（主表）+ 商品 `tianchi_2014001`（类目/品牌维度）+ 评论口碑（复用已交付情感分析结果）。
