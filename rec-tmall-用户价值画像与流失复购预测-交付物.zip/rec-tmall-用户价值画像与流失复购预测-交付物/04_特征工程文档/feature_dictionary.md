# 用户生命周期预测 · 特征工程文档

流失预测 + 复购预测共用的 user 级特征体系。所有特征从 `(user, item, action_date)` 每日中间表
（`scripts/modeling/aggregate.py` 产出）+ 价值分层表（`user_value/value_score`）+ 评论情感表
（`sentiment/output/review_pred.parquet`）派生，配置驱动，换数据只改 `scripts/lifecycle/config.py`。

时间合规：历史特征用 `< pred_start`（流失）或 `< 首购日`（复购）数据，近期特征用观察窗口数据，
标签用预测窗口数据，三者无交集。

---

## 一、流失预测特征（断面制，30 天观察 + 30 天预测）

### 1. 历史稳定特征（截至 pred_start 的全历史）
| 字段 | 含义 | 口径 |
|---|---|---|
| `hist_active_days` | 历史活跃天数 | 历史 distinct action_date |
| `hist_total_actions` | 历史总行为量 | 历史 sum(total_cnt) |
| `hist_buy_cnt` | 历史购买次数 | 历史 sum(alipay_cnt)，>=1 才入样本 |
| `hist_distinct_item` | 历史购买商品数 | 历史 distinct item_id（购买） |
| `hist_buy_interval_mean` | 平均购买间隔 | 相邻购买日差值的均值 |
| `hist_buy_interval_std` | 购买间隔波动率 | 相邻购买日差值的标准差 |
| `hist_recency_days` | 末购距预测起点天数 | datediff(pred_start, 末购日) |
| `hist_buy_tenure_days` | 购买周期跨度 | 末购日 - 首购日（购买 >=2 次） |
| `value_tier` / `value_subtier` | 价值层级（运营画像） | 上周 RFM 分层，见 [[rec-tmall-project]] |

### 2. 活跃度衰减特征（观察窗口 30 天）
| 字段 | 含义 |
|---|---|
| `rec_actions_7d/14d/30d` | 近 7/14/30 天总行为量 |
| `rec_buy_7d/14d/30d` | 近 7/14/30 天购买量 |
| `rec_collect_cart_7d/14d/30d` | 近 7/14/30 天收藏+加购量 |
| `rec_{action}_cnt_{wd}d` | 近 wd 天各行为计数（click/collect/cart/alipay） |
| `decay_actions_14d` | 行为量下滑幅度 = (近14 - 前14)/前14 |
| `decay_buy_14d` | 购买量下滑幅度 |
| `decay_collect_cart_14d` | 收藏加购意愿衰减 |
| `days_since_last_action` | 最近行为距观察窗口末天数（连续无行为） |
| `days_since_last_buy` | 最近购买距观察窗口末天数 |

### 3. 行为结构特征
| 字段 | 含义 |
|---|---|
| `ratio_click/collect/cart/buy_30d` | 近 30 天各行为占比 |

### 4. 品类匹配特征
| 字段 | 含义 |
|---|---|
| `hist_top_cat` | 历史购买 Top1 品类（目标编码） |
| `cat_match` | 静默时长 / 品类复购周期（>1 表示静默超过该品类复购周期，流失风险高） |

---

## 二、复购预测特征（首购锚点制，首购后 30 观察 + 30 预测）

### 1. 首购行为特征
| 字段 | 含义 |
|---|---|
| `first_cat` / `first_leaf_cat` | 首购商品一级/叶子品类 |
| `first_brand` | 首购商品品牌 |
| `first_decision_path` | 首购决策路径：首购前有收藏/加购=1（决策型），否则=0（冲动型） |
| `first_consumption` | 首购消费力估算 = 品类价值权重(1~5)×品牌层级(头部3/腰部2/尾部1)×log1p(首购商品销量热度)，复用 RFM M 维度口径（无价格字段的 proxy） |

### 2. 用户基础特征（首购前）
| 字段 | 含义 |
|---|---|
| `pre_actions` | 首购前总行为量 |
| `pre_active_days` | 首购前活跃天数 |
| `pre_collect_cart` | 首购前收藏+加购量 |
| `pre_distinct_cat` | 首购前浏览品类广度 |
| `value_tier` / `value_subtier` | 价值层级（运营画像） |

### 3. 首购后互动特征（首购后 [1, 30] 天）
| 字段 | 含义 |
|---|---|
| `post_actions_7d/14d/30d` | 首购后近 7/14/30 天回访行为量 |
| `post_collect_cart_7d/14d/30d` | 首购后收藏+加购量 |
| `post_same_cat_actions` | 首购后同类商品浏览行为量 |

### 4. 口碑反馈特征（user 级评论聚合，⚠️ 已知未来泄露）
| 字段 | 含义 |
|---|---|
| `rv_cnt` | 用户累计评论条数 |
| `rv_pos_rate` | 评论正面占比 |
| `rv_avg_sentiment` | 评论平均情感分 |

> ⚠️ review 表无时间戳，「首购后是否评论」无法按首购锚点切，只能降级为全量 user 级评论聚合。
> 与 value_tier 一样属「运营画像」特征，含预测时点之后信息，对 train/val/test 均匀作用、
> 不破坏时序一致性，但高估绝对性能。实际效果以纯历史行为特征为准。

---

## 三、类别特征与目标编码

- 流失：`value_tier`、`value_subtier`（2 列）
- 复购：`value_tier`、`value_subtier`、`first_cat`、`first_leaf_cat`、`first_brand`（5 列）
- 高基数类别用 fold 内 OOF 目标编码（train 5-fold，防泄露），编码列以 `_te` 后缀进特征矩阵。

## 四、预处理

缺失填充 0 → 分位数 [0.01, 0.99] 截断 → 标准化（train 拟合 mean/std 套 val/test）→
相关性 [0.95] 筛选。全部参数只用 train 拟合，防泄露。
