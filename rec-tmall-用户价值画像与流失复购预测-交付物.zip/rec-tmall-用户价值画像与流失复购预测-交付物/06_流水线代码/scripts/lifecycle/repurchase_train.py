"""
复购预测双模型训练与评估
==========================
子任务 1 复购概率（二分类）：LR + XGBoost，AUC/召回/F1，识别高复购潜力用户。
子任务 2 复购周期（回归）：LightGBM + XGBoost regressor，MAE/RMSE，训练样本 = 已复购用户
         （label=1 且有间隔天数），预测首购 → 二次购买间隔。
分品类验证：按首购品类（first_cat）对比复购概率 AUC，识别优势/薄弱品类。

输出:
  data/lifecycle/model/repurchase/cls_{m}.joblib   复购概率模型
  data/lifecycle/model/repurchase/reg_{m}.joblib   复购周期模型
  data/lifecycle/model/repurchase/preprocess.joblib 预处理 + 目标编码（供推理）
  data/lifecycle/metrics/repurchase_metrics.json   评估指标
  data/lifecycle/metrics/repurchase_by_cat.csv     分品类复购概率 AUC
  data/lifecycle/metrics/repurchase_potential_list.csv  高复购潜力清单（test）
用法: python scripts/lifecycle/repurchase_train.py --mode debug|dev|full|limit
"""
import os
import sys
import time
import argparse
import numpy as np
import pandas as pd
import joblib

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.lifecycle.config import *
from scripts.lifecycle.train_utils import (
    load_all, numeric_cols, fit_preprocess, transform_preprocess,
    build_feature_matrix, fit_classifier, fit_regressor, compute_regression_metrics,
)
from scripts.modeling.model_utils import (
    compute_metrics, feature_importance, save_model, write_json,
    target_encode_fit, target_encode_apply_map,
)
from sklearn.metrics import roc_auc_score


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=MODES, default="dev")
    args = parser.parse_args()
    mode = args.mode

    root = REPURCHASE_DATASET_DIR
    if not os.path.isdir(os.path.join(root, mode, "train")):
        print(f"[repurchase_train] 未找到 repurchase_dataset/{mode}/train，先跑 repurchase_dataset.py。")
        return

    t0 = time.time()
    train, val, test = load_all(root, mode)
    cat_cols = REPURCHASE_CAT_COLS
    num_cols = numeric_cols(train, cat_cols)
    print(f"[repurchase_train] train {len(train):,} / val {len(val):,} / test {len(test):,}；"
          f"数值 {len(num_cols)} 列，类别 {len(cat_cols)} 列")

    for df in (train, val, test):
        df[cat_cols] = df[cat_cols].fillna("未知")

    # 预处理（train 拟合）
    params = fit_preprocess(train, num_cols)
    train = transform_preprocess(train, num_cols, params)
    val = transform_preprocess(val, num_cols, params)
    test = transform_preprocess(test, num_cols, params)

    # 目标编码（基于复购概率 label）
    y_train = train["label"].astype(float)
    X_cat_train = train[cat_cols]
    te_maps = target_encode_fit(X_cat_train, y_train, smooth=TARGET_ENCODING_SMOOTH)
    global_mean = float(y_train.mean())
    te_train = target_encode_apply_map(X_cat_train, te_maps, global_mean)
    te_val = target_encode_apply_map(val[cat_cols], te_maps, global_mean)
    te_test = target_encode_apply_map(test[cat_cols], te_maps, global_mean)

    X_train = build_feature_matrix(train, cat_cols, te_train)
    X_val = build_feature_matrix(val, cat_cols, te_val)
    X_test = build_feature_matrix(test, cat_cols, te_test)
    feature_names = list(X_train.columns)

    # ══ 子任务 1：复购概率（二分类）══
    print("\n[复购概率 二分类]")
    results_cls = {}
    best_model_name, best_auc = None, -1.0
    test_probs = {}
    for mn in ["lr", "xgb"]:
        model, _ = fit_classifier(mn, X_train, y_train, X_val, val["label"].astype(float))
        test_prob = model.predict_proba(X_test)[:, 1]
        test_probs[mn] = test_prob
        m = compute_metrics(test["label"], test_prob)
        results_cls[mn] = m
        print(f"  {mn}: test AUC={m['auc']} AP={m['ap']} recall={m['recall']} "
              f"precision={m['precision']} F1={m['f1']}")
        save_model(model, os.path.join(MODEL_DIR, "repurchase", f"cls_{mn}.joblib"))
        if m["auc"] > best_auc:
            best_auc, best_model_name = m["auc"], mn

    # ══ 子任务 2：复购周期（回归，训练样本 = 已复购用户）══
    print("\n[复购周期 回归]")
    results_reg = {}
    best_reg_name, best_rmse = None, float("inf")
    mask_tr = (train["label"] == 1).values
    mask_va = (val["label"] == 1).values
    mask_te = (test["label"] == 1).values
    X_train_reg = X_train[mask_tr]
    y_train_reg = train.loc[mask_tr, "churn_reg_label"].astype(float)
    X_val_reg = X_val[mask_va]
    y_val_reg = val.loc[mask_va, "churn_reg_label"].astype(float)
    X_test_reg = X_test[mask_te]
    y_test_reg = test.loc[mask_te, "churn_reg_label"].astype(float)
    print(f"  回归样本 train {len(X_train_reg):,} / val {len(X_val_reg):,} / test {len(X_test_reg):,}")

    if len(X_train_reg) < 10:
        print("  回归样本过少，跳过复购周期模型（样本过小）。")
    else:
        for mn in ["lgb", "xgb"]:
            model, _ = fit_regressor(mn, X_train_reg, y_train_reg, X_val_reg, y_val_reg)
            y_pred_test = model.predict(X_test_reg)
            m = compute_regression_metrics(y_test_reg, y_pred_test)
            results_reg[mn] = m
            print(f"  {mn}: test MAE={m['mae']} RMSE={m['rmse']}")
            save_model(model, os.path.join(MODEL_DIR, "repurchase", f"reg_{mn}.joblib"))
            if m["rmse"] < best_rmse:
                best_rmse, best_reg_name = m["rmse"], mn

    # 保存预处理 + 目标编码（供 infer 复用）
    preprocess_bundle = {
        "params": params, "te_maps": {k: v.to_dict() for k, v in te_maps.items()},
        "global_mean": global_mean, "num_cols": num_cols, "cat_cols": cat_cols,
        "feature_names": feature_names,
    }
    bundle_path = os.path.join(MODEL_DIR, "repurchase", "preprocess.joblib")
    os.makedirs(os.path.dirname(bundle_path), exist_ok=True)
    joblib.dump(preprocess_bundle, bundle_path)

    # ══ 分品类验证（复购概率，最优模型）══
    by_cat = test[["first_cat", "label"]].copy()
    by_cat["prob"] = test_probs[best_model_name]
    rows = []
    for cat, g in by_cat.groupby("first_cat"):
        if len(g) < 50 or g["label"].nunique() < 2:
            continue
        auc = roc_auc_score(g["label"], g["prob"])
        rows.append({"first_cat": cat, "n": len(g), "pos_rate": g["label"].mean(), "auc": round(auc, 4)})
    cat_df = pd.DataFrame(rows).sort_values("n", ascending=False)
    cat_path = os.path.join(METRICS_DIR, "repurchase_by_cat.csv")
    cat_df.to_csv(cat_path, index=False, encoding="utf-8-sig")
    print(f"\n[复购概率 分品类] 覆盖 {len(cat_df)} 个品类 -> {cat_path}")

    # ══ 高复购潜力清单（最优模型对 test 推理）══
    potential = test[["user_id", "first_cat", "value_tier", "value_subtier", "label"]].copy()
    potential["repurchase_prob"] = test_probs[best_model_name]
    if best_reg_name is not None:
        reg_model = joblib.load(os.path.join(MODEL_DIR, "repurchase", f"reg_{best_reg_name}.joblib"))
        potential["expected_interval_days"] = reg_model.predict(X_test)
    potential = potential.sort_values("repurchase_prob", ascending=False)
    pot_path = os.path.join(METRICS_DIR, "repurchase_potential_list.csv")
    potential.to_csv(pot_path, index=False, encoding="utf-8-sig")

    high_value_potential = potential[(potential["value_tier"] == "高价值") &
                                     (potential["repurchase_prob"] >= 0.5)]
    hv_path = os.path.join(METRICS_DIR, "repurchase_high_value_potential_list.csv")
    high_value_potential.to_csv(hv_path, index=False, encoding="utf-8-sig")

    write_json({
        "mode": mode,
        "best_cls_model": best_model_name,
        "best_reg_model": best_reg_name,
        "classification": results_cls,
        "regression": results_reg,
    }, os.path.join(METRICS_DIR, "repurchase_metrics.json"))

    print(f"\n[repurchase_train] 最优分类 {best_model_name} (test AUC {best_auc:.4f})，"
          f"最优回归 {best_reg_name}")
    print(f"[repurchase_train] 高复购潜力清单 {len(potential):,} 条 -> {pot_path}")
    print(f"[repurchase_train] 高价值×高复购 {len(high_value_potential):,} 条 -> {hv_path}")
    print(f"[repurchase_train] 完成, 耗时 {(time.time() - t0) / 60:.1f} 分钟")


if __name__ == "__main__":
    main()
