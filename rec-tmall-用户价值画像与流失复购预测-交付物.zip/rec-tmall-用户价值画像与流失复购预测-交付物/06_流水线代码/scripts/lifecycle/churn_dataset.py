"""
流失样本构建（标签 + 分层采样 + 时序切分）
============================================
对每个时间断面：
  - 样本空间 = 历史（pred_start 前）有过购买的成交用户（hist_buy_cnt >= 1）
  - 正样本（流失）= 预测窗口 30 天内无任何购买行为
  - 负样本（留存）= 预测窗口 30 天内有购买
  - 分层欠采样：流失占多数，按 value_tier 分层欠采样到「正:负 ≈ CHURN_POS_NEG_RATIO」
    （train/val 用；test 不采样反映自然分布）

时序合规：特征用 < pred_start 数据，标签用 [pred_start, pred_end] 数据，无交集。

输出: data/lifecycle/churn_dataset/{mode}/{train|val|test}
用法: python scripts/lifecycle/churn_dataset.py --mode debug|dev|full|limit
"""
import os
import sys
import time
import argparse
from pyspark.sql import functions as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.lifecycle.config import *
from scripts.lifecycle.features import (
    load_product, build_static, build_category_cycle, build_churn_features,
)


def _downsample_pos(pos, n_neg, ratio):
    """欠采样正样本（流失，多数类）到 n_neg * ratio，按 value_tier 分层保持代表性"""
    target = int(n_neg * ratio)
    n_pos = pos.count()
    if n_pos <= target:
        print(f"  流失样本 {n_pos:,} <= 目标 {target:,}，全量保留（不欠采样）")
        return pos
    frac = target / n_pos
    pos = pos.fillna({"value_tier": "未知"})
    strata = [r["value_tier"] for r in pos.select("value_tier").distinct().collect()]
    fractions = {s: frac for s in strata}
    sampled = pos.sampleBy("value_tier", fractions, seed=NEG_SAMPLE_SEED)
    print(f"  分层欠采样流失: {n_pos:,} -> 目标 {target:,} (比例 {frac:.3f}), 层数 {len(strata)}")
    return sampled


def build_churn_dataset(spark, mode):
    daily_path = os.path.join(DAILY_DIR, mode)
    out_root = os.path.join(CHURN_DATASET_DIR, mode)
    print(f"[churn_dataset] 读取每日中间表: {daily_path}")
    daily = spark.read.parquet(daily_path)
    product = load_product(spark)
    static = build_static(spark)
    cat_cycle = build_category_cycle(spark, daily, product).persist()
    # 落盘品类复购周期基准（供报告 + 品类运营触达时间窗口参考）
    os.makedirs(METRICS_DIR, exist_ok=True)
    cat_cycle.toPandas().to_csv(
        os.path.join(METRICS_DIR, "category_repurchase_cycle.csv"),
        index=False, encoding="utf-8-sig")

    windows = churn_slice_windows()
    all_samples = None
    for w in windows:
        slice_id = w["slice_id"]
        print(f"[churn_dataset] 断面 slice_id={slice_id} (pred {w['pred_start']}~{w['pred_end']}) 构建样本...")

        feats = build_churn_features(spark, daily, w, product, static, cat_cycle)
        # 样本空间：历史有购买的用户
        feats = feats.filter(F.col("hist_buy_cnt") >= 1)

        # 标签：预测窗口内是否有购买（有 → 留存 0，无 → 流失 1）
        pred_buy = daily.filter(
            (F.col("action_date") >= w["pred_start"]) &
            (F.col("action_date") <= w["pred_end"]) &
            (F.col(BUY_COL) > 0)
        ).select("user_id").distinct().withColumn("_retained", F.lit(1))

        samples = feats.join(pred_buy, "user_id", "left") \
            .withColumn("label", F.when(F.col("_retained") == 1, 0).otherwise(1)) \
            .drop("_retained")

        n_pos = samples.filter(F.col("label") == 1).count()
        n_neg = samples.filter(F.col("label") == 0).count()
        print(f"  样本 {n_pos + n_neg:,} (流失 {n_pos:,} / 留存 {n_neg:,})")
        if n_neg == 0 or n_pos == 0:
            print(f"  断面 slice_id={slice_id} 正/负样本缺失，跳过")
            continue

        if w["split"] != "test":
            pos = samples.filter(F.col("label") == 1)
            neg = samples.filter(F.col("label") == 0)
            pos = _downsample_pos(pos, n_neg, CHURN_POS_NEG_RATIO)
            samples = pos.unionByName(neg)

        samples = samples.withColumn("slice_id", F.lit(slice_id)) \
            .withColumn("split", F.lit(w["split"])) \
            .withColumn("pred_start", F.lit(w["pred_start"])) \
            .withColumn("obs_end", F.lit(w["obs_end"]))
        all_samples = samples if all_samples is None else all_samples.unionByName(samples)

    if all_samples is None:
        print("[churn_dataset] 所有断面均无有效样本，无法构建数据集。请用更大档位（dev/full/limit）。")
        cat_cycle.unpersist()
        return None

    for split in ["train", "val", "test"]:
        part = all_samples.filter(F.col("split") == split)
        part.write.mode("overwrite").option("compression", "snappy") \
            .parquet(os.path.join(out_root, split))
        print(f"[churn_dataset] {split}: {part.count():,} 样本 -> {os.path.join(out_root, split)}")

    cat_cycle.unpersist()
    return all_samples


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=MODES, default="dev")
    args = parser.parse_args()

    spark = create_spark(f"Lifecycle-Churn-{args.mode}")
    t0 = time.time()
    build_churn_dataset(spark, args.mode)
    print(f"[churn_dataset] 完成, 耗时 {(time.time() - t0) / 60:.1f} 分钟")
    spark.stop()


if __name__ == "__main__":
    main()
