"""
时间合规校验（流失 + 复购）
============================
对已落盘的 churn_dataset / repurchase_dataset 做三类校验：
  1. 时间隔离：流失样本 obs_end < pred_start（特征窗口 < 标签窗口）；
               复购样本观察窗口 [首购+1, +30] 与预测窗口 [首购+31, +60] 无交集（构造保证）。
  2. 时序切分：流失 train/val/test 的 pred_start、复购的 first_buy_date 严格递增无重叠。
  3. 分布一致性：train/val/test 正样本率无显著偏移。

输出: data/lifecycle/metrics/leakage_report.json
用法: python scripts/lifecycle/leakage_check.py --mode dev|full|limit
"""
import os
import sys
import json
import argparse
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.lifecycle.config import *


def _load(root, mode):
    out = {}
    for split in ["train", "val", "test"]:
        p = os.path.join(root, mode, split)
        out[split] = pd.read_parquet(p) if os.path.isdir(p) else None
    return out


def check_churn(mode):
    dfs = _load(CHURN_DATASET_DIR, mode)
    if dfs["train"] is None:
        return None
    all_df = pd.concat([d for d in dfs.values() if d is not None], ignore_index=True)

    # 1) 时间隔离：obs_end < pred_start
    bad = int((all_df["obs_end"] >= all_df["pred_start"]).sum())
    # 2) 时序切分
    order = {s: {"min_pred_start": str(d["pred_start"].min()), "max_pred_start": str(d["pred_start"].max())}
             for s, d in dfs.items() if d is not None}
    ok_split = order["train"]["max_pred_start"] < order["val"]["min_pred_start"] and \
        order["val"]["max_pred_start"] < order["test"]["min_pred_start"]
    # 3) 分布
    dist = {s: round(float(d["label"].mean()), 4) for s, d in dfs.items() if d is not None}
    return {"temporal_isolation": {"ok": bad == 0, "violations": bad},
            "temporal_split": {"ok": ok_split, "splits": order},
            "pos_rate_by_split": dist}


def check_repurchase(mode):
    dfs = _load(REPURCHASE_DATASET_DIR, mode)
    if dfs["train"] is None:
        return None
    # 1) 复购窗口隔离由构造保证（观察 [首购+1,+30] 预测 [+31,+60]），此处校验首购日上限
    all_df = pd.concat([d for d in dfs.values() if d is not None], ignore_index=True)
    over = int((all_df["first_buy_date"].astype(str) > REPURCHASE_FIRST_BUY_MAX).sum())
    # 2) 时序切分
    order = {s: {"min_first_buy": str(d["first_buy_date"].min()), "max_first_buy": str(d["first_buy_date"].max())}
             for s, d in dfs.items() if d is not None}
    ok_split = order["train"]["max_first_buy"] < order["val"]["min_first_buy"] and \
        order["val"]["max_first_buy"] < order["test"]["min_first_buy"]
    # 3) 分布
    dist = {s: round(float(d["label"].mean()), 4) for s, d in dfs.items() if d is not None}
    return {"first_buy_within_window": {"ok": over == 0, "violations": over},
            "temporal_split": {"ok": ok_split, "splits": order},
            "pos_rate_by_split": dist}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=MODES, default="dev")
    args = parser.parse_args()

    report = {
        "mode": args.mode,
        "churn": check_churn(args.mode),
        "repurchase": check_repurchase(args.mode),
    }

    os.makedirs(METRICS_DIR, exist_ok=True)
    out_path = os.path.join(METRICS_DIR, "leakage_report.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2, default=str)

    print("=" * 60)
    print("时间合规校验结果")
    for task, key in [("churn", "temporal_isolation"), ("repurchase", "first_buy_within_window")]:
        r = report[task]
        if r is None:
            print(f"  {task}: 样本不存在，跳过")
            continue
        print(f"  {task} 时间隔离: {'PASS' if r[key]['ok'] else 'FAIL'}")
        print(f"  {task} 时序切分 (train<val<test): {'PASS' if r['temporal_split']['ok'] else 'FAIL'}")
        print(f"  {task} 正样本率: {r['pos_rate_by_split']}")
    print(f"报告 -> {out_path}")


if __name__ == "__main__":
    main()
