"""
用户生命周期运营建议报告
==========================
综合流失预测 + 复购预测 + 价值分层结论，产出分层运营策略建议 HTML 报告。

输入（data/lifecycle/metrics/）：评估指标 / 特征重要性 / 风险清单 / 潜力清单 /
分品类复购周期基准 / 全量生命周期预测表。
输出: reports/lifecycle/user_lifecycle_report.html
用法: python scripts/lifecycle/generate_report.py --mode dev|full|limit
"""
import os
import sys
import json
import argparse
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.lifecycle.config import *


def _read_csv(name):
    p = os.path.join(METRICS_DIR, name)
    return pd.read_csv(p) if os.path.exists(p) else None


def _fmt_table(df, n=None):
    if df is None or len(df) == 0:
        return "<p class='muted'>无数据</p>"
    if n:
        df = df.head(n)
    return df.to_html(index=False, classes="tbl", border=0, escape=False)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=MODES, default="limit")
    args = parser.parse_args()
    mode = args.mode

    os.makedirs(LIFECYCLE_REPORTS_DIR, exist_ok=True)

    churn_m = json.load(open(os.path.join(METRICS_DIR, "churn_metrics.json")))
    rep_m = json.load(open(os.path.join(METRICS_DIR, "repurchase_metrics.json")))

    churn_best = churn_m["best_model"]
    rep_cls_best = rep_m["best_cls_model"]
    rep_reg_best = rep_m.get("best_reg_model")

    # 纯历史特征 ablation 对照（若存在），量化运营画像特征的抬升幅度
    ablation = None
    _ablation_path = os.path.join(METRICS_DIR, "ablation_metrics.json")
    if os.path.exists(_ablation_path):
        ablation = json.load(open(_ablation_path))

    imp = _read_csv(f"churn_importance_{churn_best}.csv")
    risk = _read_csv("churn_risk_list.csv")
    hv_risk = _read_csv("churn_high_value_risk_list.csv")
    by_cat = _read_csv("repurchase_by_cat.csv")
    potential = _read_csv("repurchase_potential_list.csv")
    hv_potential = _read_csv("repurchase_high_value_potential_list.csv")
    cat_cycle = _read_csv("category_repurchase_cycle.csv")
    pred = _read_csv("user_lifecycle_prediction.csv")

    # ── 分层运营交叉统计 ──
    cross_rows = []
    if pred is not None:
        pred = pred.copy()
        pred["churn_risk"] = pred["churn_prob"] >= 0.5
        pred["repotential"] = pred["repurchase_prob"] >= 0.5
        for tier in ["高价值", "中价值", "低价值"]:
            g = pred[pred["value_tier"] == tier]
            if len(g) == 0:
                continue
            g_rep = g[g["repurchase_prob"].notna()]  # 首购日过晚无法预测复购的除外
            cross_rows.append({
                "价值层级": tier,
                "用户数": len(g),
                "高流失风险占比%": round(g["churn_risk"].mean() * 100, 1),
                "高复购潜力占比%": round(g_rep["repotential"].mean() * 100, 1) if len(g_rep) else None,
                "平均流失概率": round(g["churn_prob"].mean(), 3),
                "平均复购概率": round(g_rep["repurchase_prob"].mean(), 3) if len(g_rep) else None,
            })
    cross_df = pd.DataFrame(cross_rows)

    # ── 分品类复购周期基准 top ──
    cycle_top = None
    if cat_cycle is not None:
        cycle_top = cat_cycle.sort_values("cat_cycle_days").head(15).copy()
        cycle_top.columns = ["品类", "复购周期(天)", "样本量"]

    html_parts = []

    def sec(title, body):
        html_parts.append(f"<section><h2>{title}</h2>{body}</section>")

    # 头部
    html_parts.append(f"""
    <!DOCTYPE html><html lang="zh"><head><meta charset="utf-8">
    <title>用户生命周期运营建议报告</title>
    <style>
      body {{ font-family: -apple-system, "PingFang SC", sans-serif; margin: 2rem auto;
             max-width: 1080px; line-height: 1.6; color: #1f2328; }}
      h1 {{ border-bottom: 3px solid #0969da; padding-bottom: .5rem; }}
      h2 {{ color: #0969da; margin-top: 2.5rem; border-left: 4px solid #0969da; padding-left: .6rem; }}
      h3 {{ color: #333; }}
      .tbl {{ border-collapse: collapse; width: 100%; font-size: .88rem; margin: .8rem 0; }}
      .tbl th, .tbl td {{ border: 1px solid #d0d7de; padding: .35rem .5rem; text-align: left; }}
      .tbl th {{ background: #f6f8fa; }}
      .muted {{ color: #6e7781; }}
      .note {{ background: #fff8c5; border: 1px solid #d4a72c; padding: .8rem; border-radius: 6px; }}
      .strat {{ background: #f6f8fa; border-left: 4px solid #0969da; padding: .6rem .8rem; margin: .6rem 0; }}
    </style></head><body>
    <h1>用户生命周期运营建议报告</h1>
    <p>档位 <b>{mode}</b> · 数据范围 2013-04-01 ~ 2013-10-01 · 价值分层 × 流失预测 × 复购预测</p>
    """)

    # ── 流失预测 ──
    churn_metrics_html = _fmt_table(pd.DataFrame(churn_m["metrics"]).T.reset_index().rename(columns={"index": "模型"}))
    imp_html = _fmt_table(imp, 15) if imp is not None else "<p class='muted'>无特征重要性</p>"
    hv_risk_html = _fmt_table(hv_risk, 10) if hv_risk is not None else "<p class='muted'>无高价值×高流失子清单</p>"
    sec("一、用户流失预测模型",
        f"<h3>1. 模型效果（测试集）</h3>{churn_metrics_html}"
        f"<h3>2. 流失核心驱动因素（{churn_best} 特征重要性 Top 15）</h3>{imp_html}"
        f"<h3>3. 高流失风险用户清单</h3>"
        f"<p>全量风险清单 {len(risk):,} 条（按流失概率降序）；高价值×高流失风险子清单 {len(hv_risk):,} 条：</p>{hv_risk_html}")

    # ── 复购预测 ──
    cls_html = _fmt_table(pd.DataFrame(rep_m["classification"]).T.reset_index().rename(columns={"index": "模型"}))
    reg_html = ""
    if rep_m.get("regression"):
        reg_html = _fmt_table(pd.DataFrame(rep_m["regression"]).T.reset_index().rename(columns={"index": "模型"}))
    by_cat_html = ""
    if by_cat is not None and len(by_cat):
        by_cat_best = by_cat.head(8)
        by_cat_worst = by_cat.tail(5)
        by_cat_html = (f"<h4>优势品类（AUC 高、样本足）</h4>{_fmt_table(by_cat_best)}"
                       f"<h4>薄弱品类（AUC 低）</h4>{_fmt_table(by_cat_worst)}")
    hv_pot_html = _fmt_table(hv_potential, 10) if hv_potential is not None else "<p class='muted'>无高价值×高复购子清单</p>"
    cycle_html = _fmt_table(cycle_top) if cycle_top is not None else "<p class='muted'>无品类复购周期基准</p>"
    sec("二、用户复购预测模型",
        f"<h3>1. 复购概率（二分类，测试集）</h3>{cls_html}"
        f"<h3>2. 复购周期（回归，已复购用户，MAE/RMSE）</h3>{reg_html or '<p class=muted>回归样本过少，未训练</p>'}"
        f"<h3>3. 分品类复购预测精度差异</h3>{by_cat_html or '<p class=muted>无分品类数据</p>'}"
        f"<h3>4. 高复购潜力用户清单</h3>"
        f"<p>高复购潜力清单 {len(potential):,} 条；高价值×高复购子清单 {len(hv_potential):,} 条：</p>{hv_pot_html}"
        f"<h3>5. 分品类复购周期基准（运营触达窗口参考）</h3>{cycle_html}")

    # ── 分层运营策略 ──
    cross_html = _fmt_table(cross_df) if len(cross_df) else "<p class='muted'>无全量预测表</p>"
    sec("三、分层运营策略建议",
        f"<h3>1. 价值层级 × 流失 × 复购 交叉分布</h3>{cross_html}"
        f"""<h3>2. 分层运营策略</h3>
        <div class="strat"><b>① 高价值 × 高流失风险</b>：核心召回对象，投入最优先资源。
        主动触达（优惠券/专属客服/短信），结合其偏好品类与历史购买品牌做个性化召回，
        目标是把流失概率压下来——这批用户流失一个损失最大。</div>
        <div class="strat"><b>② 高价值 × 高复购潜力</b>：复购营销主力。按分品类复购周期基准
        在预计复购窗口前 3~7 天触达新品/折扣/会员权益，缩短复购周期、拉升客单。</div>
        <div class="strat"><b>③ 高价值 × 低流失 × 低复购潜力</b>：维持关系、防流失。低频但不流失，
        用会员成长/权益绑定保持粘性，避免滑向高流失。</div>
        <div class="strat"><b>④ 中价值 × 高流失风险</b>：低成本批量召回（站内 push/优惠券），
        不投入专属客服等重资源，按召回 ROI 排序择优触达。</div>
        <div class="strat"><b>⑤ 低价值 × 高流失风险</b>：资源有限时放弃或极低成本触达，
        聚焦于上述高价值人群，避免撒网式运营浪费。</div>
        <div class="strat"><b>⑥ 低价值 × 低流失 × 高复购潜力</b>：价格敏感型复购者，
        用性价比货品 + 满减活动提频，是「低价值」里的增量机会。</div>""")

    # ── 口径与泄露说明（含纯历史特征 ablation 对照）──
    ablation_note = ""
    if ablation:
        churn_full = churn_m["metrics"].get(churn_best, {}).get("auc")
        rep_full = rep_m["classification"].get(rep_cls_best, {}).get("auc")
        churn_ab = ablation.get("churn", {}).get("xgb", {}).get("auc") or \
            ablation.get("churn", {}).get("lr", {}).get("auc")
        rep_ab = ablation.get("repurchase_cls", {}).get("lr", {}).get("auc") or \
            ablation.get("repurchase_cls", {}).get("xgb", {}).get("auc")
        if churn_full and churn_ab and rep_full and rep_ab:
            ablation_note = (
                f"<b>纯历史特征对照（去掉价值分层+口碑）</b>：流失 AUC {churn_full}→{churn_ab}，"
                f"复购概率 AUC {rep_full}→{rep_ab}（真实预测能力），复购周期 MAE 基本不变。"
                f"运营画像特征（含未来信息）抬高流失 {round(churn_full - churn_ab, 3)}、"
                f"复购概率 {round(rep_full - rep_ab, 3)}，故上表分类 AUC 为「注水上界」。<br>"
            )
    sec("四、数据口径与已知限制",
        f"""<div class="note">
        <b>时间口径</b>：流失 = 历史有购买用户在预测窗口 30 天无购买；复购概率 = 首购后
        第 31~60 天是否二次购买；复购周期 = 首购→二次购买间隔天数（训练于已复购用户）。
        流失 8 断面、复购按首购日，均严格时序切 train/val/test。<br>
        <b>已知未来泄露（打折看）</b>：价值层级 value_tier（全量 RFM 画像）与口碑特征
        （review 表无时间戳，全量评论聚合）含预测时点之后的信息，对 train/val/test 均匀
        作用、不破坏时序一致性，但会高估绝对性能；实际效果以「纯历史特征」为准。<br>
        {ablation_note}</div>""")

    html_parts.append("</body></html>")

    out_path = os.path.join(LIFECYCLE_REPORTS_DIR, "user_lifecycle_report.html")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(html_parts))
    print(f"[generate_report] 报告 -> {out_path}")


if __name__ == "__main__":
    main()
