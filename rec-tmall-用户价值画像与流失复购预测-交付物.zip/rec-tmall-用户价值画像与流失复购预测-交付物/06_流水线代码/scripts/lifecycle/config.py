"""
用户生命周期预测模块配置（流失预测 + 复购预测）
================================================
用户价值画像与流失复购预测（第 2 部分）。在已交付的用户画像标签体系 + RFM 价值分层
基础上，开发流失预测模型与复购预测模型（概率二分类 + 周期回归）。

复用：
  - scripts/modeling/aggregate.py 产出的 daily 中间表（(user,item,date) 粒度，共享地基）
  - scripts/modeling/model_utils.py 的纯函数（指标 / 特征重要性 / 目标编码 / 模型持久化）
  - scripts/modeling/config.py 的字段映射 / 行为映射 / 日志档位

配置驱动：换结构相似数据集只改本文件。字段映射、时间窗口、断面、采样比例、
价值分层引用路径、模型超参全部集中在此，脚本一律不改。
"""
import os
import sys
from datetime import date, timedelta

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, PROJECT_ROOT)

from scripts.config import DATA_CLEANED, DATA_SAMPLES, SENTIMENT_OUTPUT_DIR, create_spark
# 复用 modeling 的共享地基与字段/行为/档位定义（不重复定义，避免两处漂移）
from scripts.modeling.config import (
    DAILY_DIR, LOG_BY_MODE, MODES, COL,
    ACTION_VALUES, ACTION_CLICK, ACTION_COLLECT, ACTION_CART, ACTION_BUY,
    CATEGORY_SPLIT, CATEGORY_PARENT_IDX, CATEGORY_LEAF_IDX,
)

# ── 行为映射 ──
BUY_ACTION = ACTION_BUY          # 购买行为（alipay）
BUY_COL = f"{BUY_ACTION}_cnt"    # daily 表中购买计数列名

# ── 数据时间边界（从 EDA 报告确认）──
DATA_START = "2013-04-01"
DATA_END = "2013-10-01"

# ── 输入资产（只读，不重算）──
PRODUCT_PATH = os.path.join(DATA_CLEANED, "product")
VALUE_SCORE_PATH = os.path.join(DATA_SAMPLES, "user_value", "value_score")   # 上周 RFM 价值分层
REVIEW_PRED_PATH = os.path.join(SENTIMENT_OUTPUT_DIR, "review_pred.parquet")  # 评论情感预测
ITEM_OPS_PATH = os.path.join(DATA_CLEANED, "item_ops")                       # 商品级运营宽表（销量热度）
# 首购消费力估算复用 user_value RFM M 维度的口径（品类价值权重 / 品牌层级），只读这两个既有 CSV
PARENT_CAT_METRICS_CSV = os.path.join(PROJECT_ROOT, "reports", "parent_category_metrics.csv")
BRAND_METRICS_CSV = os.path.join(PROJECT_ROOT, "reports", "brand_metrics.csv")

# ── 本模块输出目录 ──
LIFECYCLE_DIR = os.path.join(PROJECT_ROOT, "data", "lifecycle")
FEATURES_DIR = os.path.join(LIFECYCLE_DIR, "features")
CHURN_DATASET_DIR = os.path.join(LIFECYCLE_DIR, "churn_dataset")
REPURCHASE_DATASET_DIR = os.path.join(LIFECYCLE_DIR, "repurchase_dataset")
MODEL_DIR = os.path.join(LIFECYCLE_DIR, "model")
METRICS_DIR = os.path.join(LIFECYCLE_DIR, "metrics")
LIFECYCLE_REPORTS_DIR = os.path.join(PROJECT_ROOT, "reports", "lifecycle")

# ── 时间窗口（换数据改这里）──
CHURN_OBS_DAYS = 30       # 流失：观察窗口长度（近期特征）
CHURN_PRED_DAYS = 30      # 流失：预测窗口长度（标签）
REPURCHASE_OBS_DAYS = 30  # 复购：首购后观察窗口（互动特征）
REPURCHASE_PRED_DAYS = 30 # 复购：预测窗口（首购后 31~60 天）
FEATURE_WINDOWS = [7, 14, 30]   # 「近 N 天」特征窗口
SLIDE_STEP_DAYS = 15            # 流失断面滑动步长

# ── 流失预测时间断面（换数据改这里）──
# 30 观察 + 30 预测，步长 15 天。早断面 train、中 val、晚 test，严格时序递增。
CHURN_SLICES = [
    {"slice_id": 1, "pred_start": "2013-05-16", "split": "train"},
    {"slice_id": 2, "pred_start": "2013-06-01", "split": "train"},
    {"slice_id": 3, "pred_start": "2013-06-16", "split": "train"},
    {"slice_id": 4, "pred_start": "2013-07-01", "split": "train"},
    {"slice_id": 5, "pred_start": "2013-07-16", "split": "val"},
    {"slice_id": 6, "pred_start": "2013-08-01", "split": "val"},
    {"slice_id": 7, "pred_start": "2013-08-16", "split": "test"},
    {"slice_id": 8, "pred_start": "2013-09-01", "split": "test"},
]

# ── 复购预测首购锚点切分（换数据改这里）──
# 样本 = 首购日 <= 上限 的成交用户（保证首购 + 观察30 + 预测30 <= 数据末尾）。
# 按首购日切 train/val/test（首购日早的进 train），严格时序递增无重叠。
REPURCHASE_FIRST_BUY_MAX = "2013-08-02"     # 首购日上限（+60 天 <= 10-01）
REPURCHASE_TRAIN_END = "2013-06-15"         # train：首购日 <= 此值
REPURCHASE_VAL_END = "2013-07-15"           # val：首购日 <= 此值（> train_end）
# test：首购日 > REPURCHASE_VAL_END 且 <= REPURCHASE_FIRST_BUY_MAX

# ── 采样参数（换数据改这里）──
# 流失：正样本=流失（30天无购买，占多数），负样本=留存（少数）→ 欠采样流失到「正:负」目标比
CHURN_POS_NEG_RATIO = 2        # 流失正:留存负 目标比例（test 不采样反映自然分布）
# 复购概率：正样本=复购（少数），负样本=不复购（多数）→ 欠采样不复购到「负:正」目标比
REPURCHASE_POS_NEG_RATIO = 5   # 复购 负:正 目标比例（test 不采样反映自然分布）
TEST_NEG_MAX = 300000          # test 负样本随机抽样上限
NEG_SAMPLE_SEED = 42

# ── 元数据列（不参与特征；user 级任务无 item_id）──
META_COLS = ["user_id", "label", "slice_id", "split", "pred_start", "obs_end",
             "first_buy_date", "churn_reg_label"]

# ── 类别特征（训练侧 fold 内目标编码，按任务分开）──
CHURN_CAT_COLS = ["value_tier", "value_subtier"]
REPURCHASE_CAT_COLS = ["value_tier", "value_subtier", "first_cat", "first_leaf_cat", "first_brand"]

# ── 特征预处理（pandas 侧，train 拟合防泄露）──
PREPROCESS = {
    "fill_numeric_na": 0.0,         # 数值缺失填充
    "clip_quantiles": [0.01, 0.99], # 异常值截断分位数
    "standardize": True,            # 标准化（train 拟合 mean/std）
    "corr_threshold": 0.95,         # 相关性筛选阈值
}

# ── 目标编码参数 ──
TARGET_ENCODING_FOLDS = 5
TARGET_ENCODING_SMOOTH = 10.0

# ── 类别权重 ──
USE_CLASS_WEIGHT = True

# ── 分类模型超参（流失 / 复购概率共用，换数据改这里）──
MODEL_PARAMS = {
    "lr": {
        "C": 1.0, "max_iter": 2000, "solver": "liblinear",
        "class_weight": "balanced" if USE_CLASS_WEIGHT else None, "random_state": 42,
    },
    "xgb": {
        "objective": "binary:logistic", "eval_metric": "auc", "tree_method": "hist",
        "learning_rate": 0.05, "max_depth": 6, "min_child_weight": 1,
        "subsample": 0.8, "colsample_bytree": 0.8, "reg_alpha": 0.1, "reg_lambda": 1.0,
        "n_estimators": 2000, "early_stopping_rounds": 100,
        "n_jobs": -1, "random_state": 42, "enable_categorical": True,
    },
}

# ── 回归模型超参（复购周期，换数据改这里）──
REGRESSION_MODEL_PARAMS = {
    "lgb": {
        "objective": "regression", "metric": "rmse", "boosting_type": "gbdt",
        "learning_rate": 0.05, "num_leaves": 31, "max_depth": -1,
        "min_child_samples": 20, "subsample": 0.8, "subsample_freq": 1,
        "colsample_bytree": 0.8, "reg_alpha": 0.1, "reg_lambda": 0.1,
        "n_estimators": 2000, "n_jobs": -1, "random_state": 42, "verbosity": -1,
    },
    "xgb": {
        "objective": "reg:squarederror", "eval_metric": "rmse", "tree_method": "hist",
        "learning_rate": 0.05, "max_depth": 6, "min_child_weight": 1,
        "subsample": 0.8, "colsample_bytree": 0.8, "reg_alpha": 0.1, "reg_lambda": 1.0,
        "n_estimators": 2000, "early_stopping_rounds": 100,
        "n_jobs": -1, "random_state": 42,
    },
}

# ── 调优网格 ──
LR_C_GRID = [0.01, 0.1, 1.0]
XGB_GRID = {"learning_rate": [0.03, 0.05, 0.1], "max_depth": [4, 6, 8]}
LGB_REGRESSION_GRID = {"learning_rate": [0.03, 0.05, 0.1], "num_leaves": [31, 63]}
XGB_REGRESSION_GRID = {"learning_rate": [0.03, 0.05, 0.1], "max_depth": [4, 6, 8]}

# ── 复购概率高潜力 / 流失高风险 概率阈值 ──
RISK_THRESHOLDS = [0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]


def _parse(s):
    return date(*[int(x) for x in s.split("-")])


def churn_slice_windows():
    """展开每个流失断面的完整时间窗口，返回 ISO 字符串列表。

    观察窗口 [pred_start - CHURN_OBS_DAYS, pred_start - 1]（近期特征），
    预测窗口 [pred_start, pred_start + CHURN_PRED_DAYS - 1]（标签）。
    历史稳定特征取 [DATA_START, pred_start) 全历史。
    """
    out = []
    for s in CHURN_SLICES:
        pred_start = _parse(s["pred_start"])
        obs_start = pred_start - timedelta(days=CHURN_OBS_DAYS)
        obs_end = pred_start - timedelta(days=1)
        pred_end = pred_start + timedelta(days=CHURN_PRED_DAYS - 1)
        out.append({
            "slice_id": s["slice_id"],
            "split": s["split"],
            "pred_start": pred_start.isoformat(),
            "pred_end": pred_end.isoformat(),
            "obs_start": obs_start.isoformat(),
            "obs_end": obs_end.isoformat(),
        })
    return out
