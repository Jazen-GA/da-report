"""
运营画像特征 ablation 对照（诚实性评估）
==========================================
去掉含未来信息的运营画像特征（value_tier / value_subtier / total_score / rv_*），
用纯历史行为特征重训流失 + 复购模型，得到「不注水」的 AUC / MAE 对照。

与完整版（churn_metrics.json / repurchase_metrics.json）对比，量化运营画像特征
把绝对性能抬了多少。复用已落盘 dataset（默认 limit 档），不重跑 Spark 特征工程，
只跑 pandas 训练，速度快。

输出: data/lifecycle/metrics/ablation_metrics.json
用法: python scripts/lifecycle/ablation_train.py --mode limit
"""
import os
import sys
import json
import argparse

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.lifecycle.config import *
from scripts.lifecycle.train_utils import (
    load_all, numeric_cols, fit_preprocess, transform_preprocess,
    build_feature_matrix, fit_classifier, fit_regressor, compute_regression_metrics,
)
from scripts.modeling.model_utils import (
    compute_metrics, target_encode_fit, target_encode_apply_map, write_json,
)

# 含未来信息的运营画像特征（value_tier/value_subtier 是类别列，total_score/rv_* 是数值列）
DROP_COLS = ["value_tier", "value_subtier", "total_score", "rv_cnt", "rv_pos_rate", "rv_avg_sentiment"]


def _drop(dfs):
    """删除运营画像列（列存在才删，换数据少列不崩）"""
    drop = [c for c in DROP_COLS if c in dfs[0].columns]
    for df in dfs:
        df.drop(columns=drop, inplace=True)
    return drop


def _target_encode(train, val, test, cat_cols):
    """类别列目标编码（train 拟合）。cat_cols 为空时返回 None（不进特征矩阵）。"""
    if not cat_cols:
        return train, val, test, None, None, None
    y_train = train["label"].astype(float)
    te_maps = target_encode_fit(train[cat_cols], y_train, smooth=TARGET_ENCODING_SMOOTH)
    global_mean = float(y_train.mean())
    te_train = target_encode_apply_map(train[cat_cols], te_maps, global_mean)
    te_val = target_encode_apply_map(val[cat_cols], te_maps, global_mean)
    te_test = target_encode_apply_map(test[cat_cols], te_maps, global_mean)
    return train, val, test, te_train, te_val, te_test


def run_classification(root, mode, cat_cols_full):
    """流失 / 复购概率 二分类 ablation，返回 {model: metrics}"""
    train, val, test = load_all(root, mode)
    dropped = _drop([train, val, test])
    cat_cols = [c for c in cat_cols_full if c not in dropped]
    for df in (train, val, test):
        for c in cat_cols:
            df[c] = df[c].fillna("未知")

    num_cols = numeric_cols(train, cat_cols)
    params = fit_preprocess(train, num_cols)
    train = transform_preprocess(train, num_cols, params)
    val = transform_preprocess(val, num_cols, params)
    test = transform_preprocess(test, num_cols, params)

    _, _, _, te_train, te_val, te_test = _target_encode(train, val, test, cat_cols)
    X_train = build_feature_matrix(train, cat_cols, te_train)
    X_val = build_feature_matrix(val, cat_cols, te_val)
    X_test = build_feature_matrix(test, cat_cols, te_test)
    y_train = train["label"].astype(float)
    y_val = val["label"].astype(float)

    results = {}
    for mn in ["lr", "xgb"]:
        model, _ = fit_classifier(mn, X_train, y_train, X_val, y_val)
        test_prob = model.predict_proba(X_test)[:, 1]
        results[mn] = compute_metrics(test["label"], test_prob)
    return results


def run_regression(root, mode, cat_cols_full):
    """复购周期回归 ablation，返回 {model: {mae, rmse}}"""
    train, val, test = load_all(root, mode)
    dropped = _drop([train, val, test])
    cat_cols = [c for c in cat_cols_full if c not in dropped]
    for df in (train, val, test):
        for c in cat_cols:
            df[c] = df[c].fillna("未知")

    num_cols = numeric_cols(train, cat_cols)
    params = fit_preprocess(train, num_cols)
    train = transform_preprocess(train, num_cols, params)
    val = transform_preprocess(val, num_cols, params)
    test = transform_preprocess(test, num_cols, params)

    _, _, _, te_train, te_val, te_test = _target_encode(train, val, test, cat_cols)
    X_train = build_feature_matrix(train, cat_cols, te_train)
    X_val = build_feature_matrix(val, cat_cols, te_val)
    X_test = build_feature_matrix(test, cat_cols, te_test)

    mask_tr = (train["label"] == 1).values
    mask_va = (val["label"] == 1).values
    mask_te = (test["label"] == 1).values
    X_tr = X_train[mask_tr]
    y_tr = train.loc[mask_tr, "churn_reg_label"].astype(float)
    X_va = X_val[mask_va]
    y_va = val.loc[mask_va, "churn_reg_label"].astype(float)
    X_te = X_test[mask_te]
    y_te = test.loc[mask_te, "churn_reg_label"].astype(float)

    results = {}
    if len(X_tr) < 10:
        return results
    for mn in ["lgb", "xgb"]:
        model, _ = fit_regressor(mn, X_tr, y_tr, X_va, y_va)
        y_pred = model.predict(X_te)
        results[mn] = compute_regression_metrics(y_te, y_pred)
    return results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=MODES, default="limit")
    args = parser.parse_args()
    mode = args.mode

    report = {"mode": mode, "dropped_features": DROP_COLS}

    if os.path.isdir(os.path.join(CHURN_DATASET_DIR, mode, "train")):
        print("=" * 60)
        print("[ablation] 流失预测（纯历史特征）")
        report["churn"] = run_classification(CHURN_DATASET_DIR, mode, CHURN_CAT_COLS)
        for mn, m in report["churn"].items():
            print(f"  {mn}: AUC={m['auc']} recall={m['recall']} precision={m['precision']} F1={m['f1']}")

    if os.path.isdir(os.path.join(REPURCHASE_DATASET_DIR, mode, "train")):
        print("=" * 60)
        print("[ablation] 复购概率（纯历史特征）")
        report["repurchase_cls"] = run_classification(REPURCHASE_DATASET_DIR, mode, REPURCHASE_CAT_COLS)
        for mn, m in report["repurchase_cls"].items():
            print(f"  {mn}: AUC={m['auc']} recall={m['recall']} precision={m['precision']} F1={m['f1']}")

        print("[ablation] 复购周期（纯历史特征）")
        report["repurchase_reg"] = run_regression(REPURCHASE_DATASET_DIR, mode, REPURCHASE_CAT_COLS)
        for mn, m in report["repurchase_reg"].items():
            print(f"  {mn}: MAE={m['mae']} RMSE={m['rmse']}")

    os.makedirs(METRICS_DIR, exist_ok=True)
    out_path = os.path.join(METRICS_DIR, "ablation_metrics.json")
    write_json(report, out_path)
    print(f"\n[ablation] 对照指标 -> {out_path}")


if __name__ == "__main__":
    main()
