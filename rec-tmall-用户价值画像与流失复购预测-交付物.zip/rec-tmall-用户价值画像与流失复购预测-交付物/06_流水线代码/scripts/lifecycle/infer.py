"""
全量推理：用户流失概率 + 复购概率 + 预计复购周期
==================================================
用训练好的最优模型对全量成交用户推理，产出用户生命周期预测表：
  user_id / value_tier / value_subtier / churn_prob / repurchase_prob / expected_interval_days

流失推理：用最新断面（数据末尾前 30 天）算流失特征，对历史有购买用户推理。
复购推理：对全量首购用户（首购日 <= 上限）算复购特征，推理概率 + 周期。

输出: data/lifecycle/metrics/user_lifecycle_prediction.csv
用法: python scripts/lifecycle/infer.py --mode dev|full|limit
"""
import os
import sys
import time
import json
import argparse
import numpy as np
import joblib
from pyspark.sql import functions as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.lifecycle.config import *
from scripts.lifecycle.features import (
    load_product, build_static, build_category_cycle,
    build_churn_features, build_first_buy_info, build_repurchase_features,
)
from scripts.lifecycle.train_utils import transform_preprocess, build_feature_matrix
from scripts.modeling.model_utils import target_encode_apply_map


def _apply_infer(spark_df, bundle, cat_cols):
    """Spark 特征表 → pandas → 预处理 + 目标编码 + 特征矩阵（应用训练保存的参数）"""
    pdf = spark_df.toPandas()
    meta_keep = [c for c in ["user_id", "value_tier", "value_subtier"] if c in pdf.columns]
    keep = meta_keep + [c for c in bundle["num_cols"] if c in pdf.columns]
    keep += [c for c in cat_cols if c in pdf.columns and c not in keep]
    pdf = pdf[keep]

    num_cols = [c for c in bundle["num_cols"] if c in pdf.columns]
    pdf = transform_preprocess(pdf, num_cols, bundle["params"])
    for c in cat_cols:
        if c in pdf.columns:
            pdf[c] = pdf[c].fillna("未知")

    te = target_encode_apply_map(pdf[cat_cols], bundle["te_maps"], bundle["global_mean"])
    X = build_feature_matrix(pdf, cat_cols, te)
    return pdf[meta_keep], X


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=MODES, default="limit")
    args = parser.parse_args()
    mode = args.mode
    t0 = time.time()

    # 加载最优模型 + 预处理 bundle
    churn_bundle = joblib.load(os.path.join(MODEL_DIR, "churn", "preprocess.joblib"))
    rep_bundle = joblib.load(os.path.join(MODEL_DIR, "repurchase", "preprocess.joblib"))
    with open(os.path.join(METRICS_DIR, "churn_metrics.json")) as f:
        churn_best = json.load(f)["best_model"]
    with open(os.path.join(METRICS_DIR, "repurchase_metrics.json")) as f:
        rep_metrics = json.load(f)
        rep_cls_best = rep_metrics["best_cls_model"]
        rep_reg_best = rep_metrics.get("best_reg_model")

    churn_model = joblib.load(os.path.join(MODEL_DIR, "churn", f"{churn_best}.joblib"))
    rep_cls_model = joblib.load(os.path.join(MODEL_DIR, "repurchase", f"cls_{rep_cls_best}.joblib"))
    rep_reg_model = None
    if rep_reg_best:
        rep_reg_model = joblib.load(os.path.join(MODEL_DIR, "repurchase", f"reg_{rep_reg_best}.joblib"))

    spark = create_spark(f"Lifecycle-Infer-{mode}")
    daily = spark.read.parquet(os.path.join(DAILY_DIR, mode))
    product = load_product(spark)
    static = build_static(spark)
    cat_cycle = build_category_cycle(spark, daily, product).persist()

    # ══ 流失推理（最新断面）══
    w = churn_slice_windows()[-1]
    print(f"[infer] 流失推理断面 pred_start={w['pred_start']} (obs {w['obs_start']}~{w['obs_end']})")
    churn_feats = build_churn_features(spark, daily, w, product, static, cat_cycle)
    churn_feats = churn_feats.filter(F.col("hist_buy_cnt") >= 1)
    cat_cycle.unpersist()

    churn_meta, X_churn = _apply_infer(churn_feats, churn_bundle, CHURN_CAT_COLS)
    churn_meta = churn_meta.reset_index(drop=True)
    churn_meta["churn_prob"] = churn_model.predict_proba(X_churn)[:, 1]
    print(f"[infer] 流失推理 {len(churn_meta):,} 用户")

    # ══ 复购推理（全量首购用户）══
    first_buy = build_first_buy_info(spark, daily, product)
    first_buy = first_buy.filter(F.col("first_buy_date") <= F.lit(REPURCHASE_FIRST_BUY_MAX))
    rep_feats = build_repurchase_features(spark, daily, product, static, first_buy)

    rep_meta, X_rep = _apply_infer(rep_feats, rep_bundle, REPURCHASE_CAT_COLS)
    rep_meta = rep_meta.reset_index(drop=True)
    rep_meta["repurchase_prob"] = rep_cls_model.predict_proba(X_rep)[:, 1]
    if rep_reg_model is not None:
        rep_meta["expected_interval_days"] = rep_reg_model.predict(X_rep)
    else:
        rep_meta["expected_interval_days"] = np.nan
    print(f"[infer] 复购推理 {len(rep_meta):,} 首购用户")

    # ══ 合并 ══
    rep_meta = rep_meta.drop(columns=["value_tier", "value_subtier"], errors="ignore")
    merged = churn_meta.merge(rep_meta, on="user_id", how="left")
    merged = merged.sort_values("churn_prob", ascending=False)

    out_path = os.path.join(METRICS_DIR, "user_lifecycle_prediction.csv")
    merged.to_csv(out_path, index=False, encoding="utf-8-sig")
    print(f"[infer] 全量生命周期预测表 {len(merged):,} 行 -> {out_path}")

    spark.stop()
    print(f"[infer] 完成, 耗时 {(time.time() - t0) / 60:.1f} 分钟")


if __name__ == "__main__":
    main()
