"""
复购样本构建（概率二分类 + 周期回归 双任务）
==============================================
样本空间 = 首购日 <= REPURCHASE_FIRST_BUY_MAX 的成交用户（首购 = 第一次 alipay）。
以首购日为锚点：
  - 观察窗口 = 首购后 [1, 30] 天（互动特征）
  - 预测窗口 = 首购后 [31, 60] 天
  - 复购概率 label      = 预测窗口内是否有第 2 次购买（1=复购，0=不复购）
  - 复购周期 reg_label  = 首购 → 第二次购买间隔天数（仅复购用户有值，供回归）

时序切分：按首购日切 train（<= 06-15）/ val（<= 07-15）/ test（其余），严格时序递增。
分层欠采样：复购概率负样本（不复购，多数）按 value_tier 分层欠采样到「负:正 ≈ 5」。

输出: data/lifecycle/repurchase_dataset/{mode}/{train|val|test}
用法: python scripts/lifecycle/repurchase_dataset.py --mode debug|dev|full|limit
"""
import os
import sys
import time
import argparse
from pyspark.sql import functions as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.lifecycle.config import *
from scripts.lifecycle.features import (
    load_product, build_static, build_first_buy_info, build_repurchase_features,
)


def _downsample_neg(neg, n_pos, ratio):
    """欠采样负样本（不复购，多数类）到 n_pos * ratio，按 value_tier 分层保持代表性"""
    target = int(n_pos * ratio)
    n_neg = neg.count()
    if n_neg <= target:
        print(f"  不复购样本 {n_neg:,} <= 目标 {target:,}，全量保留")
        return neg
    frac = target / n_neg
    neg = neg.fillna({"value_tier": "未知"})
    strata = [r["value_tier"] for r in neg.select("value_tier").distinct().collect()]
    fractions = {s: frac for s in strata}
    sampled = neg.sampleBy("value_tier", fractions, seed=NEG_SAMPLE_SEED)
    print(f"  分层欠采样不复购: {n_neg:,} -> 目标 {target:,} (比例 {frac:.3f}), 层数 {len(strata)}")
    return sampled


def build_repurchase_dataset(spark, mode):
    daily_path = os.path.join(DAILY_DIR, mode)
    out_root = os.path.join(REPURCHASE_DATASET_DIR, mode)
    print(f"[repurchase_dataset] 读取每日中间表: {daily_path}")
    daily = spark.read.parquet(daily_path)
    product = load_product(spark)
    static = build_static(spark)

    first_buy = build_first_buy_info(spark, daily, product)
    # 样本空间：首购日 <= 上限（保证首购 + 观察30 + 预测30 <= 数据末尾）
    first_buy = first_buy.filter(F.col("first_buy_date") <= F.lit(REPURCHASE_FIRST_BUY_MAX))
    n_users = first_buy.count()
    print(f"[repurchase_dataset] 首购用户（首购日 <= {REPURCHASE_FIRST_BUY_MAX}）: {n_users:,}")

    feats = build_repurchase_features(spark, daily, product, static, first_buy)

    # 标签：预测窗口 [first_buy+31, first_buy+60] 内是否有第 2 次购买
    pred_buy = daily.join(first_buy.select("user_id", "first_buy_date"), "user_id", "inner") \
        .filter(
            (F.col("action_date") > F.date_add(F.col("first_buy_date"), REPURCHASE_OBS_DAYS)) &
            (F.col("action_date") <= F.date_add(F.col("first_buy_date"),
                                                REPURCHASE_OBS_DAYS + REPURCHASE_PRED_DAYS)) &
            (F.col(BUY_COL) > 0)
        ).groupBy("user_id").agg(F.min("action_date").alias("second_buy_date"))

    samples = feats.join(pred_buy, "user_id", "left") \
        .withColumn("label", F.when(F.col("second_buy_date").isNotNull(), 1).otherwise(0)) \
        .withColumn("churn_reg_label",
                    F.when(F.col("second_buy_date").isNotNull(),
                           F.datediff(F.col("second_buy_date"), F.col("first_buy_date")))) \
        .drop("second_buy_date")

    # 时序切分（按首购日）
    samples = samples.withColumn(
        "split",
        F.when(F.col("first_buy_date") <= F.lit(REPURCHASE_TRAIN_END), "train")
        .when(F.col("first_buy_date") <= F.lit(REPURCHASE_VAL_END), "val")
        .otherwise("test"),
    )

    # 分层欠采样（train/val 的复购概率负样本；test 不采样反映自然分布）
    n_pos = samples.filter(F.col("label") == 1).count()
    n_neg = samples.filter(F.col("label") == 0).count()
    print(f"[repurchase_dataset] 复购概率样本 {n_pos + n_neg:,}（复购 {n_pos:,} / 不复购 {n_neg:,}）")

    if n_pos == 0:
        print("[repurchase_dataset] 无复购正样本（样本过小），无法构建。请用更大档位（dev/full/limit）。")
        return None

    pos = samples.filter(F.col("label") == 1)
    neg_train_val = samples.filter((F.col("label") == 0) & (F.col("split") != "test"))
    neg_test = samples.filter((F.col("label") == 0) & (F.col("split") == "test"))
    neg_train_val = _downsample_neg(neg_train_val, n_pos, REPURCHASE_POS_NEG_RATIO)
    # test 负样本随机抽样上限（反映自然分布 + 内存可控）
    n_neg_test = neg_test.count()
    if n_neg_test > TEST_NEG_MAX:
        neg_test = neg_test.sample(fraction=TEST_NEG_MAX / n_neg_test, seed=NEG_SAMPLE_SEED)

    samples = pos.unionByName(neg_train_val).unionByName(neg_test)

    for split in ["train", "val", "test"]:
        part = samples.filter(F.col("split") == split)
        part.write.mode("overwrite").option("compression", "snappy") \
            .parquet(os.path.join(out_root, split))
        print(f"[repurchase_dataset] {split}: {part.count():,} 样本 -> {os.path.join(out_root, split)}")

    return samples


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=MODES, default="dev")
    args = parser.parse_args()

    spark = create_spark(f"Lifecycle-Repurchase-{args.mode}")
    t0 = time.time()
    build_repurchase_dataset(spark, args.mode)
    print(f"[repurchase_dataset] 完成, 耗时 {(time.time() - t0) / 60:.1f} 分钟")
    spark.stop()


if __name__ == "__main__":
    main()
