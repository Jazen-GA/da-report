"""
用户级特征工程（流失预测 + 复购预测共用）
============================================
从 daily 中间表出发，产出 user 级特征：

流失特征（断面制，每个断面一个 user 级特征表）：
  - 历史稳定特征：购买频次 / 平均购买间隔 / 间隔波动率 / 首末购 / 价值层级
  - 活跃度衰减特征：近 7/14/30 天行为量与购买量、下滑幅度、连续无行为天数
  - 行为结构特征：近期各行为占比、收藏 / 加购意愿衰减
  - 品类匹配特征：偏好品类复购周期 vs 当前静默时长匹配度

复购特征（首购锚点制，每个首购用户一条）：
  - 首购行为：首购类目 / 品牌 / 决策路径 / 消费力估算
  - 用户基础：首购前活跃度 / 价值层级 / 品类偏好广度
  - 首购后互动：首购后 7/14/30 天回访、收藏加购、同类浏览
  - 口碑反馈：user 级评论聚合（review 无时间戳，全量聚合 → 已知未来泄露，标注）

时间合规：历史/近期特征只用 < pred_start 或观察窗口内数据；标签只用预测窗口。
价值层级（value_tier）与口碑为「运营画像」特征，来自全量 RFM / 全量评论，含未来
信息，对 train/val/test 均匀作用（不破坏时序一致性，但高估绝对性能），文档标注。
"""
import os
import sys
from pyspark.sql import functions as F
from pyspark.sql import Window

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.lifecycle.config import *


# ── 通用工具 ──

def _ratio(num_col, den_col):
    """安全除法，分母 <= 0 返回 0"""
    return F.when(F.col(den_col) > 0, F.col(num_col) / F.col(den_col)).otherwise(0.0)


def load_product(spark):
    """product 表解析为规范视图：item_id / parent_cat / leaf_cat / brand_id / seller_id"""
    cat_col = F.col(COL["product_category"])
    return spark.read.parquet(PRODUCT_PATH) \
        .withColumn("parent_cat", F.split(cat_col, CATEGORY_SPLIT).getItem(CATEGORY_PARENT_IDX).cast("int")) \
        .withColumn("leaf_cat", F.split(cat_col, CATEGORY_SPLIT).getItem(CATEGORY_LEAF_IDX).cast("int")) \
        .select(
            F.col(COL["item_id"]).alias("item_id"),
            "parent_cat", "leaf_cat",
            F.col(COL["product_brand"]).alias("brand_id"),
            F.col(COL["product_seller"]).alias("seller_id"),
        )


# ── 静态画像 + 品类周期基准（断面无关，一次算好复用）──

def build_static(spark):
    """运营画像特征：价值层级（value_score）+ 口碑（review_pred 全量聚合）。

    含未来信息（value_tier 的 R 维度基于全量 RFM、review 无时间戳），标注为已知泄露，
    对 train/val/test 均匀作用。value_score 只覆盖成交用户，与流失/复购样本空间一致。
    """
    value = spark.read.parquet(VALUE_SCORE_PATH).select(
        "user_id", "value_tier", "value_subtier", "total_score",
    )
    review = spark.read.parquet(REVIEW_PRED_PATH).select("user_id", "label", "prob") \
        .groupBy("user_id").agg(
            F.count("*").alias("rv_cnt"),
            F.avg("label").alias("rv_pos_rate"),
            F.avg("prob").alias("rv_avg_sentiment"),
        )
    return value.join(review, "user_id", "left")


def build_category_cycle(spark, daily, product):
    """品类复购周期基准：每个 parent_cat 内同一用户相邻两次购买间隔的中位数。

    从全历史购买序列统计，属「业务基准」，不随断面变化。
    """
    p = F.broadcast(product.select("item_id", "parent_cat"))
    buys = daily.filter(F.col(BUY_COL) > 0).select("user_id", "item_id", "action_date") \
        .join(p, "item_id", "left").filter(F.col("parent_cat").isNotNull())

    w = Window.partitionBy("user_id", "parent_cat").orderBy("action_date")
    gaps = buys.withColumn("_prev", F.lag("action_date").over(w)) \
        .withColumn("_gap", F.datediff("action_date", "_prev")) \
        .filter(F.col("_gap").isNotNull())

    return gaps.groupBy("parent_cat").agg(
        F.percentile_approx("_gap", 0.5).alias("cat_cycle_days"),
        F.count("*").alias("cat_cycle_n"),
    )


def build_item_consumption(spark):
    """item 级单笔消费力估算（首购消费力特征，复用 user_value RFM 的 M 维度口径）。

    consumption = 品类价值权重 w_cat(1~5) × 品牌层级 w_brand(头部3/腰部2/尾部1)
                  × log1p(item_sales)
    口径与 scripts/user_value/build_rfm.py 完全一致：w_cat 用一级类目销量热度分 5 档，
    w_brand 用品牌 score 排名分位切头部/腰部/尾部。此处按 item 粒度落表，供首购锚点 join。

    数据无真实金额字段，消费力只能用「品类热度 × 品牌梯队 × 销量热度」proxy，文档标注。
    返回 item_id -> consumption 广播小表。
    """
    import numpy as np
    import pandas as pd

    # 品类价值权重：一级类目销量热度分 5 档（1~5），string 对齐 build_rfm 口径
    pc = pd.read_csv(PARENT_CAT_METRICS_CSV)[["parent_cat", "sales_cnt"]]
    qs = pc["sales_cnt"].quantile([0.2, 0.4, 0.6, 0.8]).tolist()

    def _w(s):
        for i, q in enumerate(qs):
            if s <= q:
                return i + 1
        return 5

    pc["w_cat"] = pc["sales_cnt"].apply(_w)
    w_cat = spark.createDataFrame(
        pc[["parent_cat", "w_cat"]].astype({"w_cat": "int64"})
    ).withColumn("parent_cat", F.col("parent_cat").cast("string"))

    # 品牌层级：score 排名分位切头部/腰部/尾部（复现 category_brand_analysis 梯队口径）
    bm = pd.read_csv(BRAND_METRICS_CSV)
    bm = bm[bm["brand_label"] != "未标注"].copy()
    bm["conv"] = bm["sales_cnt"] / bm["click_cnt"].replace(0, np.nan)

    def _mm(s):
        return (s - s.min()) / (s.max() - s.min()) if s.max() > s.min() else s * 0

    bm["score"] = (
        0.35 * _mm(np.log1p(bm["click_cnt"]))
        + 0.35 * _mm(np.log1p(bm["sales_cnt"]))
        + 0.30 * _mm(bm["conv"].fillna(0))
    )
    bm["rank_pct"] = bm["score"].rank(ascending=False, pct=True)
    bm["tier"] = np.where(bm["rank_pct"] <= 0.05, "头部",
                          np.where(bm["rank_pct"] <= 0.25, "腰部", "尾部"))
    bm["w_brand"] = bm["tier"].map({"头部": 3, "腰部": 2, "尾部": 1})
    w_brand = spark.createDataFrame(
        bm[["brand_label", "w_brand"]].astype({"w_brand": "int64"})
    )

    # item 级消费力（动销商品，销量热度 = 该商品被购买次数）
    item = (
        spark.read.parquet(ITEM_OPS_PATH)
        .select(
            "item_id",
            F.col("parent_cat").cast("string").alias("parent_cat"),
            "brand_id",
            F.col("alipay_cnt").alias("item_sales"),
        )
        .filter(F.col("item_sales") > 0)
    )
    return (
        item.join(F.broadcast(w_cat), "parent_cat", "left")
        .join(F.broadcast(w_brand), item["brand_id"] == w_brand["brand_label"], "left")
        .drop(w_brand["brand_label"])
        .withColumn("w_cat", F.coalesce("w_cat", F.lit(1)))
        .withColumn("w_brand", F.coalesce("w_brand", F.lit(1)))
        .withColumn("consumption", F.col("w_cat") * F.col("w_brand") * F.log1p("item_sales"))
        .select("item_id", "consumption")
    )


# ── 流失特征（断面制）──

def build_churn_features(spark, daily, w, product, static, cat_cycle):
    """对一个断面计算 user 级流失特征，返回 user_id + slice_id + 特征列。

    历史特征 [DATA_START, pred_start)，近期特征 [obs_start, obs_end]。
    """
    slice_id = w["slice_id"]
    pred_start = w["pred_start"]
    obs_start, obs_end = w["obs_start"], w["obs_end"]

    # ── 历史稳定特征（截至 pred_start 的全历史）──
    hist = daily.filter(F.col("action_date") < pred_start)
    hist_buy = hist.filter(F.col(BUY_COL) > 0)

    hist_agg = hist.groupBy("user_id").agg(
        F.countDistinct("action_date").alias("hist_active_days"),
        F.sum("total_cnt").alias("hist_total_actions"),
        F.max("action_date").alias("hist_last_action_date"),
    )
    buy_agg = hist_buy.groupBy("user_id").agg(
        F.sum(BUY_COL).alias("hist_buy_cnt"),
        F.countDistinct("item_id").alias("hist_distinct_item"),
        F.min("action_date").alias("hist_first_buy_date"),
        F.max("action_date").alias("hist_last_buy_date"),
    )
    hist_feat = hist_agg.join(buy_agg, "user_id", "left")

    # 购买间隔均值 / 波动率（对购买日序列算相邻间隔）
    w_buy = Window.partitionBy("user_id").orderBy("action_date")
    buy_seq = hist_buy.select("user_id", "action_date").distinct() \
        .withColumn("_prev", F.lag("action_date").over(w_buy)) \
        .withColumn("_gap", F.datediff("action_date", "_prev")) \
        .filter(F.col("_gap").isNotNull())
    gap_stat = buy_seq.groupBy("user_id").agg(
        F.avg("_gap").alias("hist_buy_interval_mean"),
        F.stddev("_gap").alias("hist_buy_interval_std"),
    )
    hist_feat = hist_feat.join(gap_stat, "user_id", "left")

    hist_feat = hist_feat.withColumn(
        "hist_recency_days",
        F.when(F.col("hist_last_buy_date").isNotNull(),
               F.datediff(F.lit(pred_start).cast("date"), F.col("hist_last_buy_date"))),
    ).withColumn(
        "hist_buy_tenure_days",
        F.when(F.col("hist_buy_cnt") >= 2,
               F.datediff(F.col("hist_last_buy_date"), F.col("hist_first_buy_date"))),
    )

    # ── 近期衰减特征（观察窗口 [obs_start, obs_end]）──
    obs = daily.filter(
        (F.col("action_date") >= obs_start) & (F.col("action_date") <= obs_end)
    ).withColumn("days_ago", F.datediff(F.lit(obs_end).cast("date"), F.col("action_date")))

    rec_exprs = []
    for wd in FEATURE_WINDOWS:
        cond = F.col("days_ago") < wd
        rec_exprs.append(F.sum(F.when(cond, F.col("total_cnt")).otherwise(0)).alias(f"rec_actions_{wd}d"))
        rec_exprs.append(F.sum(F.when(cond, F.col(BUY_COL)).otherwise(0)).alias(f"rec_buy_{wd}d"))
        rec_exprs.append(F.sum(F.when(cond, F.col(f"{ACTION_COLLECT}_cnt") + F.col(f"{ACTION_CART}_cnt"))
                              .otherwise(0)).alias(f"rec_collect_cart_{wd}d"))
        # 各行为单独计数（供行为结构占比特征 ratio_*_30d）
        for a in ACTION_VALUES:
            rec_exprs.append(F.sum(F.when(cond, F.col(f"{a}_cnt")).otherwise(0)).alias(f"rec_{a}_cnt_{wd}d"))
    # 前 14 天（14 <= days_ago < 28）用于下滑幅度
    prev_cond = (F.col("days_ago") >= 14) & (F.col("days_ago") < 28)
    rec_exprs += [
        F.sum(F.when(prev_cond, F.col("total_cnt")).otherwise(0)).alias("rec_actions_prev14d"),
        F.sum(F.when(prev_cond, F.col(BUY_COL)).otherwise(0)).alias("rec_buy_prev14d"),
        F.sum(F.when(prev_cond, F.col(f"{ACTION_COLLECT}_cnt") + F.col(f"{ACTION_CART}_cnt"))
              .otherwise(0)).alias("rec_collect_cart_prev14d"),
    ]
    rec_feat = obs.groupBy("user_id").agg(*rec_exprs)

    # 近期各行为占比（近 30 天）
    rec_feat = rec_feat.withColumn("ratio_click_30d", _ratio(f"rec_{ACTION_CLICK}_cnt_30d", "rec_actions_30d")) \
        .withColumn("ratio_collect_30d", _ratio(f"rec_{ACTION_COLLECT}_cnt_30d", "rec_actions_30d")) \
        .withColumn("ratio_cart_30d", _ratio(f"rec_{ACTION_CART}_cnt_30d", "rec_actions_30d")) \
        .withColumn("ratio_buy_30d", _ratio(f"rec_buy_30d", "rec_actions_30d"))

    # 下滑幅度 = (近14 - 前14) / 前14（前 14 为 0 时记 0）
    rec_feat = rec_feat.withColumn(
        "decay_actions_14d",
        F.when(F.col("rec_actions_prev14d") > 0,
               (F.col("rec_actions_14d") - F.col("rec_actions_prev14d")) / F.col("rec_actions_prev14d"))
        .otherwise(0.0),
    ).withColumn(
        "decay_buy_14d",
        F.when(F.col("rec_buy_prev14d") > 0,
               (F.col("rec_buy_14d") - F.col("rec_buy_prev14d")) / F.col("rec_buy_prev14d"))
        .otherwise(0.0),
    ).withColumn(
        "decay_collect_cart_14d",
        F.when(F.col("rec_collect_cart_prev14d") > 0,
               (F.col("rec_collect_cart_14d") - F.col("rec_collect_cart_prev14d")) / F.col("rec_collect_cart_prev14d"))
        .otherwise(0.0),
    )

    # ── 合并历史 + 近期 ──
    feat = hist_feat.join(rec_feat, "user_id", "left")

    # 连续无行为天数 / 最近行为距 obs_end（历史最后行为可能在观察窗口内，取 max）
    feat = feat.withColumn(
        "days_since_last_action",
        F.when(F.col("hist_last_action_date").isNotNull(),
               F.datediff(F.lit(obs_end).cast("date"), F.col("hist_last_action_date"))),
    ).withColumn(
        "days_since_last_buy",
        F.when(F.col("hist_last_buy_date").isNotNull(),
               F.datediff(F.lit(obs_end).cast("date"), F.col("hist_last_buy_date")))
        .otherwise(F.lit(CHURN_OBS_DAYS)),
    )

    # ── 品类匹配特征：偏好品类复购周期 vs 当前静默时长 ──
    p = F.broadcast(product.select("item_id", "parent_cat"))
    hist_cat = hist_buy.join(p, "item_id", "left") \
        .groupBy("user_id", "parent_cat").agg(F.sum(BUY_COL).alias("_cat_buy"))
    w_cat = Window.partitionBy("user_id").orderBy(F.desc("_cat_buy"))
    top_cat = hist_cat.withColumn("_rank", F.row_number().over(w_cat)) \
        .filter(F.col("_rank") == 1) \
        .select("user_id", F.col("parent_cat").alias("hist_top_cat"))
    feat = feat.join(top_cat, "user_id", "left")
    feat = feat.join(F.broadcast(cat_cycle), feat["hist_top_cat"] == cat_cycle["parent_cat"], "left") \
        .drop(cat_cycle["parent_cat"])
    feat = feat.withColumn(
        "cat_match",
        F.when((F.col("cat_cycle_days").isNotNull()) & (F.col("cat_cycle_days") > 0),
               F.col("days_since_last_buy") / F.col("cat_cycle_days"))
        .otherwise(F.lit(0.0)),
    ).drop("cat_cycle_days", "cat_cycle_n")

    # ── 价值层级（运营画像，join 静态表）──
    feat = feat.join(F.broadcast(static), "user_id", "left")

    # 派生完成后剔除日期中间列（date 类型不进特征/预处理）
    feat = feat.drop("hist_last_action_date", "hist_first_buy_date", "hist_last_buy_date")

    return feat.select("user_id", *[c for c in feat.columns if c != "user_id"]) \
        .withColumn("slice_id", F.lit(slice_id))


# ── 复购特征（首购锚点制）──

def build_first_buy_info(spark, daily, product):
    """每个用户的首购信息：首购日 / 首购商品 / 类目 / 品牌 / 决策路径。

    首购 = 用户第一次 alipay 的 (date, item)。决策路径：首购 item 在首购日之前
    是否有收藏 / 加购（有 → 决策型 1，无 → 冲动型 0）。
    """
    p = F.broadcast(product.select("item_id", "parent_cat", "leaf_cat", "brand_id"))
    buys = daily.filter(F.col(BUY_COL) > 0).select("user_id", "item_id", "action_date")

    # 每个用户最早购买日，再在该日取一个商品（按 item_id 稳定取）
    first_date = buys.groupBy("user_id").agg(F.min("action_date").alias("first_buy_date"))
    first_item = buys.join(first_date, "user_id", "inner") \
        .filter(F.col("action_date") == F.col("first_buy_date")) \
        .groupBy("user_id").agg(F.min("item_id").alias("first_item_id"))
    first_buy = first_date.join(first_item, "user_id") \
        .join(p, first_item["first_item_id"] == p["item_id"], "left") \
        .drop(p["item_id"])

    # 首购决策路径：首购 item 在首购日之前是否有 collect / cart（有 → 决策型 1）
    intent = daily.join(first_buy.select("user_id", "first_item_id", "first_buy_date"), "user_id", "inner") \
        .filter((F.col("item_id") == F.col("first_item_id")) &
                (F.col("action_date") < F.col("first_buy_date")) &
                ((F.col(f"{ACTION_COLLECT}_cnt") > 0) | (F.col(f"{ACTION_CART}_cnt") > 0))) \
        .select("user_id").distinct().withColumn("first_decision_path", F.lit(1))

    first_buy = first_buy.join(intent, "user_id", "left") \
        .withColumn("first_decision_path", F.coalesce(F.col("first_decision_path"), F.lit(0)))

    # 首购消费力估算（复用 RFM M 维度口径的 item 级 proxy，join 首购商品）
    consumption = build_item_consumption(spark)
    first_buy = first_buy.join(
        F.broadcast(consumption), first_buy["first_item_id"] == consumption["item_id"], "left"
    ).drop(consumption["item_id"])

    return first_buy.select(
        "user_id", "first_buy_date", "first_item_id",
        F.col("parent_cat").alias("first_cat"),
        F.col("leaf_cat").alias("first_leaf_cat"),
        F.col("brand_id").alias("first_brand"),
        "first_decision_path",
        F.col("consumption").alias("first_consumption"),
    )


def build_repurchase_features(spark, daily, product, static, first_buy):
    """复购特征（user 级，首购锚点制）。

    首购后观察窗口 [first_buy+1, first_buy+30]（互动特征），预测窗口 [first_buy+31, first_buy+60]（标签）。
    用字符串 "user_id" join（first_buy 已含首购列，与 daily 的 item_id/action_date 无列名冲突）。
    """
    p = F.broadcast(product.select("item_id", "parent_cat"))

    # ── 首购前基础特征（action_date < first_buy_date）──
    pre = daily.join(first_buy, "user_id", "inner") \
        .filter(F.col("action_date") < F.col("first_buy_date"))
    pre_feat = pre.groupBy("user_id").agg(
        F.sum("total_cnt").alias("pre_actions"),
        F.countDistinct("action_date").alias("pre_active_days"),
        F.sum(F.col(f"{ACTION_COLLECT}_cnt") + F.col(f"{ACTION_CART}_cnt")).alias("pre_collect_cart"),
    )
    # 首购前浏览品类广度
    pre_cat = pre.join(p, "item_id", "left") \
        .groupBy("user_id").agg(F.countDistinct("parent_cat").alias("pre_distinct_cat"))
    pre_feat = pre_feat.join(pre_cat, "user_id", "left")

    # ── 首购后互动特征（first_buy < action_date <= first_buy + 30）──
    post = daily.join(first_buy, "user_id", "inner") \
        .filter((F.col("action_date") > F.col("first_buy_date")) &
                (F.col("action_date") <= F.date_add(F.col("first_buy_date"), REPURCHASE_OBS_DAYS))) \
        .withColumn("post_days_ago",
                    F.datediff(F.date_add(F.col("first_buy_date"), REPURCHASE_OBS_DAYS), F.col("action_date")))

    post_exprs = []
    for wd in [7, 14, 30]:
        cond = F.col("post_days_ago") < wd
        post_exprs += [
            F.sum(F.when(cond, F.col("total_cnt")).otherwise(0)).alias(f"post_actions_{wd}d"),
            F.sum(F.when(cond, F.col(f"{ACTION_COLLECT}_cnt") + F.col(f"{ACTION_CART}_cnt"))
                  .otherwise(0)).alias(f"post_collect_cart_{wd}d"),
        ]
    post_feat = post.groupBy("user_id").agg(*post_exprs)

    # 首购后同类商品浏览（首购品类下，非首购商品的行为）
    same_cat = post.join(p, "item_id", "left") \
        .filter((F.col("parent_cat") == F.col("first_cat")) & (F.col("item_id") != F.col("first_item_id")))
    same_cat_feat = same_cat.groupBy("user_id") \
        .agg(F.sum("total_cnt").alias("post_same_cat_actions"))

    # ── 合并 ──
    feat = first_buy.select("user_id", "first_buy_date", "first_cat", "first_leaf_cat",
                            "first_brand", "first_decision_path", "first_consumption") \
        .join(pre_feat, "user_id", "left") \
        .join(post_feat, "user_id", "left") \
        .join(same_cat_feat, "user_id", "left") \
        .join(F.broadcast(static), "user_id", "left")

    return feat.fillna(0.0, subset=[
        "pre_actions", "pre_active_days", "pre_collect_cart", "pre_distinct_cat",
        "post_actions_7d", "post_actions_14d", "post_actions_30d",
        "post_collect_cart_7d", "post_collect_cart_14d", "post_collect_cart_30d",
        "post_same_cat_actions", "first_consumption",
    ])
