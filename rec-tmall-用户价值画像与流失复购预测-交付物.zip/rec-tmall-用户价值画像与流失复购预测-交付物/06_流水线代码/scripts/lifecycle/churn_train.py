"""
流失预测模型训练与评估
========================
LR + XGBoost 两基线，验证集调优，测试集评估（AUC/召回/精确/F1），特征重要性，
输出高流失风险用户清单（按流失概率降序）+ 高价值×高流失风险子清单。

输出:
  data/lifecycle/model/churn/{model}.joblib      模型
  data/lifecycle/model/churn/preprocess.joblib   预处理参数 + 目标编码映射（供推理）
  data/lifecycle/metrics/churn_metrics.json      评估指标
  data/lifecycle/metrics/churn_importance_{m}.csv  特征重要性
  data/lifecycle/metrics/churn_risk_list.csv     高流失风险清单（test 集）
用法: python scripts/lifecycle/churn_train.py --mode debug|dev|full|limit
"""
import os
import sys
import time
import argparse
import numpy as np
import pandas as pd
import joblib

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.lifecycle.config import *
from scripts.lifecycle.train_utils import (
    load_all, numeric_cols, fit_preprocess, transform_preprocess,
    build_feature_matrix, fit_classifier, compute_regression_metrics,
)
from scripts.modeling.model_utils import (
    compute_metrics, feature_importance, save_model, write_json,
    target_encode_fit, target_encode_apply_map,
)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=MODES, default="dev")
    args = parser.parse_args()
    mode = args.mode

    root = CHURN_DATASET_DIR
    if not os.path.isdir(os.path.join(root, mode, "train")):
        print(f"[churn_train] 未找到 churn_dataset/{mode}/train，先跑 churn_dataset.py。")
        return

    t0 = time.time()
    train, val, test = load_all(root, mode)
    cat_cols = CHURN_CAT_COLS
    num_cols = numeric_cols(train, cat_cols)
    print(f"[churn_train] train {len(train):,} / val {len(val):,} / test {len(test):,}；"
          f"数值 {len(num_cols)} 列，类别 {len(cat_cols)} 列")

    # 类别列缺失填「未知」
    for df in (train, val, test):
        df[cat_cols] = df[cat_cols].fillna("未知")

    # 预处理（train 拟合）
    params = fit_preprocess(train, num_cols)
    train = transform_preprocess(train, num_cols, params)
    val = transform_preprocess(val, num_cols, params)
    test = transform_preprocess(test, num_cols, params)

    # 目标编码（train 拟合，套 val/test）
    y_train = train["label"].astype(float)
    X_cat_train = train[cat_cols]
    te_maps = target_encode_fit(X_cat_train, y_train, smooth=TARGET_ENCODING_SMOOTH)
    global_mean = float(y_train.mean())
    te_train = target_encode_apply_map(X_cat_train, te_maps, global_mean)
    te_val = target_encode_apply_map(val[cat_cols], te_maps, global_mean)
    te_test = target_encode_apply_map(test[cat_cols], te_maps, global_mean)

    X_train = build_feature_matrix(train, cat_cols, te_train)
    X_val = build_feature_matrix(val, cat_cols, te_val)
    X_test = build_feature_matrix(test, cat_cols, te_test)
    feature_names = list(X_train.columns)

    # 训练 + 评估
    results = {}
    best_model_name, best_auc = None, -1.0
    test_probs = {}
    for model_name in ["lr", "xgb"]:
        model, _ = fit_classifier(model_name, X_train, y_train, X_val, val["label"].astype(float))
        test_prob = model.predict_proba(X_test)[:, 1]
        test_probs[model_name] = test_prob
        m = compute_metrics(test["label"], test_prob)
        results[model_name] = m
        print(f"[churn_train] {model_name}: test AUC={m['auc']} AP={m['ap']} "
              f"recall={m['recall']} precision={m['precision']} F1={m['f1']}")

        imp = feature_importance(model_name, model, feature_names)
        imp_path = os.path.join(METRICS_DIR, f"churn_importance_{model_name}.csv")
        imp.to_csv(imp_path, encoding="utf-8-sig")
        print(f"[churn_train] {model_name} 特征重要性 -> {imp_path}")

        save_model(model, os.path.join(MODEL_DIR, "churn", f"{model_name}.joblib"))
        if m["auc"] > best_auc:
            best_auc, best_model_name = m["auc"], model_name

    # 保存预处理 + 目标编码（供 infer 复用）
    preprocess_bundle = {
        "params": params, "te_maps": {k: v.to_dict() for k, v in te_maps.items()},
        "global_mean": global_mean, "num_cols": num_cols, "cat_cols": cat_cols,
        "feature_names": feature_names,
    }
    bundle_path = os.path.join(MODEL_DIR, "churn", "preprocess.joblib")
    os.makedirs(os.path.dirname(bundle_path), exist_ok=True)
    joblib.dump(preprocess_bundle, bundle_path)

    # 评估结果落盘
    write_json({"mode": mode, "best_model": best_model_name, "metrics": results},
               os.path.join(METRICS_DIR, "churn_metrics.json"))

    # 高流失风险清单（最优模型对 test 推理，按概率降序）
    best_prob = test_probs[best_model_name]
    risk = test[["user_id", "value_tier", "value_subtier", "label"]].copy()
    risk["churn_prob"] = best_prob
    risk = risk.sort_values("churn_prob", ascending=False)
    risk_path = os.path.join(METRICS_DIR, "churn_risk_list.csv")
    risk.to_csv(risk_path, index=False, encoding="utf-8-sig")

    # 高价值 × 高流失风险子清单（value_tier == 高价值 且 概率 >= 0.5）
    high_value_risk = risk[(risk["value_tier"] == "高价值") & (risk["churn_prob"] >= 0.5)]
    hv_path = os.path.join(METRICS_DIR, "churn_high_value_risk_list.csv")
    high_value_risk.to_csv(hv_path, index=False, encoding="utf-8-sig")

    print(f"[churn_train] 最优模型 {best_model_name} (test AUC {best_auc:.4f})")
    print(f"[churn_train] 高流失风险清单 {len(risk):,} 条 -> {risk_path}")
    print(f"[churn_train] 高价值×高流失 {len(high_value_risk):,} 条 -> {hv_path}")
    print(f"[churn_train] 完成, 耗时 {(time.time() - t0) / 60:.1f} 分钟")


if __name__ == "__main__":
    main()
