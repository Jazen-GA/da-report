#!/usr/bin/env bash
# 用户生命周期预测（流失 + 复购）一键端到端
# 用法: bash scripts/lifecycle/run_lifecycle.sh [dev|limit|full|debug] [--skip-aggregate]
#   第二参数 --skip-aggregate 复用已有 daily 中间表（建模阶段已生成时用）
set -e

MODE="${1:-dev}"
SKIP_AGG="${2:-}"

cd "$(dirname "$0")/../.."
if [ -f venv/bin/activate ]; then
  source venv/bin/activate
fi

echo "======================================================"
echo " 用户生命周期预测 pipeline（mode=$MODE）"
echo "======================================================"

if [ "$SKIP_AGG" != "--skip-aggregate" ]; then
  echo ">>> [1/8] 每日行为中间表 aggregate"
  python scripts/modeling/aggregate.py --mode "$MODE"
else
  echo ">>> [1/8] 跳过 aggregate（复用已有 daily 表）"
fi

echo ">>> [2/8] 流失样本构建（标签 + 分层采样 + 时序切分）"
python scripts/lifecycle/churn_dataset.py --mode "$MODE"

echo ">>> [3/8] 复购样本构建（概率 + 周期双任务）"
python scripts/lifecycle/repurchase_dataset.py --mode "$MODE"

echo ">>> [4/8] 时间合规校验"
python scripts/lifecycle/leakage_check.py --mode "$MODE"

echo ">>> [5/8] 流失模型训练（LR + XGBoost）"
python scripts/lifecycle/churn_train.py --mode "$MODE"

echo ">>> [6/8] 复购模型训练（分类 + 回归）"
python scripts/lifecycle/repurchase_train.py --mode "$MODE"

echo ">>> [7/8] 全量推理（流失概率 + 复购概率 + 周期）"
python scripts/lifecycle/infer.py --mode "$MODE"

echo ">>> [8/8] 运营建议报告"
python scripts/lifecycle/generate_report.py --mode "$MODE"

echo "======================================================"
echo " 完成。报告 -> reports/lifecycle/user_lifecycle_report.html"
echo "======================================================"
