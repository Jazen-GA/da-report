"""
生命周期模块共享训练框架（分类 + 回归）
==========================================
流失预测与复购预测共用的 pandas 侧「预处理 → 目标编码 → 分类/回归训练 → 指标」通用函数。

复用 scripts/modeling/model_utils.py 的纯函数（指标 / 特征重要性 / 目标编码 / 持久化）；
分类/回归训练因模型参数与任务不同，在此实现（用户级样本量小，pandas + sklearn 足够，
不再走 Spark 的 preprocess）。
"""
import os
import sys
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from scripts.lifecycle.config import *
from scripts.modeling.model_utils import (
    compute_metrics, compute_pr_curve, feature_importance,
    save_model, load_model, write_json,
    target_encode_train, target_encode_apply, target_encode_fit, target_encode_apply_map,
)
from sklearn.metrics import roc_auc_score, mean_absolute_error, mean_squared_error


# ── 数据读取 ──

def load_split(root, mode, split):
    return pd.read_parquet(os.path.join(root, mode, split))


def load_all(root, mode):
    return load_split(root, mode, "train"), load_split(root, mode, "val"), load_split(root, mode, "test")


def numeric_cols(df, cat_cols):
    """数值特征列 = 全部列 - 元数据 - 类别（类别列由调用方传入）"""
    return [c for c in df.columns if c not in META_COLS and c not in cat_cols]


# ── pandas 预处理（train 拟合，防泄露）──

def fit_preprocess(train, num_cols):
    """只用 train 拟合 clip 分位数 / 标准化 mean-std，返回 params"""
    params = {}
    if PREPROCESS.get("clip_quantiles"):
        lo, hi = PREPROCESS["clip_quantiles"]
        params["clip"] = {c: (float(train[c].quantile(lo)), float(train[c].quantile(hi)))
                          for c in num_cols if c in train.columns and train[c].notna().any()}
    if PREPROCESS.get("standardize"):
        params["scale"] = {c: (float(train[c].mean()), float(train[c].std()))
                           for c in num_cols if c in train.columns and train[c].std() > 0}
    return params


def transform_preprocess(df, num_cols, params):
    """套用 fit 参数（缺失填充 / 截断 / 标准化），不学习任何新参数"""
    df = df.copy()
    fill = PREPROCESS.get("fill_numeric_na")
    if fill is not None:
        cols = [c for c in num_cols if c in df.columns]
        df[cols] = df[cols].fillna(float(fill))
    for c, (lo, hi) in params.get("clip", {}).items():
        if c in df.columns:
            df[c] = df[c].clip(lo, hi)
    for c, (m, s) in params.get("scale", {}).items():
        if c in df.columns:
            df[c] = (df[c] - m) / s
    return df


def build_feature_matrix(df, cat_cols, target_enc=None):
    """数值特征 + 目标编码列 → X DataFrame（保留列名供树模型识别）"""
    num = [c for c in df.columns if c not in META_COLS and c not in cat_cols]
    X = df[num].astype(float).copy()
    if target_enc is not None:
        for c in target_enc.columns:
            X[f"{c}_te"] = target_enc[c].astype(float).values
    return X


# ── 分类训练（流失 / 复购概率，LR + XGBoost）──

def fit_classifier(model_name, X_train, y_train, X_val, y_val):
    """训练单个分类模型，返回 (model, val_pred_proba)。按 val AUC 网格调优。"""
    params = dict(MODEL_PARAMS[model_name])

    if model_name == "lr":
        from sklearn.linear_model import LogisticRegression
        best_auc, best_m = -1.0, None
        for C in LR_C_GRID:
            cand = LogisticRegression(**{**params, "C": C})
            cand.fit(X_train, y_train)
            auc = roc_auc_score(y_val, cand.predict_proba(X_val)[:, 1])
            if auc > best_auc:
                best_auc, best_m = auc, cand
        m = best_m

    elif model_name == "xgb":
        import xgboost as xgb
        n_pos = int(y_train.sum())
        n_neg = len(y_train) - n_pos
        best_auc, best_m = -1.0, None
        for lr in XGB_GRID["learning_rate"]:
            for md in XGB_GRID["max_depth"]:
                p = {**params, "learning_rate": lr, "max_depth": md}
                if not p.get("scale_pos_weight"):
                    p["scale_pos_weight"] = n_neg / max(n_pos, 1)
                cand = xgb.XGBClassifier(**p)  # early_stopping_rounds 是构造参数（XGB 2.x）
                cand.fit(X_train, y_train, eval_set=[(X_val, y_val)], verbose=False)
                auc = roc_auc_score(y_val, cand.predict_proba(X_val)[:, 1])
                if auc > best_auc:
                    best_auc, best_m = auc, cand
        m = best_m

    else:
        raise ValueError(f"未知分类模型: {model_name}（可选 lr/xgb）")

    val_prob = m.predict_proba(X_val)[:, 1]
    return m, val_prob


# ── 回归训练（复购周期，LightGBM / XGBoost regressor）──

def fit_regressor(model_name, X_train, y_train, X_val, y_val):
    """训练单个回归模型，返回 (model, val_pred)。按 val RMSE 网格调优。"""
    params = dict(REGRESSION_MODEL_PARAMS[model_name])

    if model_name == "lgb":
        import lightgbm as lgb
        best_rmse, best_m = float("inf"), None
        for lr in LGB_REGRESSION_GRID["learning_rate"]:
            for nl in LGB_REGRESSION_GRID["num_leaves"]:
                p = {**params, "learning_rate": lr, "num_leaves": nl}
                esr = p.pop("early_stopping_rounds", 100)
                cand = lgb.LGBMRegressor(**p)
                cand.fit(X_train, y_train,
                         eval_set=[(X_val, y_val)], eval_metric="rmse",
                         callbacks=[lgb.early_stopping(esr, verbose=False)])
                rmse = float(np.sqrt(mean_squared_error(y_val, cand.predict(X_val))))
                if rmse < best_rmse:
                    best_rmse, best_m = rmse, cand
        m = best_m

    elif model_name == "xgb":
        import xgboost as xgb
        best_rmse, best_m = float("inf"), None
        for lr in XGB_REGRESSION_GRID["learning_rate"]:
            for md in XGB_REGRESSION_GRID["max_depth"]:
                p = {**params, "learning_rate": lr, "max_depth": md}
                cand = xgb.XGBRegressor(**p)
                cand.fit(X_train, y_train, eval_set=[(X_val, y_val)], verbose=False)
                rmse = float(np.sqrt(mean_squared_error(y_val, cand.predict(X_val))))
                if rmse < best_rmse:
                    best_rmse, best_m = rmse, cand
        m = best_m

    else:
        raise ValueError(f"未知回归模型: {model_name}（可选 lgb/xgb）")

    val_pred = m.predict(X_val)
    return m, val_pred


# ── 回归指标 ──

def compute_regression_metrics(y_true, y_pred):
    return {
        "mae": round(float(mean_absolute_error(y_true, y_pred)), 4),
        "rmse": round(float(np.sqrt(mean_squared_error(y_true, y_pred))), 4),
    }
