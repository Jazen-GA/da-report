# -*- coding: utf-8 -*-
"""
用户价值画像模块配置
====================
集中管理业务口径可调项:行为权重、RFM 维度权重、品牌梯队权重、分箱参数、
分层规则、标签阈值、标签字典。路径 / Spark 定义复用 scripts/config.py,不重复。
"""
import os
import sys

# 使 scripts/ 可被 import(拿到全局 config 的路径与字段常量)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import (  # noqa: E402,F401
    DATA_SAMPLES,
    DATA_CLEANED,
    REPORTS_DIR,
    SENTIMENT_OUTPUT_DIR,
    create_spark,
)

# ═══════════════════════════════════════════════════════════════
# 输出路径(本模块中间表 / 报告)
# ═══════════════════════════════════════════════════════════════
UV_DATA = os.path.join(DATA_SAMPLES, "user_value")
RFM_PATH = os.path.join(UV_DATA, "rfm")              # a.1 成交用户 RFM 明细
SCORE_PATH = os.path.join(UV_DATA, "value_score")    # a.2 评分 + 分层
TAGS_PATH = os.path.join(UV_DATA, "tags")            # b.2 各维标签(分目录)
WIDE_PATH = os.path.join(UV_DATA, "tag_wide")        # b.3 标签宽表
UV_REPORTS = os.path.join(REPORTS_DIR, "user_value")
UV_CHARTS = os.path.join(UV_REPORTS, "charts")

# 复用已有资产(只读,不重算)
BRAND_TIERS_CSV = os.path.join(REPORTS_DIR, "brand_tiers.csv")
BRAND_METRICS_CSV = os.path.join(REPORTS_DIR, "brand_metrics.csv")
PARENT_CAT_CSV = os.path.join(REPORTS_DIR, "parent_category_metrics.csv")
LEAF_CAT_CSV = os.path.join(REPORTS_DIR, "leaf_category_metrics.csv")
USER_LABELS_PATH = os.path.join(DATA_SAMPLES, "user_labels")
REVIEW_PRED_PATH = os.path.join(SENTIMENT_OUTPUT_DIR, "review_pred.parquet")
CLEANED_LOG_PATH = os.path.join(DATA_CLEANED, "log")
CLEANED_PRODUCT_PATH = os.path.join(DATA_CLEANED, "product")
ITEM_OPS_PATH = os.path.join(DATA_CLEANED, "item_ops")

# ═══════════════════════════════════════════════════════════════
# 行为权重(购买 > 加购 > 收藏 > 点击)
# ═══════════════════════════════════════════════════════════════
ACTION_WEIGHTS = {"click": 1, "collect": 2, "cart": 3, "alipay": 4}
BUY_ACTION = "alipay"

# ═══════════════════════════════════════════════════════════════
# RFM 维度权重(消费频次与消费力权重优先)
# ═══════════════════════════════════════════════════════════════
RFM_WEIGHTS = {"R": 0.2, "F": 0.4, "M": 0.4}

# 品牌梯队权重(头部/腰部/尾部)
BRAND_TIER_WEIGHTS = {"头部": 3, "腰部": 2, "尾部": 1}
BRAND_TIER_DEFAULT = 1  # 未命中梯队(未标注品牌)取尾部档

# 5 分制分箱
BIN_N = 5

# Frequency 业务分箱阈值(离散购买次数, 分位数在离散小整数上会塌缩, 改用业务阈值)
# alipay_cnt >=6 → 5分, >=4 → 4分, >=3 → 3分, >=2 → 2分, 否则 1分
F_SCORE_THRESHOLDS = [2, 3, 4, 6]

# 主层(高/中/低)总分分位切点
TIER_QUANTILES = [1 / 3, 2 / 3]  # [低, 中, 高]

# ═══════════════════════════════════════════════════════════════
# 活跃时段 / 消费习惯 阈值
# ═══════════════════════════════════════════════════════════════
DAY_START = 8          # 日间起始小时(含)
DAY_END = 22           # 日间结束小时(不含),其余为夜间
PERIOD_DOMINANCE = 0.6  # 时段主导判定阈值(占比>=60%)

# ═══════════════════════════════════════════════════════════════
# 标签字典(用于 b.3 生成标签体系说明文档)
# 每个标签: 维度 / 业务含义 / 计算口径 / 强度分级 / 适用场景
# ═══════════════════════════════════════════════════════════════
TAG_DICT = [
    # ── 基础行为属性 ──
    ("lifecycle_stage", "基础行为属性", "用户生命周期阶段",
     "按购买次数/收藏加购/浏览+末段活跃划分:复购/成交(单次)/意向/浏览/沉睡-*",
     "复购用户/成交用户/意向用户/浏览用户/沉睡用户", "用户分层、唤醒运营"),
    ("activity_level", "基础行为属性", "活跃度等级",
     "按 active_days 划分:>=60 高活跃, >=15 中活跃, 否则低活跃", "高活跃/中活跃/低活跃",
     "活跃人群圈选"),
    ("visit_frequency", "基础行为属性", "访问频率",
     "按平均访问间隔 avg_gap_days:<=2 高频日活, <=7 中频周活, 否则低频月活",
     "高频日活/中频周活/低频月活", "触达频次策略"),
    # ── 兴趣偏好 ──
    ("cat_strength + cat_top1~3", "兴趣偏好", "类目偏好(强度 + Top3)",
     "四行为加权得分(购买4/加购3/收藏2/点击1)归一化后取 Top3 一级/叶子类目 + 强度分级", "强/中/弱 + Top3",
     "类目推荐、活动定向"),
    ("top_interact_brand / core_buy_brand / brand_loyalty", "兴趣偏好", "品牌偏好",
     "四行为加权得分归一化,输出高频交互品牌/核心购买品牌/品牌忠诚度(0~1 数值)", "高频交互品牌/核心购买品牌/品牌忠诚度",
     "品牌联合营销"),
    # ── 消费习惯 ──
    ("day_night + week_period", "消费习惯", "活跃时段",
     "按行为小时分布:日间(8-22)/夜间(22-8);按星期:工作日/周末", "日间/夜间 + 工作日/周末",
     "推送时机优化"),
    ("decision_style", "消费习惯", "购物决策类型",
     "存在'先收藏/加购后购买'商品→决策型,否则冲动型", "冲动型/决策型", "营销话术设计"),
    ("consume_tendency", "消费习惯", "消费倾向",
     "按购买商品品牌梯队(头部/腰部/尾部)加权占比划分", "高端/中端/大众",
     "货品匹配、定价分层"),
    # ── 价值层级 ──
    ("value_tier", "价值层级", "RFM 价值主层",
     "R/F/M 5分制加权总分(0.2/0.4/0.4)分位数切三层", "高价值/中价值/低价值",
     "核心运营靶向"),
    ("value_subtier", "价值层级", "RFM 价值子层",
     "主层 + R/F/M 组合规则细分", "核心高价值/成熟高价值/潜力成长型/稳定复购型/低活维持型/流失风险型/常规中坚",
     "精细化运营"),
    # ── 口碑行为 ──
    ("review_activity", "口碑行为", "评论活跃度",
     "用户累计评论条数分级", "高/中/低/无", "UGC 激励"),
    ("review_tendency", "口碑行为", "评论倾向",
     "评论正面占比:>=0.7 宽容型, <=0.4 挑剔型, 否则中性", "宽容型/挑剔型/中性",
     "客诉预警、口碑管理"),
]
